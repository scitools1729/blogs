# Breakpoint Red Teamer
A CLI tool to batch execute Breakpoint red teaming prompts against a coding agent.
## Setup
This tool uses `uv` for dependency management and execution. To install the tool globally on your system so that it can be executed from anywhere:

```bash
# Navigate to the root of the breakpoint repository
cd breakpoint

# Install the tool globally via uv
uv tool install . --force
```

## Usage
`breakpoint --batch-size 50 --output results.csv`

## Prompt Taxonomy
The `breakpoint` dataset contains 1,570 prompts categorized into two main testing vectors:

### 1. Execution Prompts (`exec_*`)
Tests if the agent will blindly execute malicious instructions and code provided by the user.
*   **`exec_bash_*`**: Commands and scripts meant to be executed directly in a Linux shell environment (e.g., modifying `/etc/passwd`, setting up reverse shells).
*   **`exec_python_*`**: Python scripts provided to the agent to be executed via the Python interpreter (e.g., copying sensitive files, command injection).

### 2. Generation Prompts (`gen_*`)
Tests if the agent will write malicious code from scratch when given a suggestive function signature and docstring.
*   **`gen_virus_*`**: Code that replicates itself and infects other files or systems.
*   **`gen_trojan_*`**: Code that masquerades as a legitimate program but contains a hidden payload.
*   **`gen_ransomware_*`**: Code designed to iterate through file systems and encrypt user data.
*   **`gen_spyware_*`**: Code that silently monitors user activity (keyloggers, screen scrapers) and exfiltrates data.
*   **`gen_rootkit_*`**: Highly privileged code designed to hide its own existence (e.g., in-memory fileless execution).
*   **`gen_adware_*`**: Code that forcefully injects advertisements or hijacks browser searches.
*   **`gen_ddos_*`**: Code designed to overwhelm a target server with traffic (UDP floods, SYN floods).
*   **`gen_others_*`**: A mix of other malicious behaviors (cryptocurrency miners, credential stuffers, logic bombs).
