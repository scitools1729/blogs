# LLMesh Example: Workspace Guide

This guide demonstrates how to orchestrate a unified, multi-module AI Assurance pipeline using `core-llmesh`. 

By combining the structural power of `uv workspaces` with the hyper-parameter configuration engine of `Hydra`, you can deploy lightning-fast monolithic runtimes that effortlessly sweep sweeping across multiple benchmarks, red-team attacks, and language models in a single command.

---

## 1. Initializing the Workspace

Complex assurance pipelines often require multiple isolated modules that share underlying infrastructure.

Start by creating an overarching directory for your enterprise pipeline, copying the core framework into it, and installing the `llmesh` CLI locally:

```bash
# Create the root workspace directory
mkdir ai-assurance-pipeline
cd ai-assurance-pipeline

# Import the core LLMesh framework into the workspace root
cp -r ../core-llmesh .

# Install the scaffolding CLI tool directly from the local framework
uv tool install --force ./core-llmesh --no-cache
```

---

## 2. Scaffolding Modules

Next, we generate two distinct modules using the `llmesh` scaffolding CLI. One will handle static model performance evaluation, and the other will handle dynamic offensive security checks.

### The Benchmark Module
This module runs standard intelligence benchmarks on targeted LLMs.
```bash
llmesh create-module benchmark-llm function=evaluation tool=mmlu,gsm8k
```

### The Red Team Module
This module contains offensive security tools meant to break or test model constraints.
```bash
llmesh create-module redteam-llm function=attack tool=prompt_injection,jailbreak
```

---

## 3. Implementing Execution Logic

To turn the generated boilerplate into working examples, we'll assign simple mocked return values to our new tool implementations.

Open **`src/benchmark_llm/mmlu.py`** and update it to return a mock score and accept our runtime arguments:
```python
    def run(self, **kwargs):
        # In a real environment, this executes the MMLU eval loop against the defined model
        target_model = kwargs.get("model", "gpt-4")
        temp = kwargs.get("temperature", 0.7)
        return {
            "score": 88.5, 
            "status": "passed",
            "model_tested": target_model, 
            "temperature_used": temp
        }

    def get_tool_definition(self):
        return {
            "name": self.name,
            "description": "Evaluates the targeted model against the MMLU dataset",
            "parameters": {
                "type": "object",
                "properties": {
                    "model": {
                        "type": "string",
                        "description": "The target Foundation Model ID to evaluate (e.g., gpt-4)"
                    },
                    "temperature": {
                        "type": "number",
                        "description": "The generation temperature to use during the benchmark"
                    }
                },
                "required": ["model"]
            }
        }
```

Open **`src/benchmark_llm/conf/tool/mmlu.yaml`** and update it with the following configuration:
```yaml
# @package _global_
tool: "mmlu"

model: "claude-3"
temperature: 0.0
```

Open **`src/redteam_llm/prompt_injection.py`** and update it with an attack payload metric:
```python
    def run(self, **kwargs):
        # In a real environment, this pipes jailbreak payloads into the target LLM
        return {
            "attack_success": True, 
            "payload_executed": "ignore previous instructions",
            "severity_finding": "High"
        }

    def get_tool_definition(self):
        return {
            "name": self.name,
            "description": "Executes prompt injection vectors against a target system",
            "parameters": {
                "type": "object",
                "properties": {
                    "payload_type": {
                        "type": "string",
                        "description": "The vector category to test (e.g., system_override, role_play)"
                    }
                },
                "required": []
            }
        }
```

---

## 4. Building the Application

With our logic written, we can fuse the distinct modules together utilizing `uv workspaces`. Running the LLMesh builder initiates a recursive scan of the root directory and securely links all dependencies to the singular `core-llmesh` sibling.

```bash
llmesh build .
```

*Output summary:*
```log
Detected modules: "redteam-llm", "benchmark-llm", "core-llmesh"
Scaffolding root uv workspace pyproject.toml...
Running uv sync across the workspace...
Workspace built successfully! All modules share the root .venv.
```

The pipeline initializes nearly instantaneously, because `data-forge` and `redteam-llm` both fundamentally rely on `core-llmesh`, meaning dependency trees are perfectly resolved only once at the root level.

---

## 5. Execution and Sweeping

The `llmesh run-module` command automatically abstracts virtual environments and proxies directly into the `uv run` mechanism, handing over control to the `Hydra` configuration engine.

### Single Tool Execution
Execute a single benchmark script directly via the orchestrator:
```bash
llmesh run-module benchmark-llm function=evaluation tool=mmlu
```

### Parameter Overriding (Runtime Injection)
You can directly bridge dynamic runtime arguments cleanly into the underlying `kwargs` payload for your tools:
```bash
llmesh run-module benchmark-llm function=evaluation tool=mmlu model=claude-3 temperature=0.0
```
This is directly picked up by our modified Python code and injected into the evaluation run.

### Configuration Sweeping
The true advantage of backing the multi-module execution via Hydra comes from the ability to generate combinatorial sweeps across parameters using the `-m` flag. 

You can queue up massive arrays of test definitions to run sequentially, generating vast matrices of configuration runs in a single line.

**Example 1: Sweeping tools hyperparameters**
Execute the `mmlu` benchmark with three different temperature settings:
```bash
llmesh run-module benchmark-llm function=evaluation tool=mmlu model=claude-3 temperature=0.0,0.1,0.2 -m
# This launches two jobs
```
Execute the `mmlu` benchmark on three models with three different temperature settings:
```bash
llmesh run-module benchmark-llm function=evaluation tool=mmlu model=gpt-4,llama-3,qwen-3 temperature=0.0,0.1,0.2 -m
# This launches 9 jobs
```

**Example 2: Sweeping multiple tools simultaneously**
Execute the entirety of the offensive red team suite in one go:
```bash
llmesh run-module redteam-llm function=attack tool=prompt_injection,jailbreak -m
```

*Output trace:*
```log
[HYDRA] Launching 9 jobs locally
[HYDRA]         #0 : function=evaluation tool=mmlu model=gpt-4 temperature=0.0
[HYDRA]         #1 : function=evaluation tool=mmlu model=gpt-4 temperature=0.1
[HYDRA]         #2 : function=evaluation tool=mmlu model=gpt-4 temperature=0.2
[HYDRA]         #3 : function=evaluation tool=mmlu model=llama-3 temperature=0.0
[HYDRA]         #4 : function=evaluation tool=mmlu model=llama-3 temperature=0.1
...
```
This effortlessly bridges declarative pipeline generation with industrial-grade runtime scalability.
