# Intelligence Collection Tools (ictools)

This project provides a suite of intelligence collection and analysis tools designed to simulate a modern multi-int workflow. It leverages **Hydra** for powerful configuration management and parallel execution.

## Components

The toolkit consists of three primary services:

1.  **SIGINT (Signal Intelligence)**: Scans frequency ranges to detect potential threats.
2.  **GEOINT (Geospatial Intelligence)**: Tasks satellite assets to image detected coordinates using various sensors (Electro-Optical, SAR).
3.  **COMPVIS (Computer Vision)**: Analyzes imagery using AI models (YOLO, EfficientNet) to identify objects.

## Configuration

The project uses a modular configuration structure to ensure clean execution and output:

*   **`conf/config.yaml`**: The main entry point, defining defaults.
*   **`conf/project/`**: Project-specific settings. `ictools.yaml` dynamically loads tool configurations.
*   **`conf/tool/`**: Individual tool configurations (e.g., `sigint_tool.yaml`) containing specific defaults.

This structure allows valid parameters (like `frequency_range` for SIGINT) to be loaded only when that specific tool is requested, keeping the output free of irrelevant settings.

## Usage

### 1. Install Dependencies
This project uses `uv` for dependency management.

```bash
uv sync
```

### 2. Run Individual Tools
You can run individual tools using the CLI interface.

**SIGINT Scan:**
```bash
uv run main.py interface=cli project=ictools tool=sigint_tool frequency_range="100-500 MHz"
```

**GEOINT Tasking:**
```bash
uv run main.py interface=cli project=ictools tool=geoint_tool \
    signal_event.coordinates.lat=34.05 \
    signal_event.coordinates.lon=-118.24 \
    sensor_type="SAR"
```

**COMPVIS Analysis:**
```bash
uv run main.py interface=cli project=ictools tool=compvis_tool \
    image_data.image_path="/tmp/satellite_img.nitf" \
    image_data.model_type="YOLOv8"
```

### 3. Parameter Sweeps on Individual Tools
You can also use Hydra's multirun (`-m`) feature to sweep over parameters for individual tools.

**Sweep SIGINT Frequencies:**
```bash
uv run main.py interface=cli project=ictools tool=sigint_tool \
    frequency_range="'100-200 MHz','400-500 MHz'" \
    -m
```

**Sweep COMPVIS Models:**
```bash
uv run main.py interface=cli project=ictools tool=compvis_tool \
    image_data.model_type="YOLOv8,EfficientNet" \
    -m
```

### 4. Run the IC Workflow
The IC workflow chains these tools together: **Detect -> Image -> Identify**.

Run a single cycle:
```bash
uv run main.py interface=cli project=icworkflow frequency_range="1-2 GHz"
```

### 5. Parameter Sweeps on IC Workflow
You can also use Hydra's multirun (`-m`) feature to sweep over parameters for entire workflows.

```bash
uv run main.py interface=cli project=icworkflow \
    frequency_range="'1-2 GHz','10-12 GHz'" \
    sensor_type="EO,SAR" \
    model_type="YOLOv8,ViT-Huge" \
    -m
```

This command will:
1.  Launch 8 parallel jobs.
2.  Each job represents a unique combination of frequency, sensor, and model.
3.  Hydra manages the execution and output directory structure.

## Exposing Tools via MCP (Model Context Protocol)

You can expose all registered tools (SIGINT, GEOINT, COMPVIS, IcWorkflow) as an MCP server, allowing them to be consumed by AI agents and other MCP clients.

Run the MCP server:
```bash
uv run main.py interface=mcp
```

This will start an MCP server over stdio, making the tools available for function calling.

### Example Agent Queries
Here are 5 natural language queries an agent can process using these tools:

1.  *"Scan the frequency range 100-500 MHz for any signals."*
2.  *"Can you check satellite imagery for coordinates 34.05, -118.24 using a SAR sensor?"*
3.  *"Analyze the image at '/tmp/satellite_img.nitf' using the YOLOv8 model."*
4.  *"Run a full intelligence cycle for the 1-2 GHz band using Electro-Optical sensors and EfficientNet."*
5.  *"First scan for signals in the UHF band, then task a satellite if anything is found, and finally identify any objects in the image."*
