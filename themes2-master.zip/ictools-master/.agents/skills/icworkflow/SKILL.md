---
name: icworkflow
description: Executing the full Intelligence Cycle Workflow (SIGINT -> GEOINT -> COMPVIS) to detect, image, and identify threats.
version: 1.0.0
---

# Intelligence Cycle Workflow (IcWorkflow)

This skill guides the agent through the standard Intelligence Cycle workflow used to detect, track, and identify targets using a multi-int approach.

## Goal
To successfully identify physical equipment associated with signal emissions by chaining Signal Intelligence (SIGINT), Geospatial Intelligence (GEOINT), and Computer Vision (COMPVIS).

## Workflow Steps

The intelligence cycle consists of three sequential phases that **MUST** be executed in this specific order:

### 1. Detection (SIGINT)
**Action**: Scan the electromagnetic spectrum to detect signal emissions and geolocate their source.
**Tool**: `sigint_tool`
**Input**: `frequency_range` (e.g., "100-500 MHz", "1-2 GHz")
**Output**: `signal_event` containing `coordinates` (lat/lon).

### 2. Collection (GEOINT)
**Action**: Task a satellite to collect imagery of the geolocated coordinates.
**Tool**: `geoint_tool`
**Input**: 
*   `signal_event`: From Phase 1 output.
*   `sensor_type`: Optional (default: "Electro-Optical/Infrared"). Use "SAR" for all-weather/night capabilities.
**Output**: `image_data` containing `image_path`.

### 3. Identification (COMPVIS)
**Action**: Analyze the collected imagery to identify the physical object.
**Tool**: `compvis_tool`
**Input**:
*   `image_data`: From Phase 2 output.
*   `model_type`: Optional (default: "Standard"). Use "YOLOv8" for speed, "EfficientNet" for accuracy.
**Output**: Classification result and confidence score.

## Automated Execution

For efficiency, you can execute the entire cycle in a single step using the composite workflow primitive:

**Tool**: `icworkflow`
**Inputs**:
*   `frequency_range`
*   `sensor_type` (Optional)
*   `model_type` (Optional)

## Usage Examples

### Scenario 1: Manual Step-by-Step Execution
**User**: "Check for activity in the VHF band and identify any contacts."

**Agent**:
1.  Call `sigint_tool(frequency_range="30-300 MHz")`
    *   *Result*: Found signal at 34.05, -118.24.
2.  Call `geoint_tool(signal_event=PREVIOUS_RESULT, sensor_type="SAR")`
    *   *Result*: Image acquired at `/tmp/img_123.nitf`.
3.  Call `compvis_tool(image_data=PREVIOUS_RESULT, model_type="YOLOv8")`
    *   *Result*: "Mobile Launcher (89%)"

### Scenario 2: Automated Execution
**User**: "Run a full scan on 1-2 GHz using high-res optical sensors and the best accuracy model."

**Agent**:
1.  Call `icworkflow(frequency_range="1-2 GHz", sensor_type="Electro-Optical", model_type="EfficientNet")`
