from dataclasses import dataclass
from llmesh import Primitive
from compvis.compvis import computer_vision_service

@dataclass
class CompvisTool(Primitive):
    name: str = "compvis_tool"

    def __init__(self):
        super().__init__(self.name)

    def run(self, **kwargs):
        return computer_vision_service(
            image_data=kwargs.get("image_data", {})
        )

    def get_tool_definition(self):
        return {
            "name": self.name,
            "description": "Analyzes the high-res image to confirm physical equipment.",
            "parameters": {
                "type": "object",
                "properties": {
                    "image_data": {
                        "type": "object",
                        "description": "Image data containing the path to the image.",
                        "properties": {
                            "image_path": {"type": "string", "description": "Path to the image file"},
                            "model_type": {"type": "string", "description": "The AI model to use (e.g., 'YOLOv8', 'EfficientNet').", "default": "Standard"}
                        },
                        "required": ["image_path"]
                    }
                },
                "required": ["image_data"]
            }
        }

if __name__ == "__main__":
    tool = CompvisTool()
    print(tool.run(image_data={"image_path": "/secure/imagery/IMG_88291.nitf"}))
    print(tool.get_tool_definition())
