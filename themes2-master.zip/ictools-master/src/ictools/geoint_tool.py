from dataclasses import dataclass   
from llmesh import Primitive 
from geoint.satellite_tracking_service import satellite_tasking_service

@dataclass
class GeointTool(Primitive):
    name: str = "geoint_tool"
    
    def __init__(self):
        super().__init__(self.name)

    def run(self, **kwargs):
        return satellite_tasking_service(
            signal_event=kwargs.get("signal_event", {}),
            sensor_type=kwargs.get("sensor_type", "Electro-Optical/Infrared")
        )

    def get_tool_definition(self):
        return {
            "name": self.name,
            "description": "Tasks the nearest orbital asset for imagery based on signal event data.",
            "parameters": {
                "type": "object",
                "properties": {
                    "signal_event": {
                        "type": "object",
                        "description": "The signal event containing target coordinates.",
                        "properties": {
                            "coordinates": {
                                "type": "object",
                                "description": "The lat/lon coordinates of the target.",
                                "properties": {
                                    "lat": {"type": "number", "description": "Latitude"},
                                    "lon": {"type": "number", "description": "Longitude"}
                                },
                                "required": ["lat", "lon"]
                            }
                        },
                        "required": ["coordinates"]
                    },
                    "sensor_type": {
                        "type": "string",
                        "description": "The type of sensor to use (e.g., 'Electro-Optical', 'SAR').",
                        "default": "Electro-Optical/Infrared"
                    }
                },
                "required": ["signal_event"]
            }
        }

if __name__ == "__main__":
    tool = GeointTool()
    print(tool.run(signal_event={"coordinates": {"lat": 34.05, "lon": -118.24}}))
    print(tool.get_tool_definition())

