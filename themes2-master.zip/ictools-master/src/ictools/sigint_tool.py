from dataclasses import dataclass   
from llmesh import Primitive 
from sigint.rf_sensing_service import rf_sensing_service

@dataclass
class SigintTool(Primitive):
    name: str = "sigint_tool"
    
    def __init__(self):
        super().__init__(self.name)

    def run(self, **kwargs):
        return rf_sensing_service(
            frequency_range=kwargs.get("frequency_range", "1-10 GHz")
        )

    def get_tool_definition(self):
        return {
            "name": self.name,
            "description": "Scans radio frequencies for known threat signatures.",
            "parameters": {
                "type": "object",
                "properties": {
                    "frequency_range": {
                        "type": "string",
                        "description": "The frequency range to scan (e.g., '1-10 GHz')"
                    }
                },
                "required": ["frequency_range"]
            }
        }


if __name__ == "__main__":
    tool = SigintTool()
    print(tool.run(frequency_range="1-10 GHz"))
    print(tool.get_tool_definition())