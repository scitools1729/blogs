from typing import TypedDict, Optional, List, Dict, Any
from langgraph.graph import StateGraph, END
from llmesh import Primitive

# 1. Define State
class IntelligenceState(TypedDict):
    # Inputs (Sweep Variables)
    frequency_range: str
    sensor_type: str
    model_type: str
    
    # Intermediate Artifacts
    signal_event: Optional[Dict[str, Any]]
    image_data: Optional[Dict[str, Any]]
    
    # Output
    final_detection: Optional[List[Dict[str, Any]]]

# 2. Define Nodes
def sigint_node(state: IntelligenceState) -> IntelligenceState:
    tool = Primitive.registry.get("sigint_tool")
    # Call sigint tool
    # Tool signature: run(frequency_range=...)
    result = tool.run(frequency_range=state["frequency_range"])
    return {**state, "signal_event": result}

def geoint_node(state: IntelligenceState) -> IntelligenceState:
    tool = Primitive.registry.get("geoint_tool")
    # Call geoint tool
    # Tool signature: run(signal_event=..., sensor_type=...)
    result = tool.run(
        signal_event=state["signal_event"],
        sensor_type=state["sensor_type"]
    )
    return {**state, "image_data": result}

def compvis_node(state: IntelligenceState) -> IntelligenceState:
    tool = Primitive.registry.get("compvis_tool")
    # Call compvis tool
    # Tool signature: run(image_data=...)
    # We need to inject model_type into image_data before calling
    image_data = state["image_data"]
    # Create a copy or modify in place? Let's create a new dict to be safe and clean
    # The tool expects image_data to contain image_path and optionally model_type
    
    # Actually, look at compvis_tool.py: It takes image_data as an argument.
    # We should merge the model_type from state into the image_data dict we pass.
    enhanced_image_data = {
        **image_data, 
        "model_type": state["model_type"]
    }
    
    result = tool.run(image_data=enhanced_image_data)
    return {**state, "final_detection": result}

# 3. Define Graph
workflow = StateGraph(IntelligenceState)
workflow.add_node("sigint_scan", sigint_node)
workflow.add_node("satellite_tasking", geoint_node)
workflow.add_node("image_analysis", compvis_node)

workflow.set_entry_point("sigint_scan")
workflow.add_edge("sigint_scan", "satellite_tasking")
workflow.add_edge("satellite_tasking", "image_analysis")
workflow.add_edge("image_analysis", END)

app = workflow.compile()

# 4. Wrap in Primitive
class IcWorkflow(Primitive):
    name: str = "icworkflow"
    
    def __init__(self):
        super().__init__(self.name)
        
    def run(self, **kwargs):
        initial_state = IntelligenceState(
            frequency_range=kwargs.get("frequency_range", "1-10 GHz"),
            sensor_type=kwargs.get("sensor_type", "Electro-Optical/Infrared"),
            model_type=kwargs.get("model_type", "Standard"),
            signal_event=None,
            image_data=None,
            final_detection=None
        )
        return app.invoke(initial_state)
        
    def get_state_graph(self):
        return app

    def get_workflow_definition(self):
        return {
            "description": "Executes a full intelligence cycle: SIGINT -> GEOINT -> COMPVIS.",
            "steps": [
                {
                    "name": "sigint_scan",
                    "description": "Scan for signals in frequency range.",
                    "tools": ["sigint_tool"]
                },
                {
                    "name": "satellite_tasking",
                    "description": "Task satellite to image detected coordinates.",
                    "tools": ["geoint_tool"]
                },
                {
                    "name": "image_analysis",
                    "description": "Analyze imagery to identify objects.",
                    "tools": ["compvis_tool"]
                }
            ]
        }
