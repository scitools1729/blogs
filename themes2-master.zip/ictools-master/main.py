import hydra
from omegaconf import DictConfig, OmegaConf
from llmesh.main import execute_mesh, setup_cli_environment

@hydra.main(config_path="conf", config_name="config", version_base=None)
def main(cfg: DictConfig):
    import src.ictools
    # Run the mesh
    execute_mesh(cfg)

if __name__ == "__main__":
    main()