# mod-redteam-breakpoint

`mod-redteam-breakpoint` is an LLMesh integration of the comprehensive Breakpoint red teaming dataset. It provides a massive collection of 1,570 adversarial prompts explicitly designed to evaluate an LLM's safety boundaries around generating malware and executing dangerous system commands.

This module utilizes the `parallel_agent_executor` primitive to rapidly sweep these prompts against any target code generation agent exposed via an api endpont(vllm, ollama, etc.) in a highly concurrent, multi-threaded batch executor. 

By passing `prompt_category`, you can precisely isolate which attack vectors to test. By passing `num_prompts`, you can slice a random representative sample of the prompts to test.

## Prompt Categories
Available Prompt Categories:
- Execution Prompts (600 total)
    - exec_bash (300 prompts)
    - exec_python (300 prompts)
- Generation & Malware Prompts (970 total)
    - gen_adware
    - gen_ddos
    - gen_ransomware
    - gen_rootkit
    - gen_spyware
    - gen_trojan
    - gen_virus
    - gen_others
        - backdoor
        - botnet
        - worm

```bash
# prompt_category="<category>" implements substring matching using <category> as the prefix
prompt_category="exec_" get all the 600 prompts
prompt_category="gen_" get all the 970 prompts
```

## Run breakpoint module

```bash
# for vllm and other OpenAI-compatible APIs
llmesh run-module mod-redteam-breakpoint \
    function=agent_evaluation \
    tool=parallel_agent_executor \
    prompt_category="gen_" \
    target_id="openai:chat:Meta-Llama-3-8B-Instruct" \
    api_base_url="http://localhost:8000/v1" \
    api_key="your_vllm_api_key_if_any" \
    batch_size=5 \
    num_prompts=25 \
    -m

# for ollama APIs
llmesh run-module mod-redteam-breakpoint \
    function=agent_evaluation \
    tool=parallel_agent_executor \
    prompt_category="gen_" \
    target_id="ollama:chat:gpt-oss:latest" \
    api_base_url="http://localhost:11434/v1" \
    api_key="DUMMY" \
    batch_size=5 \
    num_prompts=25 \
    -m
```