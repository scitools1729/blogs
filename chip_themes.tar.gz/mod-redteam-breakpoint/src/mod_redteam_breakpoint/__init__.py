from core_llmesh import Primitive

from .parallel_agent_executor import ParallelAgentExecutor
Primitive.add(ParallelAgentExecutor())
