import csv
from collections import Counter

prefixes = []
with open("breakpoint_prompts.csv", "r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for row in reader:
        pid = row["prompt_id"]
        # The prompt_id looks like "exec_bash_001" or "gen_virus_050"
        # We want everything before the last underscore
        if "_" in pid:
            prefix = pid.rsplit("_", 1)[0]
            prefixes.append(prefix)
        else:
            prefixes.append(pid)

counts = Counter(prefixes)
print("Available Prompt Categories:")
for cat, count in sorted(counts.items()):
    print(f"- {cat} ({count} prompts)")
