from core_llmesh import Primitive

from .garak_runner import GarakRunner
Primitive.add(GarakRunner())
