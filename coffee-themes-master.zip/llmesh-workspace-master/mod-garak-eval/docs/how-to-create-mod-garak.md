# Tutorial: Creating the `mod-garak-eval` Module

This guide provides a step-by-step walkthrough to recreate the `mod-garak-eval` module from scratch, starting with the `llmesh` scaffolding command.

## 1. Scaffold the Module

Use the `llmesh create-module` command to generate the initial structure.

```bash
# From the workspace root
llmesh create-module mod-garak-eval function=scan_vulnerabilities
```

## 2. Configure Dependencies

Garak has dependency conflicts with the workspace. We will remove it from the direct dependencies and run it via `uvx`.

```bash
# Remove garak from mod-garak-eval/pyproject.toml if it was added, 
# or ensure it only contains hydra and core-llmesh.
cat <<EOF > mod-garak-eval/pyproject.toml
[project]
name = "mod-garak-eval"
version = "0.1.0"
description = "Module for NVIDIA Garak red-teaming and vulnerability scanning"
requires-python = ">=3.11"
dependencies = [
    "core-llmesh",
    "hydra-core",
    "omegaconf",
]

[build-system]
requires = ["setuptools"]
build-backend = "setuptools.build_meta"

[tool.uv.sources]
core-llmesh = { workspace = true }
EOF
```

## 3. Implement the Garak Runner Primitive

Replace the scaffolded `garak_runner.py` with the implementation that supports `uvx` isolation and JSONL report parsing.

```bash
cat <<EOF > mod-garak-eval/src/mod_garak_eval/garak_runner.py
import os
import subprocess
import json
import glob
from dataclasses import dataclass
from core_llmesh import Primitive
from rich.console import Console

@dataclass
class GarakRunner(Primitive):
    """
    Primitive for executing NVIDIA Garak red-teaming tool.
    """
    name: str = "garak_runner"

    def __init__(self):
        super().__init__(self.name)

    def run(self, **kwargs):
        console = Console()
        
        # 1. Parameter Extraction
        target_type = kwargs.get("target_type")
        target_name = kwargs.get("target_name")
        probes = kwargs.get("probes", "")
        detectors = kwargs.get("detectors", "")
        generations = kwargs.get("generations")
        
        if not target_type or not target_name:
            return {"status": "error", "message": "'target_type' and 'target_name' are required."}

        # Resolve output directory via Hydra
        try:
            from hydra.core.hydra_config import HydraConfig
            output_dir = HydraConfig.get().runtime.output_dir
        except Exception:
            output_dir = os.getcwd()

        # 2. Command Construction & Configuration Redirection
        # Create a temporary Garak config to redirect reporting to the Hydra output_dir
        garak_config_path = os.path.join(output_dir, "garak_config.yaml")
        with open(garak_config_path, "w") as f:
            f.write(f"reporting:\n  report_dir: {output_dir}\n")

        # Use uvx to run garak in an isolated environment
        cmd = [
            "uvx", "--from", "garak>=0.10.2", "garak", 
            "--target_type", target_type, 
            "--target_name", target_name,
            "--config", garak_config_path
        ]
        
        if probes:
            cmd.extend(["--probes", probes])
        if detectors:
            cmd.extend(["--detectors", detectors])
        if generations:
            cmd.extend(["--generations", str(generations)])
        
        # 3. Environment and Execution
        env = os.environ.copy()
        console.log(f"[garak_runner] Executing Garak: {' '.join(cmd)}")
        
        try:
            captured_output = []
            with console.status(f"[bold red]Red-teaming {target_name}...", spinner="shark") as status:
                process = subprocess.Popen(
                    cmd, 
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.STDOUT, 
                    universal_newlines=True,
                    bufsize=1,
                    env=env
                )
                
                for line in process.stdout:
                    captured_output.append(line)
                    clean_line = line.strip()
                    if clean_line:
                        status.update(f"[bold red]garak: [white]{clean_line[:85]}")
                        
                process.wait()
        
            if process.returncode != 0:
                return {
                    "status": "error", 
                    "message": f"Garak scan failed with code {process.returncode}",
                    "stdout": "".join(captured_output)
                }
                
            # 4. Report Parsing - Look in the Hydra output_dir
            report_dir = output_dir
            report_files = glob.glob(os.path.join(report_dir, "*.report.jsonl"))
            
            results_summary = {}
            if report_files:
                latest_report = max(report_files, key=os.path.getctime)
                console.log(f"[garak_runner] Parsing report: {latest_report}")
                
                try:
                    with open(latest_report, "r") as f:
                        for line in f:
                            data = json.loads(line)
                            if data.get("entry_type") == "eval":
                                probe_name = data.get("probe")
                                passes = data.get("passed", 0)
                                total = data.get("total", 0)
                                results_summary[probe_name] = {
                                    "passed": passes,
                                    "total": total,
                                    "score": (passes / total) if total > 0 else 0
                                }
                except Exception as parse_err:
                    console.log(f"[garak_runner] [yellow]Warning: Could not parse report: {parse_err}")

            return {
                "status": "completed",
                "target": f"{target_type}/{target_name}",
                "probes": probes,
                "output_dir": output_dir,
                "report_file": latest_report if report_files else None,
                "results": results_summary,
                "stdout_preview": "".join(captured_output[-20:])
            }
            
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def get_tool_definition(self):
        return {
            "name": self.name,
            "description": (
                "Executes NVIDIA Garak to red-team and scan LLMs for vulnerabilities. "
                "Garak probes models for jailbreaks, prompt injection, toxicity, and data leakage. "
                "The tool returns a summary of scan results including pass/fail rates for each probe."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "target_type": {
                        "type": "string",
                        "description": "Generator family (e.g., 'ollama', 'huggingface').",
                        "enum": ["ollama", "huggingface", "openai", "nim", "replicate", "anthropic", "cohere", "google"]
                    },
                    "target_name": {
                        "type": "string",
                        "description": "Model identifier (e.g., 'llama3', 'gpt2')."
                    },
                    "probes": {
                        "type": "string",
                        "description": "Comma-separated probes (e.g., 'dan.Dan_11_0')."
                    },
                    "detectors": {
                        "type": "string",
                        "description": "Optional detectors."
                    },
                    "generations": {
                        "type": "integer",
                        "description": "Number of generations per prompt.",
                        "default": 10
                    }
                },
                "required": ["target_type", "target_name"]
            }
        }
EOF
```

## 4. Update Defaults in Hydra Config

Refine the generated `config.yaml` to set default tools and functions.

```bash
cat <<EOF > mod-garak-eval/src/mod_garak_eval/conf/config.yaml
hydra:
  searchpath:
    - pkg://core_llmesh.conf

defaults:
  - _self_
  - interface: cli
  - function: scan_vulnerabilities
  - tool: garak_runner

function: scan_vulnerabilities
tool: garak_runner
target_type: ""
target_name: ""
probes: ""
detectors: ""
generations: 10
EOF
```

## 5. Finalize and Sync

```bash
# Sync workpace
uv sync

# Run smoke test
llmesh run-module mod-garak-eval \\
    target_type=ollama \\
    target_name=gpt-oss:latest \\
    probes=dan.Dan_11_0 \\
    generations=1
```
