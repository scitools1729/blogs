# mod-garak-eval

This module integrates [NVIDIA Garak](https://github.com/NVIDIA/garak), a Generative AI Red-teaming & Assessment Kit, into the LLMesh framework.

## Overview

`mod-garak-eval` allows you to run adversarial scans against LLMs to identify vulnerabilities such as prompt injection, jailbreaking, toxicity, and data leakage.

### Key Features
- **Isolated Execution**: Runs Garak via `uvx` to avoid dependency conflicts (e.g., `datasets`, `numpy`) with other workspace modules.
- **Hydra Integration**: Automatically redirects Garak reports and logs into the standard LLMesh/Hydra `outputs/` directory.
- **Structured Results**: Parses Garak's JSONL reports to provide summary pass/fail metadata directly in the LLMesh output.

## Usage

Run the module using the `llmesh run-module` command.

### Basic Command
```bash
llmesh run-module mod-garak-eval \
    target_type=ollama \
    target_name=gpt-oss:latest \
    probes=dan.Dan_11_0
```

### Parameters

| Parameter | Default | Description |
| :--- | :--- | :--- |
| `target_type` | (required) | The Garak generator type (e.g., `ollama`, `huggingface`, `openai`). |
| `target_name` | (required) | The model name or API endpoint. |
| `probes` | "" | Comma-separated list of probes or families (e.g., `dan`, `encoding`). |
| `detectors` | "" | Comma-separated list of detectors. |
| `generations` | 10 | Number of times to send each prompt. |

### Smoke Testing (Fast Scan)

**Ollama (Local)**
```bash
llmesh run-module mod-garak-eval \
    target_type=ollama \
    target_name=gpt-oss:latest \
    probes=dan.Dan_11_0 \
    generations=1
```

**vLLM (Remote/OpenAI-compatible)**
First, ensure `OPENAI_API_BASE` is set to your vLLM endpoint:
```bash
export OPENAI_API_BASE="http://localhost:8000/v1"
llmesh run-module mod-garak-eval \
    target_type=openai \
    target_name=gpt-oss-120B \
    probes=dan.Dan_11_0 \
    generations=1
```

## Output & Reports

Garak's full reports are stored in the current run's output directory:
`mod-garak-eval/outputs/YYYY-MM-DD/HH-MM-SS/`

Files include:
- `garak.*.report.jsonl`: Detailed scan logs.
- `garak.*.report.html`: Visual summary of results.
- `garak_config.yaml`: Temporary config used to redirect output.

## Configuration

Default settings are managed in:
- `src/mod_garak_eval/conf/config.yaml`
- `src/mod_garak_eval/conf/tool/garak_runner.yaml`
