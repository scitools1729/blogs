import pytest
import os
import json
from unittest.mock import MagicMock, patch, mock_open
from mod_garak_eval import GarakRunner

@pytest.fixture
def garak_runner():
    return GarakRunner()

def test_get_tool_definition(garak_runner):
    definition = garak_runner.get_tool_definition()
    assert definition["name"] == "garak_runner"
    assert "target_type" in definition["parameters"]["properties"]
    assert "target_name" in definition["parameters"]["properties"]
    assert "ollama" in definition["parameters"]["properties"]["target_type"]["enum"]

@patch("subprocess.Popen")
@patch("glob.glob")
@patch("os.path.getctime")
@patch("builtins.open", new_callable=mock_open)
def test_garak_runner_run_success(mock_file_open, mock_getctime, mock_glob, mock_popen, garak_runner):
    # 1. Setup Mock for subprocess
    mock_process = MagicMock()
    mock_process.stdout = ["line1", "line2"]
    mock_process.returncode = 0
    mock_popen.return_value = mock_process
    
    # Mock JSONL content
    report_content = json.dumps({
        "entry_type": "eval",
        "probe": "dan.Dan_11_0",
        "passed": 1,
        "total": 1
    }) + "\n"

    # 2. Setup Mocks for glob and file parsing
    mock_glob.return_value = ["dummy.report.jsonl"]
    mock_getctime.return_value = 1000
    
    # Setup side_effect to handle DIFFERENT files
    def open_side_effect(path, mode="r", *args, **kwargs):
        if "report" in str(path):
            return mock_open(read_data=report_content).return_value
        return mock_open().return_value

    mock_file_open.side_effect = open_side_effect

    # 3. Run the primitive
    result = garak_runner.run(
        target_type="ollama",
        target_name="gpt-oss:latest",
        probes="dan.Dan_11_0",
        generations=1
    )

    # 4. Assertions
    assert result["status"] == "completed"
    assert "dan.Dan_11_0" in result["results"]
    assert result["results"]["dan.Dan_11_0"]["passed"] == 1
    assert result["results"]["dan.Dan_11_0"]["total"] == 1
    
    # Verify subprocess call (using uvx)
    args, _ = mock_popen.call_args
    cmd = args[0]
    assert "uvx" in cmd
    assert "--target_type" in cmd
    assert "ollama" in cmd
    assert "--config" in cmd

def test_garak_runner_missing_args(garak_runner):
    result = garak_runner.run(target_type="ollama")
    assert result["status"] == "error"
    assert "'target_type' and 'target_name' are required" in result["message"]
