```bash
uv sync --all-packages
uv run pytest
```