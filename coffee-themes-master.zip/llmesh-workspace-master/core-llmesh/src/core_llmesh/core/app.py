import sys
from .primitive import Primitive


def run_app(config: dict, runner_key: str):
    """
    Main entry point for the application.

    Args:
        config: Configuration dictionary.
        runner_key: The configuration key that specifies which runner to use.
    """
    runner_name = config.get(runner_key)
    if not runner_name:
        # Fallback: Treat the key itself as the runner name (Flattened Config Support)
        runner_name = runner_key

    runner = Primitive.registry.get(runner_name)
    if not runner:
        print(f"Error: Runner '{runner_name}' not found in registry.")
        print(f"Available primitives: {list(Primitive.registry.keys())}")
        sys.exit(1)

    # Pass the entire config as kwargs to the runner
    result = runner.run(**config)
    
    from rich import print as rprint
    from rich.panel import Panel
    
    # Extract common output streams to format neatly
    stdout_str = result.pop('stdout', None) if isinstance(result, dict) else None
    stderr_str = result.pop('stderr', None) if isinstance(result, dict) else None

    # Print any remaining structured metadata
    rprint("[bold green]Result Metadata:[/bold green]")
    rprint(result)

    # Print unescaped standard streams if they were present
    if stdout_str:
        rprint("\n[bold cyan]Standard Output:[/bold cyan]")
        print(stdout_str)
        
    if stderr_str:
        rprint("\n[bold red]Standard Error:[/bold red]")
        print(stderr_str)
