import os
import json
import random
from dataclasses import dataclass
from core_llmesh import Primitive
from rich.console import Console

@dataclass
class ImageAttackPreprocessor(Primitive):
    """
    Primitive for generating visually perturbed (adversarial) images for a VQA dataset.
    """
    name: str = "image_attack_preprocessor"

    def __init__(self):
        super().__init__(self.name)

    def run(self, **kwargs):
        console = Console()
        
        dataset_path = kwargs.get("dataset_path")
        attack_name = kwargs.get("attack_name", "figstep")
        num_samples = kwargs.get("num_samples", None)

        if not dataset_path:
            return {"status": "error", "message": "'dataset_path' parameter is required."}

        # Resolve relative paths via Hydra
        try:
            from hydra.utils import get_original_cwd
            original_cwd = get_original_cwd()
        except Exception:
            original_cwd = os.getcwd()

        abs_dataset_path = os.path.join(original_cwd, dataset_path)
        
        if not os.path.exists(abs_dataset_path):
             return {"status": "error", "message": f"Dataset not found at {abs_dataset_path}"}

        console.log(f"[{self.name}] Reading dataset: {abs_dataset_path}")
        try:
             with open(abs_dataset_path, 'r') as f:
                  data = json.load(f)
        except Exception as e:
             return {"status": "error", "message": f"Failed to read dataset: {e}"}

        # Randomly sample items if num_samples is provided
        if num_samples is not None and isinstance(num_samples, int) and num_samples > 0:
             if num_samples < len(data):
                  console.log(f"[{self.name}] Randomly sampling {num_samples} out of {len(data)} items.")
                  data = random.sample(data, num_samples)
             else:
                  console.log(f"[{self.name}] num_samples ({num_samples}) >= dataset length ({len(data)}). Using full dataset.")

        dataset_dir = os.path.dirname(abs_dataset_path)
        output_image_dir = os.path.join(dataset_dir, attack_name)
        
        # Ensure output directory exists for perturbed images
        os.makedirs(output_image_dir, exist_ok=True)
        console.log(f"[{self.name}] Generated images will be saved to: {output_image_dir}")

        # Initialize OmniSafeBench-MM Attack
        try:
            import sys
            # Add OmniSafeBench-MM to sys.path so its absolute imports like 'core.unified_registry' work
            workspace_root = os.path.dirname(os.path.dirname(os.path.dirname(original_cwd)))
            omni_path = os.path.join(workspace_root, "OmniSafeBench-MM")
            if omni_path not in sys.path:
                sys.path.append(omni_path)
            
            from core.unified_registry import UNIFIED_REGISTRY
            
            attack_kwargs = kwargs.copy()
            if "target_model" in attack_kwargs:
                attack_kwargs["target_model_name"] = attack_kwargs.pop("target_model")

            from pathlib import Path
            console.log(f"[{self.name}] Initializing attack '{attack_name}'...")
            attack = UNIFIED_REGISTRY.create_attack(
                name=attack_name,
                config=attack_kwargs,
                output_image_dir=Path(output_image_dir)
            )


        except Exception as e:
            return {"status": "error", "message": f"Failed to load OmniSafeBench-MM attack '{attack_name}': {e}"}

        # Generate Adversarial Images
        console.log(f"[{self.name}] Generating images for {len(data)} items...")
        for index, item in enumerate(data):
             source_image_rel = item.get("image") or item.get("image_id")
             source_image_path = None
             if source_image_rel:
                 source_image_path = os.path.join(dataset_dir, source_image_rel)
                 if not os.path.exists(source_image_path):
                     alt_path = os.path.join(dataset_dir, "Images_val", os.path.basename(source_image_rel))
                     if os.path.exists(alt_path):
                         source_image_path = alt_path
             
             original_question = item.get("question", item.get("original_question", ""))
             case_id = f"{attack_name}_{index}"
             
             try:
                 test_case = attack.generate_test_case(
                     original_prompt=original_question,
                     image_path=source_image_path,
                     case_id=case_id
                 )
                 
                 # Rewire JSON to point to relative adversarial image path
                 if test_case and test_case.image_path:
                     rel_path = os.path.relpath(test_case.image_path, dataset_dir)
                     # Convert windows slashes to forward slashes for cross-platform JSON
                     item["image"] = rel_path.replace("\\", "/")
                 
                 if 'original_question' not in item:
                     item['original_question'] = original_question
                     item['question'] = test_case.prompt if test_case and test_case.prompt else original_question

             except Exception as e:
                 console.log(f"[{self.name}] Error on case {index}: {e}")

        # Construct output dataset filename
        base_name = os.path.basename(abs_dataset_path).replace(".json", "")
        output_dataset_name = os.path.join(dataset_dir, f"{base_name}_{attack_name}.json")

        console.log(f"[{self.name}] Writing modified dataset to: {output_dataset_name}")
        try:
             with open(output_dataset_name, 'w') as f:
                  json.dump(data, f, indent=4)
        except Exception as e:
             return {"status": "error", "message": f"Failed to write dataset: {e}"}

        return {
             "status": "completed",
             "message": f"Successfully preprocessed {len(data)} items into {output_image_dir}.",
             "output_file": output_dataset_name
        }

    def get_tool_definition(self):
        return {
            "name": self.name,
            "description": "Pre-processes multimodal JSON datasets by generating perturbed adversarial images offline. Generates a poisoned dataset file pointing to a new folder of adversarial images.",
            "parameters": {
                "type": "object",
                "properties": {
                    "dataset_path": {
                        "type": "string",
                        "description": "The path to the original clean JSON dataset file that needs to be preprocessed with an attack."
                    },
                    "attack_name": {
                        "type": "string",
                        "description": "The name of the visual attack to apply (e.g., 'figstep', 'bap').",
                        "default": "figstep"
                    },
                    "num_samples": {
                        "type": "integer",
                        "description": "Optional number of random samples to target. If omitted, applies to the entire dataset."
                    }
                },
                "required": ["dataset_path"]
            }
        }
