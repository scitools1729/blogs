from core_llmesh import Primitive

from .text_attack_preprocessor import TextAttackPreprocessor
from .image_attack_preprocessor import ImageAttackPreprocessor

Primitive.add(TextAttackPreprocessor())
Primitive.add(ImageAttackPreprocessor())
