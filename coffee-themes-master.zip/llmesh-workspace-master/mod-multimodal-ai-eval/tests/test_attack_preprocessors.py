import pytest
import os
import json
from unittest.mock import MagicMock, patch, mock_open
from mod_multimodal_ai_eval.image_attack_preprocessor import ImageAttackPreprocessor
from mod_multimodal_ai_eval.text_attack_preprocessor import TextAttackPreprocessor

@pytest.fixture
def image_preprocessor():
    return ImageAttackPreprocessor()

@pytest.fixture
def text_preprocessor():
    return TextAttackPreprocessor()

def test_image_tool_definition(image_preprocessor):
    definition = image_preprocessor.get_tool_definition()
    assert definition["name"] == "image_attack_preprocessor"
    assert "dataset_path" in definition["parameters"]["properties"]
    assert "attack_name" in definition["parameters"]["properties"]

def test_text_tool_definition(text_preprocessor):
    definition = text_preprocessor.get_tool_definition()
    assert definition["name"] == "text_attack_preprocessor"
    assert "dataset_path" in definition["parameters"]["properties"]

@patch("os.path.exists")
@patch("builtins.open", new_callable=mock_open, read_data='[{"question": "test", "image": "test.jpg"}]')
@patch("os.makedirs")
def test_image_preprocessor_run(mock_makedirs, mock_open_file, mock_exists, image_preprocessor):
    # Setup mocks
    mock_exists.return_value = True
    
    with patch.dict("sys.modules", {"core.unified_registry": MagicMock()}):
        from core.unified_registry import UNIFIED_REGISTRY
        mock_attack = MagicMock()
        mock_test_case = MagicMock()
        mock_test_case.image_path = "/fake/attack/test.jpg"
        mock_test_case.prompt = "perturbed test"
        mock_attack.generate_test_case.return_value = mock_test_case
        UNIFIED_REGISTRY.create_attack.return_value = mock_attack
        
        result = image_preprocessor.run(
            dataset_path="dummy.json",
            attack_name="figstep",
            num_samples=1
        )
    
    assert result["status"] == "completed"
    assert "Successfully preprocessed" in result["message"]
    assert "dummy_figstep.json" in result["output_file"]
