from inspect_ai import Task, task
from inspect_ai.dataset import Sample, MemoryDataset
from inspect_ai.model import ChatMessageUser, ContentText, ContentImage
from inspect_ai.solver import generate, system_message
from inspect_ai.scorer import includes
import json
import os

@task
def vrs_vqa_baseline():
    # Adjusted paths to match your llmesh-workspace/ structure [cite: 227]
    data_dir = "../../data/vrs_bench"
    img_dir = os.path.join(data_dir, "Images_val")
    vqa_json_path = os.path.join(data_dir, "VRSBench_EVAL_vqa.json")

    with open(vqa_json_path, 'r') as f:
        vqa_data = json.load(f)

    samples = []
    for item in vqa_data:
        img_id = item.get('image_id')
        if not img_id:
            continue

        img_path = os.path.abspath(os.path.join(img_dir, img_id))

        if os.path.exists(img_path):
            samples.append(Sample(
                input=[
                    ChatMessageUser(content=[
                        ContentText(text=item.get('question')),
                        ContentImage(image=img_path)
                    ])
                ],
                target=str(item.get('ground_truth')),
                metadata={
                    "id": item.get('question_id'),
                    "type": item.get('type')
                }
            ))

    return Task(
        dataset=MemoryDataset(samples),
        solver=[
            system_message("Answer the question about the satellite image briefly."),
            generate()
        ],
        scorer=includes()
    )