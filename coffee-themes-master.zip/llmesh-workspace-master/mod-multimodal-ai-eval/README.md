# mod-multimodal-ai-eval

This module is responsible for executing multimodal AI evaluations (such as VRSBench) in a standalone, decoupled manner. It functions as a domain-specific application layer, utilizing the `mod-inspectAI-eval` execution engine layer's `inspect_script_runner` to run evaluations.

## Evaluation Scripts

The evaluation definition scripts (previously called tests) are located in the `tasks/` directory:
- `tasks/vrs_baseline.py`: Baseline evaluation for the original VRSBench VQA dataset.
- `tasks/vrs_adversarial.py`: Adversarial evaluation for the preprocessed VRSBench VQA dataset.

## Pre-processing

If you need to generate the text-only adversarial prompts offline before running the adversarial evaluation, use the specialized preprocessor tool:
```bash
llmesh run-module mod-multimodal-ai-eval function=security tool=text_attack_preprocessor dataset_path='../data/vrs_bench/VRSBench_EVAL_vqa.json' attack_name='deceptive_roleplay_prefix'
```
This will read from `../data/vrs_bench/VRSBench_EVAL_vqa.json` and generate `../data/vrs_bench/VRSBench_EVAL_vqa_text_adv.json`.

## Running Evaluations

You can run these evaluations using the central `llmesh` command-line interface. Make sure your Python virtual environment is activated and you are in the `llmesh-workspace` root directory.

### Running the Adversarial Evaluation
Note: This evaluation requires the dataset to have been preprocessed using the script mentioned above. Replace `mockllm/model` with your desired target model ID (e.g., `openai/gpt-4o`).

```bash
llmesh run-module mod-multimodal-ai-eval function=security tool=inspect_script_runner tasks='tasks/vrs_adversarial.py' target_id='mockllm/model' limit=1
```

### Running the Baseline Evaluation
To run the standard, unmodified baseline evaluation:

```bash
llmesh run-module mod-multimodal-ai-eval function=security tool=inspect_script_runner tasks='tasks/vrs_baseline.py' target_id='mockllm/model' limit=1
```

### Command Arguments
- `function=security` / `tool=inspect_script_runner`: Routes the execution to the execution engine layer (`mod-inspectAI-eval`).
- `tasks`: The path to the evaluation script you want to run (e.g., `tasks/vrs_adversarial.py`).
- `target_id`: The model identifier (e.g., `openai/gpt-4o-mini`, `anthropic/claude-3-haiku-20240307`, or a custom local model).
- `limit`: (Optional) Restricts the evaluation to the first _N_ samples for quick testing. Remove this argument to run the full dataset.
