# Multimodal Image Attacks Explained

This document provides a high-level overview of three distinct "model-free" adversarial image attacks: **FigStep**, **MML**, and **JOOD**. These attacks are designed to bypass the safety guardrails of Vision-Language Models (VLMs) by manipulating images in ways that are easily understood by humans or OCR (Optical Character Recognition) systems, but confusing to the underlying safety filters of the AI.

---

## 1. FigStep (Typography/Step-by-Step Injection)

**How it works:**
FigStep exploits the fact that VLMs are increasingly good at reading text embedded within images (OCR capability). It takes a harmful or restricted text prompt (e.g., "How to build a bomb") and converts it into a sequence of steps written explicitly onto an image using basic typography. 

To the model's safety filter, the input might just look like a picture of some text rather than a direct, malicious text query. However, the VLM's vision encoder reads the text from the image, processes the semantic meaning, and often bypasses its own text-based safety moderation because the malicious payload was delivered visually rather than via the standard text chat interface.

**Why it's effective:**
It creates a modality gap. Text safety filters are highly tuned, but visual safety filters often struggle to holistically evaluate the semantic danger of text that is rendered as an image of step-by-step instructions.

---

## 2. MML (Multilingual Modality Mapping / Visual Scrambling)

**How it works:**
Similar to FigStep, MML attempts to smuggle harmful text past the safety filters by turning it into an image. However, MML intentionally obscures or translates the text to make it even harder for simple guardrails to detect, while still remaining readable to a powerful VLM.

MML typically applies one of several transformations to the text before rendering it as an image:
*   **Word Replacement:** Swaps out heavily moderated keywords (like "bomb" or "steal") with seemingly innocuous nouns or adjectives, relying on the surrounding context to trick the VLM into inferring the true meaning.
*   **Geometric Transformations:** Renders the text upside down (rotation) or flips it horizontally (mirroring). 
*   **Encoding:** Converts the text into Base64 format and renders that exact Base64 string into the image.

**Why it's effective:**
Robust VLMs have learned to understand rotated text and decode Base64 strings to be helpful. MML exploits this helpfulness. By forcing the model to perform a complex visual decoding task (like reading mirrored text), the model focuses its attention on solving the visual puzzle, which often completely derails the secondary task of safety filtering.

---

## 3. JOOD (Jailbreak Out-Of-Distribution / Image Mixing)

**How it works:**
Unlike FigStep and MML, which focus on text-to-image typography, JOOD is a purely visual attack that works by mathematically overlapping two different images:
1.  A **Harmful Image** (e.g., a picture depicting violence or illegal acts).
2.  A **Harmless Image** (e.g., a picture of a cat, a landscape, or a completely blank background).

JOOD uses classical computer vision augmentation techniques like **MixUp** (blending the pixels of both images together at a certain transparency level) or **CutMix** (cutting patches of the harmful image and pasting them into the harmless image).

**Why it's effective:**
AI Vision Models are trained on distinct, clear images (In-Distribution). A blended image combining a weapon and a cat is highly unusual and falls "Out-Of-Distribution" (OOD). The visual encoder of the VLM gets mathematically confused by the overlapping pixels. It often identifies the harmless elements (the cat) and fails to trigger the safety mechanism for the harmful elements, even though a human can still clearly see the restricted content in the blended result.

---

## 4. Heavy Machine Learning / Gradient-Based Attacks

The remaining attacks in OmniSafeBench-MM are far more computationally intensive. Rather than using simple image manipulations (like text overlays or patch blending), these attacks use "white-box" machine learning techniques. 

They work by analyzing the mathematical gradients (the way a neural network learns and processes data) of a specific open-source AI model. By looking under the hood of a "Surrogate Model," the attacker calculates the exact microscopic pixel changes needed to force the AI to misclassify an image or bypass its safety filters. Because many AI models share similar architectures and training data, these carefully calculated pixel changes (Adversarial Noise) often "transfer" and successfully trick completely different, closed-source models (like ChatGPT or Claude). 

These attacks are categorized by the specific open-source AI model they use to calculate their adversarial pixel noise:

### Stable Diffusion Based (`hades`, `himrd`, `qr`)
**How it works:** Instead of adding random static noise, these attacks hijack the generative process of models like Stable Diffusion. They force the image generator to weave malicious, adversarial patterns directly into the structure of an image (e.g., making a QR code or a stylized portrait that naturally contains adversarial pixel arrangements).
**External Model Requirements:** These require downloading external models. You must have the massive pre-trained weights for the specific diffusion model downloaded to your system (e.g., `StableDiffusion3Pipeline` for `qr` and `himrd`, or `PixArtAlphaPipeline` for `hades`), and you need a GPU with sufficient VRAM to run the diffusion generation process.

**How to run locally with downloaded models:**
To run the **`qr`** attack, for example, assuming you have downloaded Stable Diffusion 3 weights locally:
```sh
uv run llmesh run-module mod-multimodal-ai-eval function=security tool=image_attack_preprocessor dataset_path='../data/vrs_bench/VRSBench_EVAL_vqa.json' attack_name=qr num_samples=5 +stable_diffusion_path='/absolute/path/to/local/stable-diffusion-3'
```
**Why it's effective:** To a human, the image just looks like high-quality AI art or a stylized texture. However, the exact color values and edges in the image are mathematically optimized to trigger a severe misinterpretation in a VLM's vision encoder.

### LLaVA / Qwen-VL Based (`si`, `viscra`)
**How it works:** These attacks use modern, highly capable open-source VLMs like LLaVA (Large Language-and-Vision Assistant) or Qwen-VL as their surrogate targets. The attacker feeds a harmful prompt to the surrogate model, calculates how the model's safety filters react, and computationally generates optical noise to cancel out that safety reaction.
**Why it's effective:** Because LLaVA and Qwen-VL are extremely powerful and share architectural similarities with bleeding-edge proprietary models, adversarial noise calculated against them is highly likely to "transfer" and deceive even the smartest commercial VLMs.

**How to run locally with downloaded models:**
If you are on a GPU node and have already downloaded the surrogate models (e.g., `llava-v1.6-mistral-7b-hf` or `Qwen2-VL-7B-Instruct`) to your local file system, you can execute these attacks by pointing the preprocessor directly to your local paths using Hydra config overrides.

To run the **`si`** attack (which uses LLaVA):
```sh
uv run llmesh run-module mod-multimodal-ai-eval function=security tool=image_attack_preprocessor dataset_path='../data/vrs_bench/VRSBench_EVAL_vqa.json' attack_name=si num_samples=5 +target_model_path='/absolute/path/to/your/local/llava-v1.6-mistral-7b-hf'
```

To run the **`viscra`** attack (which uses Qwen2.5-VL):
```sh
uv run llmesh run-module mod-multimodal-ai-eval function=security tool=image_attack_preprocessor dataset_path='../data/vrs_bench/VRSBench_EVAL_vqa.json' attack_name=viscra num_samples=5 +target_model_path='/absolute/path/to/your/local/Qwen2.5-VL-7B-Instruct'
```

*Note on Configuration:*
The `+` sign in front of `+target_model_path` tells the Hydra configuration engine to dynamically inject a new parameter into the attack's configuration schema at runtime, overriding the default behavior (which would otherwise attempt to download the model from the HuggingFace Hub over the internet).
**How it works:** MiniGPT-4 was one of the earliest open-source models to bridge a vision encoder with an advanced language model. These attacks rely on feeding an image into MiniGPT-4 and applying gradient descent (iteratively tweaking the pixels until the model produces the desired, unrestricted output). 
**Why it's effective:** It specifically targets the "alignment gap." It manipulates the image embedding (the mathematical representation of the image) before it reaches the language component, meaning the text-moderation guardrails are entirely blinded to the true, malicious intent of the user.
