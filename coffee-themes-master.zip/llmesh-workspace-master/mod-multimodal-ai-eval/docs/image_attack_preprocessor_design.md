# ImageAttackPreprocessor Design Document

## Objective
Design and implement the `ImageAttackPreprocessor` class within the `mod-multimodal-ai-eval` module. This tool will act as the visual equivalent to the `TextAttackPreprocessor`, generating pixel-manipulated image prompts (such as FigStep and BAP) offline for multimodal dataset evaluations.

## 1. Class Architecture (`src/mod_multimodal_ai_eval/image_attack_preprocessor.py`)
The `ImageAttackPreprocessor` class will inherit from the core `Primitive` class and register its tool definition using the `get_tool_definition()` contract.

### The `run(**kwargs)` Execution Flow
1. **Parameter Extraction:** The method will accept the following parameters (resolved via Hydra):
   - `dataset_path`: The path to the source JSON dataset (e.g., `VRSBench_EVAL_vqa.json`).
   - `attack_name`: The identifier for the attack strategy (e.g., `"figstep"`, `"bap"`).
   - `num_samples`: (Optional) Integer controlling the number of samples to include in the adversarial dataset. If provided (e.g., 10), it randomly samples that many items to perturb.
   - Hyperparameters specific to the generator (e.g., `epsilon`, `steps`, `target_model`).
2. **Dataset Loading:** Load the source JSON dataset. It will use Hydra's `get_original_cwd()` to safely resolve absolute paths regardless of the CLI invocation directory.
3. **Adversarial Generation Loop:** Iterate through the dataset items. For each item:
   - Extract the source image path.
   - Route the image and the target text payload to the corresponding underlying generator (which ports the generation logic from `OmniSafeBench-MM/attacks/` classes).
   - Save the aggressively perturbed image to a dedicated output folder.
4. **Dataset Re-wiring:** Modify the JSON structure so that the `image` key points to the newly generated adversarial image path instead of the clean original image.
5. **Output Delivery:** Save the modified dataset as `[original_dataset_name]_[attack_name].json` and return a successful execution dictionary detailing the `output_file` path.

## 2. Directory Structure and Output Management
To keep the dataset directories organized and prevent evaluation cross-contamination, the preprocessor will enforce a strict, isolated output structure.

- **Perturbed Images:** The perturbed images will be stored alongside the source dataset's directory, inside a newly created folder named after the specific `attack_name`. 
- **JSON Outputs:** The preprocessor will generate **one distinct `.json` file for each attack** execution (rather than merging all attacks into a single file).

### Example Output Structure
If the input dataset is `../data/vrs_bench/VRSBench_EVAL_vqa.json` and the `figstep` attack is executed, the directory will look like this:

```text
data/vrs_bench/
├── VRSBench_EVAL_vqa.json              # Original clean dataset
├── VRSBench_EVAL_vqa_figstep.json      # New dataset routing only to figstep images
├── figstep/                            # Auto-generated folder for figstep perturbed images
│   ├── image_001.png
│   └── ...
```

This structure allows the `inspect_script_runner` to sequentially execute distinct evaluations (e.g., baseline vs. figstep) simply by pointing to the respective JSON file.

## 3. Configuration (`src/mod_multimodal_ai_eval/conf/tool/image_attack_preprocessor.yaml`)
A dedicated Hydra configuration file will manage the preprocessor's parameters and generator hyperparameters by default:

```yaml
# @package _global_
tool: "image_attack_preprocessor"
dataset_path: null
attack_name: "figstep"
num_samples: null # Example: 10

# Attack Generator Hyperparameters
epsilon: 0.1
steps: 10
target_model: "test_model" # Required by attacks like BAP and FigStep to generate gradients
```

### CLI Execution Example
The tool will automatically be available via the LLMesh interface routing:
```bash
llmesh run-module mod-multimodal-ai-eval function=security tool=image_attack_preprocessor dataset_path='...' attack_name='figstep' steps=50 epsilon=0.05
```
