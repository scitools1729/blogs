# Image Attack Fix Ideas and Action Items

This document tracks the identified blockers and required next steps to fully operationalize the `bap` and `cs_dj` image perturbation attacks from `OmniSafeBench-MM` within the `mod-multimodal-ai-eval` module.

## 1. BAP (Blind Adversarial Perturbations)

**Current Status:** Blocked by breaking changes in the `transformers` library architecture.

**Root Cause:**
* The `bap` attack relies on `multimodalmodels.minigpt4.minigpt4_model.MiniGPT4` to compute adversarial gradients.
* The `MiniGPT4` implementation hardcodes references to private, deprecated `transformers` variables, specifically `HybridCache` and `LLAMA_INPUTS_DOCSTRING` inside `transformers.models.llama.modeling_llama`.
* Since `mod-inspectai-eval` requires a modern version of `transformers` (`>=4.45`), these private APIs no longer exist in the shared virtual environment, causing the model lazy-loader to crash.

**Proposed Solutions:**
1. **Virtual Environment Segregation:** Refactor the LLMesh workspace so `OmniSafeBench-MM` and `mod-inspectai-eval` execute in separate Python environments. This would allow `bap` to load an archaic version of `transformers` (e.g., `< 4.40`) without violating the constraints of other modules.
2. **Model Architecture Rewrite:** Manually patch `OmniSafeBench-MM/multimodalmodels/minigpt4/minigpt4/models/base_model.py` and its PEFT integrations to comply with modern `transformers` class structures.

## 2. CS-DJ (Cross-Modal Distraction Jailbreak)

**Current Status:** Codebase is fully patched; currently blocked purely by local hardware/driver constraints.

**Root Cause:**
* The attack is attempting to generate distraction mapping using `sentence-transformers/clip-ViT-B-32`. 
* When it moves the embeddings to the GPU (`.to("cuda")`), PyTorch throws the error: `CUDA error: no kernel image is available for execution on the device`.
* This indicates that the `torch` wheel installed in the WSL environment (e.g., `cu118`) was compiled without support for the physical GPU architecture present on the host machine.

**Proposed Solutions:**
1. **Reinstall PyTorch with Matching CUDA Arch:** Verify the host GPU architecture (e.g., Ampere, Ada Lovelace) and install the officially supported PyTorch wheels. For example: `uv pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121`.
2. **Force CPU Execution:** If GPU execution is not strictly required for development, modify `OmniSafeBench-MM/attacks/cs_dj/attack.py` to hardcode the device to `cpu` rather than dynamically selecting `cuda`.
```python
# In CSDJAttack._ensure_distraction_map
device = torch.device("cpu") # Instead of checking torch.cuda.is_available()
```
