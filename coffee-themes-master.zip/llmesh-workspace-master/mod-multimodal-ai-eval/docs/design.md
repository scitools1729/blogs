# mod-multimodal-ai-eval: Detailed Design Document

## 1. Overview and Purpose
`mod-multimodal-ai-eval` serves as the "Domain Application" layer within the `core-llmesh` ecosystem. Its primary responsibility is to define and facilitate the evaluation of complex multimodal datasets, specifically integrating paradigms from academic benchmarks such as VRSBench and adversarial attack vectors from OmniSafeBench-MM.

In contrast to foundational modules, this module purposefully does **not** contain independent pipeline execution logic. Instead, it vertically depends on the `mod-inspectAI-eval` Execution Engine layer to run its tasks, maintaining a clean separation between "What to Evaluate" (Application Layer) and "How to Execute It" (Engine Layer).

## 2. Architecture
The module strictly adheres to a layered architecture:
- **Inherits from:** `core-llmesh` (Provides the base `Primitive` classes).
- **Depends dynamically on:** `mod-inspectAI-eval` (Provides the execution tools like `inspect_script_runner`). 

### 2.1 Dependency Resolution & Hydra Integration
To allow the local LLMesh CLI to execute tools that do not natively exist within this codebase, the module leverages Hydra `searchpath` injection.
In `src/mod_multimodal_ai_eval/conf/config.yaml`:
```yaml
hydra:
  searchpath:
    - pkg://core_llmesh.conf
    - pkg://mod_inspectAI_eval.conf
```
This elegantly forces the local config builder to query the downstream dependency for tool definitions, allowing a user to run:
`llmesh run-module mod-multimodal-ai-eval tool=inspect_script_runner`

## 3. Dataset Evaluations (Tasks)
The core evaluations are stored in the `/tasks` directory as native `inspect_ai` Task definitions.
- **`tasks/vrs_baseline.py`**: Instantiates a `MemoryDataset` from the standard `.json` dataset, loading images from the standard `Images_val` paths and sending clean prompt evaluations to the model.
- **`tasks/vrs_adversarial.py`**: Simulates an identical pipeline, except it points to a dynamically generated dataset path (e.g. `*_text_adv.json`) that has been previously poisoned by an attack preprocessor.

These scripts do not define their own CLI execution blocks, as they rely entirely on the `inspect_script_runner` primitive to invoke them.

## 4. Primitives (Preprocessors)
While the module relies on `mod-inspectAI-eval` for *online* evaluation execution, it houses its own *offline* dataset manipulation LLMesh Primitives in order to safely experiment with various adversarial attacks against vision-language models.

### 4.1. `text_attack_preprocessor`
**Function:** `security`
- **Purpose:** Mutates the textual prompts within standard JSON datasets.
- **Implementation:** Provides the `deceptive_roleplay_prefix` attack methodology. Given a target `.json` file, it injects an explicit jailbreak prefix into the `question` field of every single data point, saving the result safely to a `_text_adv.json` replica without modifying the ground truth source dataset.

### 4.2. `image_attack_preprocessor` *(Future Work: Phase 3)*
**Function:** `security`
- **Purpose:** A planned primitive designed to integrate the sophisticated visual pixel-manipulation techniques native to `OmniSafeBench-MM` (such as FigStep, BAP, and visual_adv). 

## 5. Development Strategy
When adding new evaluations or benchmarks:
1. Ensure raw datasets are kept external to the module source code (`llmesh-workspace/data/`).
2. Write standard `inspect_ai` `@task` definition files in the `tasks/` directory that point sequentially to the relative data endpoints.
3. Keep the module lightweight. Heavy configuration should be defined at the target level, trusting that `inspect_script_runner` will securely handle API authentication, chunking, and parallelism during its remote invocation process.
