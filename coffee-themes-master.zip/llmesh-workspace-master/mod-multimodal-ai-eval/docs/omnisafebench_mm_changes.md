# OmniSafeBench-MM Integration Changes

This document tracks the specific, low-level modifications successfully made to the `OmniSafeBench-MM/` codebase to integrate it as an engine dependency underneath the `mod-multimodal-ai-eval` module.

The core motivation for these changes was resolving dependency issues (strict pinning in OmniSafeBench-MM preventing resolution with LLMesh's tool abstractions) and fixing runtime syntax/logic errors exposed when triggering generator code programmatically rather than via CLI.

## 1. Dependency Resolution (`pyproject.toml`)

In `OmniSafeBench-MM/pyproject.toml`, two highly-restrictive dependency pins were relaxed to allow `uv` to formulate a compatible resolution graph across the workspace.

### A. Relaxing `transformers`
- **Original Entry:** `"transformers==4.45"`
- **Modified Entry:** `"transformers>=4.45"`
- **Reasoning:** `mod-inspectai-eval` depends heavily on `huggingface-hub`, which mandates a more recent version of the `transformers` library than exactly 4.45. Relaxing this pin allowed a higher, cross-compatible minor version to be chosen.

### B. Relaxing `protobuf`
- **Original Entry:** `"protobuf>=6.33.2"`
- **Modified Entry:** `"protobuf>4.21.5"`
- **Reasoning:** The `core-llmesh` orchestration layer depends on the `tooluniverse` framework. `tooluniverse` intrinsically invokes `google-generativeai` and `google-ai-generativelanguage`, which strictly enforce that `protobuf` must be `<6.0.0.dev0`. Downgrading the floor requirement of protobuf inside OmniSafeBench-MM trivially fixes the impossible resolution graph without breaking the runtime.

## 2. Bug Fixes in Attack Generators

### A. FigStep Syntax Error (`attacks/figstep/attack.py`)
- **Original Code:**
  ```python
  def _get_font(
  def _get_font(
      font_path: Optional[str], size: int
  ) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
  ```
- **Modified Code:**
  ```python
  def _get_font(
      font_path: Optional[str], size: int
  ) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
  ```
- **Reasoning:** A duplicated `def _get_font(` caused an immediate Python `SyntaxError: '(' was never closed`. When programmatic imports attempt to load the module (via `sys.path.append()`), this immediately halts execution. 

### B. FigStep PIL TypeError (`attacks/figstep/attack.py`)
- **Original Code:**
  ```python
  def _get_font(
      font_path: Optional[str], size: int
  ) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
      return ImageFont.truetype(font_path, size)
  ```
- **Modified Code:**
  ```python
  def _get_font(
      font_path: Optional[str], size: int
  ) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
      if not font_path:
          return ImageFont.load_default()
      return ImageFont.truetype(font_path, size)
  ```
### C. CS-DJ Legacy Transformer Imports (`attacks/cs_dj/__init__.py`)
- **Original Code:**
  ```python
  from transformers import AutoModelForCausalLM, AutoTokenizer, HybridCache
  ```
- **Modified Code:**
  ```python
  from transformers import AutoModelForCausalLM, AutoTokenizer
  ```
- **Reasoning:** The `HybridCache` module was fundamentally deprecated and removed in recent `transformers` releases (`>=4.45`). The `cs_dj` plugin blindly imported it but never actually utilized it. Removing the import safely prevented the attack instantiator from crashing.

### D. BAP Model Architecture Constraints (`multimodalmodels/minigpt4/`)
- **Finding:** The `bap` attack programmatically wraps `multimodalmodels.minigpt4.minigpt4_model.MiniGPT4` to process the gradients. However, this model implementation contains deeply-embedded invocations to deprecated, private `transformers` APIs (such as `HybridCache` and `LLAMA_INPUTS_DOCSTRING` inside `transformers.models.llama.modeling_llama`). 
- **Resolution:** These issues are structural to how `minigpt4` interacts with `peft` and `transformers`. Because we upgraded `transformers` to `>=4.45` to unblock `mod-inspectai-eval`, `bap` fundamentally breaks unless the ecosystem is dual-partitioned.

## 3. Secondary Dependency Additions (`pyproject.toml`)

### A. Easing `peft` Pinning
- **Original Entry:** `"peft==0.17.1"`
- **Modified Entry:** `"peft>=0.4.0"`
- **Reasoning:** The strict hold on `peft 0.17.1` within OmniSafeBench-MM forced the environment to use a version of `peft` that contained hard dependency cycles on `HybridCache`. Bumping the floor resolved some internal cache mismatches, though `BAP`'s core issues remain deeper.

### B. Missing `omegaconf` Module
- **Action:** Added `"omegaconf>=2.3.0"` to both the root OmniSafeBench-MM `pyproject.toml` and the `mod-multimodal-ai-eval` module `pyproject.toml`.
- **Reasoning:** While `minigpt4` implicitly requires `omegaconf` underneath, it was missing from the package specification, causing a `ModuleNotFoundError` during standard instantiation under the `uv` virtual environment resolution graph.
