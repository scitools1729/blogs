Create module scaffolding
```bash
llmesh create-module mod-multimodal-ai-eval \
    function=evaluation,security \
    tool=baseline_runner,omni_safe_runner
```

Update mod-multimodal-ai-eval/pyproject.toml
```python
[project]
name = "mod-multimodal-ai-eval"
version = "0.1.0"
description = "Specialized Multimodal AI Safety and Performance Evaluation"
requires-python = ">=3.11"
dependencies = [
    "core-llmesh",
    "mod-inspectAI-eval",
    "omegaconf",
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/mod_multimodal_ai_eval"]

[tool.uv.sources]
core-llmesh = { workspace = true }
mod-inspectAI-eval = { workspace = true }
```

Configure Hydra for Swappable Datasets
```bash
mkdir -p mod-multimodal-ai-eval/src/mod_multimodal_ai_eval/conf/dataset
```
Add `vrs_bench.yaml` to that directory:
```yaml
# @package _global_
dataset_name: "vrs_bench"
dataset_path: "path/to/vrs_bench_task.py"
limit: 100
```

Update the Hydra main config: Location: `mod-multimodal-ai-eval/src/mod_multimodal_ai_eval/conf/config.yaml`

Implement the `BaselineRunner`: Location: `mod-multimodal-ai-eval/src/mod_multimodal_ai_eval/baseline_runner.py.py`

Update the Hydra Security Config: Location: `src/mod_multimodal_ai_eval/conf/function/evaluation.yaml`

Implementation: `omni_safe_runner.py`: Location: `mod-multimodal-ai-eval/src/mod_multimodal_ai_eval/omni_safe_runner.py`

Update the Hydra Security Config: Location: `src/mod_multimodal_ai_eval/conf/function/security.yaml`

Pytest Implementation: Create a file at `mod-multimodal-ai-eval/tests/test_multimodal_delegation.py`

Pytest Implementation: Create a file at `mod-multimodal-ai-eval/tests/test_omni_safe_delegation.py`

Rebuild llmesh-workspace
```bash
rm -rf .venv
rm uv.lock
rm pyproject.toml
llmesh build .
```
Append the following to pyproject.toml
```python
[dependency-groups]
dev = [
    "pytest>=9.0.2",
]

[tool.pytest.ini_options]
pythonpath = [
  "core-llmesh/src",
  "mod-inspectAI-eval/src",
  "mod-multimodal-ai-eval/src"
]
addopts = "--import-mode=importlib"
```

```bash
uv sync --all-packages
uv run pytest
```

Creating the Task Bridge for `vrs_bench_task.py`: Location: mod-multimodal-ai-eval/tasks/vrs_bench_task.py

Download dataset VRSBench from Hugging face and structure it like so:
```bash
mod-multimodal-ai-eval/
└── data/
    └── vrs_bench
        ├── Annotations_val
        ├── Images_val
        ├── Annotations_val.zip
        ├── Images_val.zip
        ├── README.md
        ├── VRSBench_EVAL_Cap.json
        ├── VRSBench_EVAL_referring.json
        └── VRSBench_EVAL_vqa.json
```

Run module
```bash
# without using llmesh
uv run inspect \
  eval \
  mod-multimodal-ai-eval/tasks/vrs_bench_task.py@vrs_bench \
  --model google/gemini-3-flash-preview \
  --limit 2

# with llmesh
llmesh run-module mod-multimodal-ai-eval \
    function=evaluation \
    tool=baseline_runner \
    target_id=google/gemini-3-flash-preview \
    '+args="--task tasks/vrs_bench_task.py@vrs_bench -T dataset_path=data/vrs_bench --model google/gemini-3-flash-preview --limit 2 "'
```

```bash
llmesh run-module mod-multimodal-ai-eval \
    function=security \
    tool=omni_safe_runner \
    target_id=google/gemini-3-flash-preview \
    '+args="--task tasks/vrs_bench_task.py@vrs_bench \
    -T dataset_path=data/vrs_bench \
    --model google/gemini-3-flash-preview \
    --limit 2"'
```

View results
```bash
uv run inspect view start --log-dir mod-multimodal-ai-eval/outputs/2026-03-07/12-17-54
```