# Implementation Plan: mod-multimodal-ai-eval

This document consolidates the phased implementation strategy for the `mod-multimodal-ai-eval` module, which serves as a domain-specific application layer for multimodal dataset evaluations while utilizing `mod-inspectAI-eval` for its execution engine.

## Phase 1: Foundation and Text Attack Preprocessing

### 1. Scaffold New Module
Initialize the core structure using the internal CLI:
```bash
llmesh create-module mod-multimodal-ai-eval function=security tool=multimodal_evaluator
```

### 2. Relocate VRSBench Scripts
Move VRSBench specific evaluation files from the execution engine layer into this application layer:
- `mod-multimodal-ai-eval/tasks/vrs_adversarial.py`
- `mod-multimodal-ai-eval/tasks/vrs_baseline.py`

### 3. Create `text_attack_preprocessor` Tool
Create `src/mod_multimodal_ai_eval/text_attack_preprocessor.py` containing the `TextAttackPreprocessor(Primitive)` class to handle offline string-based prompt injections (e.g., `deceptive_roleplay_prefix`).

**Configuration**: `src/mod_multimodal_ai_eval/conf/tool/text_attack_preprocessor.yaml`
```yaml
# @package _global_
tool: "text_attack_preprocessor"
dataset_path: null
attack_name: "deceptive_roleplay_prefix"
```

## Phase 2: Layered Restructuring

To maximize reusability, we implement a strict **Layered Architecture**. The goal is for this module to strictly be a domain application layer without duplicating engine logic.

### 1. Fix Dependencies
Replace redundant dependencies (`core-llmesh`, `hydra-core`, `omegaconf`, `inspect_ai`) in `pyproject.toml` with a single, explicit workspace dependency:
```toml
dependencies = ["mod-inspectAI-eval"]
```
The Python package manager (`uv`) will automatically resolve the rest transitively.

### 2. Remove Redundant Wrappers
Delete the initial duplicate `multimodal_evaluator` generic tool wrapper and its configs, as it duplicates the `inspect_script_runner` logic from Layer 2.

### 3. Update Configuration Searchpaths
Inject `pkg://mod_inspectAI_eval.conf` into the `searchpath` of the module's `config.yaml` to allow Hydra to discover and instantiate execution tools from the lower layer.

## Phase 3: Image Attack Preprocessor 

Following the integration of textual attacks, build the visual equivalent porting from OmniSafeBench-MM.

### 1. Create `image_attack_preprocessor` Tool
Create `src/mod_multimodal_ai_eval/image_attack_preprocessor.py`. 
Define `ImageAttackPreprocessor(Primitive)` containing generation logic for pixel-manipulated image prompts (FigStep, BAP, etc).

### 2. Hydra Configuration
Create `src/mod_multimodal_ai_eval/conf/tool/image_attack_preprocessor.yaml` with required rendering parameters (`epsilon`, `steps`, `target_model`).

## Verification Plan

1. **Preprocessor Verification**: Execute `llmesh run-module ... tool=text_attack_preprocessor ...` using the CLI and verify the adversarial JSON is generated.
2. **Build Resolution**: Execute the `llmesh build` pipeline to ensure the single dependency on `mod-inspectAI-eval` resolves correctly.
3. **Layered Execution (Adversarial)**: Execute the evaluation using the parent layer's `inspect_script_runner` tool:
```bash
llmesh run-module mod-multimodal-ai-eval function=security tool=inspect_script_runner tasks='tasks/vrs_adversarial.py' target_id='mockllm/model' limit=1
```
4. **Layered Execution (Baseline)**: Execute the baseline evaluation:
```bash
llmesh run-module mod-multimodal-ai-eval function=security tool=inspect_script_runner tasks='tasks/vrs_baseline.py' target_id='mockllm/model' limit=1
```
Success is defined by the commands executing perfectly against the mock model using the Layer 2 tool, proving the vertical decoupling is correct.
