from inspect_ai import Task, task
from inspect_ai.dataset import Sample
from inspect_ai.solver import generate
from inspect_ai.scorer import includes

@task
def test_task():
    return Task(
        dataset=[Sample(input="Is InspectAI working?", target="working")],
        solver=[generate()],
        scorer=includes()
    )
