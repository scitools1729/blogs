import pytest
from unittest.mock import patch, MagicMock
import os
from mod_inspectAI_eval.inspect_registry_runner import InspectRegistryRunner
from mod_inspectAI_eval.inspect_script_runner import InspectScriptRunner

@patch("subprocess.Popen")
def test_benchmark_parameter_translation(mock_popen):
    """Verifies that generic arguments are correctly mapped to 'inspect eval' flags."""
    # Setup mock process
    mock_process = MagicMock()
    mock_process.stdout = []
    mock_process.returncode = 0
    mock_popen.return_value = mock_process

    runner = InspectRegistryRunner()
    kwargs = {
        "tasks": "mmlu",
        "target_id": "openai/gpt-4o",
        "limit": 5,
        "task_args": {"fewshot": 3}
    }

    runner.run(**kwargs)

    # Capture the command passed to Popen
    called_cmd = mock_popen.call_args[1]['args'] if 'args' in mock_popen.call_args[1] else mock_popen.call_args[0][0]
    
    # Assertions for CLI command structure [cite: 545, 546]
    assert "inspect" in called_cmd
    assert "eval" in called_cmd
    assert "mmlu" in called_cmd
    assert "--limit" in called_cmd
    assert "5" in called_cmd
    assert "-T" in called_cmd
    assert "fewshot=3" in called_cmd

@patch("subprocess.Popen")
def test_environment_variable_injection(mock_popen):
    """Verifies that API keys and base URLs are correctly injected into the environment."""
    mock_process = MagicMock()
    mock_process.stdout = []
    mock_process.returncode = 0
    mock_popen.return_value = mock_process

    runner = InspectScriptRunner()
    kwargs = {
        "tasks": "security_test.py",
        "target_id": "openai/custom-model",
        "api_base_url": "http://localhost:8080/v1",
        "api_key": "sk-test-key"
    }

    runner.run(**kwargs)

    # Check the env dictionary passed to Popen [cite: 601, 605]
    called_env = mock_popen.call_args[1]['env']
    assert called_env["OPENAI_BASE_URL"] == "http://localhost:8080/v1"
    assert called_env["OPENAI_API_KEY"] == "sk-test-key"

@patch("subprocess.check_call")
def test_dashboard_command_logic(mock_check_call):
    """Verifies the dashboard runner targets the correct log directory and port."""
    from mod_inspectAI_eval.inspect_dashboard import InspectDashboard

    runner = InspectDashboard()
    # Mocking os.path.exists to true so the test doesn't fail on missing dir
    with patch("os.path.exists", return_value=True):
        runner.run(log_dir="/fake/logs", port=9000)

    called_cmd = mock_check_call.call_args[0][0]
    # Remove the [cite: 633] tag from the line below
    assert called_cmd == ["inspect", "view", "start", "--log-dir", "/fake/logs", "--port", "9000"]