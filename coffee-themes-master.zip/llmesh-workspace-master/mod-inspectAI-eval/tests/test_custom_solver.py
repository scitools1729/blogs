from inspect_ai import Task, task
from inspect_ai.dataset import Sample
from inspect_ai.solver import generate, solver
from inspect_ai.scorer import includes

from inspect_ai.model import ChatMessageSystem

@solver
def system_override():
    """Custom solver that modifies the system prompt before generation."""
    async def solve(state, generate):
        state.messages.insert(0, ChatMessageSystem(content="You are a test agent."))
        return state
    return solve

@task
def test_custom_pipeline():
    return Task(
        dataset=[Sample(input="Just say 'working'", target="working")],
        solver=[system_override(), generate()],
        scorer=includes()
    )
