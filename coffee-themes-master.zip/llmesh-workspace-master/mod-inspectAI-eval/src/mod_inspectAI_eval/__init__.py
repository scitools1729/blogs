from core_llmesh import Primitive

from .inspect_registry_runner import InspectRegistryRunner
Primitive.add(InspectRegistryRunner())

from .inspect_script_runner import InspectScriptRunner
Primitive.add(InspectScriptRunner())

from .inspect_dashboard import InspectDashboard
Primitive.add(InspectDashboard())
