"""
InspectAI Dashboard Viewer implementation.
Wraps the `inspect view` tool to open a local HTTP server exposing the `.eval` logs.
"""
import os
import subprocess
from dataclasses import dataclass
from core_llmesh import Primitive

@dataclass
class InspectDashboard(Primitive):
    """
    Primitive for starting the InspectAI web UI to visualize `.eval` logs.
    """
    name: str = "inspect_dashboard"

    def __init__(self):
        super().__init__(self.name)

    def run(self, **kwargs):
        log_dir = kwargs.get("log_dir")
        port = kwargs.get("port", 7575)
        
        # If no explicit log_dir provided, look in the current working directory,
        # or fall back to resolving Hydra's output dir if invoked inside a pipeline.
        if not log_dir:
            try:
                from hydra.core.hydra_config import HydraConfig
                log_dir = HydraConfig.get().runtime.output_dir
            except Exception:
                log_dir = os.getcwd()

        # FIX: Ensure we have the absolute path before the check 
        log_dir = os.path.abspath(log_dir)
        assert os.path.exists(log_dir)

        if not os.path.exists(log_dir):
            return {"status": "error", "message": f"Log directory not found: {log_dir}"}

        # 2. Command Construction 
        # Matches: inspect view start --log-dir <dir> --port <port>
        cmd = ["inspect", "view", "start", "--log-dir", log_dir, "--port", str(port)]
        
        print(f"[inspect_dashboard] Starting Inspect Web UI: {' '.join(cmd)}")
        print(f"[inspect_dashboard] Please visit: http://localhost:{port}")
        print(f"[inspect_dashboard] Press Ctrl+C in your terminal to stop the server.")
        
        try:
             # We use check_call here because we want to explicitly block the thread
             # while the dashboard server is alive, otherwise it returns immediately and terminates.
             subprocess.check_call(cmd, universal_newlines=True)
             
             return {
                 "status": "completed",
                 "message": "Dashboard server terminated by user.",
                 "log_dir_viewed": log_dir
             }
             
        except subprocess.CalledProcessError as e:
             return {
                 "status": "error",
                 "message": f"Process exited with {e.returncode}"
             }
        except KeyboardInterrupt:
            print("\n[inspect_dashboard] Shutdown signal received. Exiting.")
            return {
                 "status": "completed",
                 "message": "Dashboard server terminated by user."
            }
        except FileNotFoundError:
             return {
                  "status": "error",
                  "message": "The 'inspect' executable was not found. Please ensure 'inspect_ai' is installed."
             }
        except Exception as e:
            return {
                "status": "error",
                "message": str(e)
            }

    def get_tool_definition(self):
        return {
            "name": self.name,
            "description": "Starts a local InspectAI dashboard web server to visualize `.eval` log outputs. Call this tool after running evaluations to allow the user to visually inspect results, model traces, conversations, and adversarial prompts through a local web UI.",
            "parameters": {
                "type": "object",
                "properties": {
                    "log_dir": {
                        "type": "string",
                        "description": "The absolute path to the directory containing the JSON evaluation log files. This path is returned in the 'log_directory' field of the execution tool's response (e.g., from inspect_script_runner)."
                    },
                    "port": {
                        "type": "integer",
                        "description": "The port number to bind the dashboard server to. Defaults to 7575."
                    }
                }
            }
        }
