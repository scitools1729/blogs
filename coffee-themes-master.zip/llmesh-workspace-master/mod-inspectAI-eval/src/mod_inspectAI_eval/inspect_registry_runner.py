"""
InspectRegistryRunner implementation.
Dedicated to running "Standard" benchmarks registered in the InspectAI ecosystem.
"""
import os
import subprocess
from dataclasses import dataclass
from core_llmesh import Primitive
from rich.console import Console
from collections.abc import Mapping, Iterable

@dataclass
class InspectRegistryRunner(Primitive):
    """
    Primitive for executing standard InspectAI benchmarks from the registry.
    """
    name: str = "inspect_registry_runner"

    def __init__(self):
        super().__init__(self.name)

    def run(self, **kwargs):
        console = Console()
        
        # 1. Parameter Extraction
        tasks = kwargs.get("tasks", [])
        if isinstance(tasks, str):
            tasks = [tasks]
            
        target_id = kwargs.get("target_id")
        limit = kwargs.get("limit")
        max_connections = kwargs.get("max_connections", 10)
        task_args = kwargs.get("task_args", {})
        
        if not tasks:
            return {"status": "error", "message": "'tasks' (registry name) is required."}
        if not target_id:
            return {"status": "error", "message": "'target_id' is required."}

        # Resolve output directory via Hydra
        try:
            from hydra.core.hydra_config import HydraConfig
            output_dir = HydraConfig.get().runtime.output_dir
        except Exception:
            output_dir = os.getcwd()

        # 2. Command Construction
        # Focused purely on registry names (e.g. inspect_evals/mmlu_0_shot)
        cmd = ["inspect", "eval"]
        cmd.extend(tasks)
        cmd.extend(["--model", target_id])
        cmd.extend(["--log-dir", output_dir])
        
        if limit is not None:
             cmd.extend(["--limit", str(limit)])
        if max_connections is not None:
             cmd.extend(["--max-connections", str(max_connections)])
             
        # 3. Handle Task Arguments (e.g., -T subjects=anatomy)
        if task_args and isinstance(task_args, Mapping):
            for k, v in task_args.items():
                # Convert lists [a, b] to "a,b" for the CLI
                val = ",".join(map(str, v)) if isinstance(v, Iterable) and not isinstance(v, str) else str(v)
                cmd.append("-T")
                cmd.append(f"{k}={val}")

        # 3.5 Handle Model Roles (e.g., grader=openai/gpt-4o)
        model_roles = kwargs.get("model_roles", {})
        if model_roles and isinstance(model_roles, Mapping):
            for role_name, model_str in model_roles.items():
                cmd.append("--model-role")
                cmd.append(f"{role_name}={model_str}")

        # 4. Environment and Execution
        env = os.environ.copy()
        console.log(f"[inspect_registry_runner] Executing Registry Task: {' '.join(cmd)}")
        
        try:
            captured_output = []
            with console.status(f"[bold blue]Running {tasks[0]}...", spinner="dots") as status:
                process = subprocess.Popen(
                    cmd, 
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.STDOUT, 
                    universal_newlines=True,
                    bufsize=1,
                    env=env
                )
                
                for line in process.stdout:
                    captured_output.append(line)
                    clean_line = line.strip()
                    if clean_line:
                        # Real-time progress update in status bar
                        status.update(f"[bold blue]inspect: [white]{clean_line[:85]}")
                        
                process.wait()
        
            if process.returncode != 0:
                return {
                    "status": "error", 
                    "message": f"Registry task failed with code {process.returncode}",
                    "stdout": "".join(captured_output)
                }
                
            return {
                "status": "completed",
                "tasks_evaluated": tasks,
                "log_directory": output_dir,
                "stdout": "".join(captured_output)
            }
            
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def get_tool_definition(self):
        return {
            "name": self.name,
            "description": "Executes evaluation tasks from the standard InspectAI benchmark registry (e.g., MMLU, GPQA). Use this tool when you need to evaluate a model against established, publicly registered datasets rather than custom local scripts.",
            "parameters": {
                "type": "object",
                "properties": {
                    "tasks": {
                        "type": ["string", "array"],
                        "description": "The exact name(s) of the registered InspectAI tasks to run, (e.g., 'inspect_evals/mmlu_0_shot')."
                    },
                    "target_id": {
                        "type": "string",
                        "description": "The target model identifier to evaluate (e.g., 'openai/gpt-4o', 'google/gemini-1.5-pro', or 'mockllm/model' for testing)."
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Optional limit on the number of samples to evaluate. Useful for quick tests (e.g., 5 or 10)."
                    },
                    "task_args": {
                        "type": "object",
                        "description": "Optional dictionary of task-specific arguments to pass to the registry task (e.g., {'fewshot': 3})."
                    }
                },
                "required": ["tasks", "target_id"]
            }
        }