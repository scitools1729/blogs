# mod-inspectAI-eval

This module integrates the [InspectAI](https://inspect.ai-safety-institute.org.uk/) framework into the `core-llmesh` ecosystem, providing robust capabilities for adversarial evaluation and agentic testing.

## Overview
It wraps the underlying `inspect eval` and `inspect view` commands as LLMesh primitives, enabling you to launch comprehensive, multi-model evaluation pipelines directly from the LLMesh CLI. Because it runs native Python tasks, this module is specifically configured to support complex, multimodal custom execution blocks (such as routing through `OmniSafeBench-MM` for `VRSBench` attacks).

## Primitives
- `inspect_script_runner`: Function: `security` or `evaluation`. Evaluates raw python files containing Inspect Tasks (e.g. `tests/test_basic_eval.py`).
- `inspect_registry_runner`: Function: `security` or `evaluation`. Evaluates tasks from the Inspect AI registry by name.
- `inspect_dashboard`: Function: `reporting`. Starts the local webserver to inspect `.eval` log outputs.

## Healthchecks
To verify that the module is correctly wired to the LLMesh interface and the underlying `inspect_ai` framework, you can run the provided pipeline healthchecks from the workspace root:

```bash
# Verify the registry runner plumbing (running a built-in Inspect tasks, like mmlu,gsm8k, etc)
llmesh run-module mod-inspectAI-eval \
    function=evaluation \
    tool=inspect_registry_runner \
    tasks='inspect_evals/mmlu_0_shot' \
    target_id='mockllm/model' \
    limit=1

# Verify the script runner plumbing (running a custom python script)
llmesh run-module mod-inspectAI-eval \
    function=evaluation \
    tool=inspect_script_runner \
    tasks='tests/test_basic_eval.py' \
    target_id='mockllm/model' \
    limit=1

# Verify the custom solver plumbing
llmesh run-module mod-inspectAI-eval \
    function=security \
    tool=inspect_script_runner \
    tasks='tests/test_custom_solver.py' \
    target_id='mockllm/' \
    limit=1
```

## Unit testing
```bash
uv run pytest mod-inspectAI-eval/tests/test_decoupled_logic.py
```

## Integration testing
```bash
# integrated into and requires `mod-multimodal-ai-eval`.
# export GOOGLE_API_KEY="..."
llmesh run-module mod-multimodal-ai-eval \
    function=security \
    tool=inspect_script_runner \
    tasks='tasks/vrs_baseline.py' \
    target_id='google/gemini-3-flash-preview' \
    limit=5

# view results
uv run inspect view start --log-dir mod-multimodal-ai-eval/outputs/

# view results using llmesh command
llmesh run-module mod-multimodal-ai-eval \
    function=reporting \
    tool=inspect_dashboard \
    log_dir='outputs/' \
    port=7575
```

*(Note: `mockllm/` is InspectAI's built-in mock endpoint used for testing without requiring real API keys).*
