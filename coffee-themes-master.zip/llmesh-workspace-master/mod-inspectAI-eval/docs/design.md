# mod-inspectAI-eval: Detailed Design Document

## 1. Overview and Purpose
`mod-inspectAI-eval` serves as the foundational "Execution Engine" layer within the `core-llmesh` ecosystem. Its primary responsibility is to seamlessly integrate the [InspectAI](https://inspect.ai-safety-institute.org.uk/) framework by wrapping its native CLI commands (`inspect eval` and `inspect view`) into standardized LLMesh Primitives.

By abstracting the evaluation engine, higher-level domain-specific modules (like `mod-multimodal-ai-eval`) can rely entirely on this module to execute complex evaluation routines, benchmark pipelines, and adversarial red-teaming scenarios without duplicating engine logic.

## 2. Architecture
The module strictly adheres to a layered architecture:
- **Inherits from:** `core-llmesh` (Provides the base `Primitive` class, generic Hydra configuration loading, and CLI routing).
- **Provides services to:** Higher-level application modules (e.g., `mod-multimodal-ai-eval`).

All tools execute as Python subprocesses. This decouples the LLMesh framework's runtime environment from the evaluation task's runtime environment, allowing InspectAI to natively manage its own async connections, retries, and dataset mounting.

## 3. Core Primitives (Tools)
The module exposes three distinct LLMesh Primitives.

### 3.1. `inspect_script_runner`
**Function:** `evaluation` or `security`
- **Purpose:** Executes custom Python scripts containing Inspect `@task` or `@solver` definitions (e.g., `tasks/vrs_baseline.py`).
- **Core Mechanism:** Constructs and executes the command `inspect eval <script_path> --model <target_id> --log-dir <output_dir>`.
- **Environment Management:** Dynamically duplicates the OS environment and injects appropriate API keys based on the model prefix string before spawning the subprocess:
  - `openai/*` -> Injects `OPENAI_API_KEY` and `OPENAI_BASE_URL`.
  - `vllm/*` or `hf/*` -> Injects `HF_TOKEN`.
- **Parameter Translation:** Maps kwargs like `limit`, `max_connections`, and `task_args` dicts directly into CLI flags (e.g. `--limit 5`, `-T fewshot=3`).

### 3.2. `inspect_registry_runner`
**Function:** `evaluation` or `security`
- **Purpose:** Executes standard benchmarks and tasks intrinsically registered within the Inspect ecosystem (e.g., `inspect_evals/mmlu_0_shot`).
- **Core Mechanism:** Similar to the script runner, it constructs the command `inspect eval <registry_name> --model <target_id> --log-dir <output_dir>` but targets the registry string instead of a local file path.
- **Differences:** Does not explicitly manage deep API key injection logic internally, delegating more native trust to Inspect's default environment inheritance.

### 3.3. `inspect_dashboard`
**Function:** `reporting`
- **Purpose:** Spawns a local HTTP server to host the Inspect Web Viewer, allowing users to visually inspect `.eval` json logs, traces, and model behavior.
- **Core Mechanism:** Executes `inspect view start --log-dir <dir> --port <port>` via `subprocess.check_call` to intentionally block the thread and keep the server alive until the user issues a KeyboardInterrupt (`Ctrl+C`).
- **Path Resolution:** Gracefully falls back to resolving the `log_dir` via Hydra's runtime output directory if no explicit path is provided via the LLMesh interface.

## 4. Configuration and Routing
- The module relies on Hydra (`config.yaml`) to map the textual names (e.g., `tool: inspect_script_runner`) to the concrete Python class implementations.
- Subprocesses inherit `HydraConfig.get().runtime.output_dir` dynamically to ensure that all generated `.eval` JSON logs land in LLMesh's strict datestamped `outputs/` hierarchy.

## 5. Testing Strategy
Given the module's nature as an integration wrapper, testing focuses strictly on string compilation and execution decoupling rather than AI behavior.
- **`test_decoupled_logic.py`:** Utilizes `unittest.mock.patch` to intercept all `subprocess.Popen` and `subprocess.check_call` invocations.
- Asserts that parameter inputs (like dictionaries and integers) flawlessly serialize into raw Bash CLI argument arrays (e.g., converting `{'fewshot': 3}` into `['-T', 'fewshot=3']`).
- Asserts that API key tokens are successfully isolated and injected into the subprocess `env` dictionary without polluting the host interpreter environment.
