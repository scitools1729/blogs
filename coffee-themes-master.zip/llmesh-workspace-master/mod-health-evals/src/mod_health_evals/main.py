import hydra
from omegaconf import DictConfig, OmegaConf
from core_llmesh import execute_mesh, setup_cli_environment

@hydra.main(version_base=None, config_path="conf", config_name="config")
def main(cfg: DictConfig):
    import mod_health_evals

    print("--- Hydra Config Structure ---")
    print(OmegaConf.to_yaml(cfg, resolve=True))
    print("------------------------------")
    execute_mesh(cfg)

def cli():
    setup_cli_environment()
    main()

if __name__ == "__main__":
    cli()
