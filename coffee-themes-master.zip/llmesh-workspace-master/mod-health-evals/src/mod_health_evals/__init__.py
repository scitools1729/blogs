from core_llmesh import Primitive
from mod_inspectAI_eval.inspect_registry_runner import InspectRegistryRunner

# Register the reused tool
Primitive.add(InspectRegistryRunner())
