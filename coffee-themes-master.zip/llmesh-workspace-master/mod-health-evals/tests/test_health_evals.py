import pytest
from unittest.mock import MagicMock, patch
from mod_inspectAI_eval.inspect_registry_runner import InspectRegistryRunner
from core_llmesh import Primitive

def test_inspect_registry_runner_registration():
    # Ensure the module is imported to trigger registration
    import mod_health_evals
    # Verify that the runner can be found in the Primitive registry
    # Access registry dictionary directly via the class attribute
    runner = Primitive.registry.get("inspect_registry_runner")
    assert runner is not None
    assert isinstance(runner, InspectRegistryRunner)

def test_get_tool_definition():
    runner = InspectRegistryRunner()
    definition = runner.get_tool_definition()
    assert definition["name"] == "inspect_registry_runner"
    assert "tasks" in definition["parameters"]["properties"]
    assert "target_id" in definition["parameters"]["properties"]

@patch("subprocess.Popen")
def test_inspect_registry_runner_run(mock_popen):
    # Setup mock for subprocess
    mock_process = MagicMock()
    mock_process.stdout = ["evaluating...", "done."]
    mock_process.returncode = 0
    mock_popen.return_value = mock_process
    
    runner = InspectRegistryRunner()
    result = runner.run(
        tasks="inspect_evals/mmlu_0_shot",
        target_id="openai/gpt-4o",
        limit=1
    )
    
    assert result["status"] == "completed"
    assert "inspect_evals/mmlu_0_shot" in result["tasks_evaluated"]
    
    # Verify command construction
    args, _ = mock_popen.call_args
    cmd = args[0]
    assert "inspect" in cmd
    assert "eval" in cmd
    assert "inspect_evals/mmlu_0_shot" in cmd
    assert "--model" in cmd
    assert "openai/gpt-4o" in cmd
    assert "--limit" in cmd
    assert "1" in cmd
