# Creating the `mod-health-evals` Module

This guide provides sequential, runnable bash commands to scaffold and configure the `mod-health-evals` module in the `llmesh-workspace`, reusing the `inspect_registry_runner` tool from `mod-inspectAI-eval` to run medical benchmarks.

## Step 1: Scaffold the Module
Use the LLMesh CLI to generate the boilerplate structure for the new module.

```bash
llmesh create-module mod-health-evals
```

## Step 2: Define Dependencies
Update the `pyproject.toml` of the new module to depend on `mod-inspectAI-eval` and `inspect-evals`.

```bash
cat << 'EOF' > mod-health-evals/pyproject.toml
[project]
name = "mod-health-evals"
version = "0.1.0"
description = "Module for running Health and Medical Benchmarks"
requires-python = ">=3.11"
dependencies = [
    "core-llmesh",
    "hydra-core",
    "omegaconf",
    "mod-inspectAI-eval",
    "inspect-evals>=0.4.0"
]

[build-system]
requires = ["setuptools"]
build-backend = "setuptools.build_meta"

[tool.uv.sources]
core-llmesh = { workspace = true }
mod-inspectAI-eval = { workspace = true }
EOF
```

## Step 3: Register the Tool
Modify the module's initialization to import the `InspectRegistryRunner` primitive so the runtime can discover it.

```bash
cat << 'EOF' > mod-health-evals/src/mod_health_evals/__init__.py
from core_llmesh import Primitive
from mod_inspectAI_eval.inspect_registry_runner import InspectRegistryRunner

# Register the reused tool
Primitive.add(InspectRegistryRunner())
EOF
```

## Step 4: Create Hydra Configurations
Hydra requires configuration files to map the CLI arguments to the tool and function. Create these files in the `conf` directory.

```bash
mkdir -p mod-health-evals/src/mod_health_evals/conf/tool
cat << 'EOF' > mod-health-evals/src/mod_health_evals/conf/tool/inspect_registry_runner.yaml
# @package _global_
tool: "inspect_registry_runner"
EOF

mkdir -p mod-health-evals/src/mod_health_evals/conf/function
cat << 'EOF' > mod-health-evals/src/mod_health_evals/conf/function/evaluation.yaml
# @package _global_
meta:
  module_key: "inspect_registry_runner"
function: "evaluation"
EOF

# Update base config.yaml to declare the parameters
cat << 'EOF' >> mod-health-evals/src/mod_health_evals/conf/config.yaml
tasks: ""
target_id: ""
limit: 1
task_args: {}
model_roles: {}
EOF
```

## Step 5: Configure the Workspace
Add the new module to the workspace members and synchronize dependencies. Because the workspace members list is in the root `llmesh-workspace/pyproject.toml`, we must update it to include the new tool so `uv` builds everything together.

```bash
# Append to the members list if not already present
sed -i 's/members = \[/members = \["mod-health-evals", /' pyproject.toml

# Sync the workspace using uv
uv sync
```

## Step 6: Run the Benchmarks
The module is now fully configured. You can execute any registered health benchmark using standard LLMesh CLI arguments.

**Run PubMedQA:**
```bash
llmesh run-module mod-health-evals \
    function=evaluation \
    tool=inspect_registry_runner \
    tasks='inspect_evals/pubmedqa' \
    target_id='mockllm/model' \
    limit=1
```

**Run HealthBench:**
```bash
llmesh run-module mod-health-evals \
    function=evaluation \
    tool=inspect_registry_runner \
    tasks='inspect_evals/healthbench' \
    target_id='mockllm/model' \
    limit=1
```

**Run ChemBench:**
```bash
llmesh run-module mod-health-evals \
    function=evaluation \
    tool=inspect_registry_runner \
    tasks='inspect_evals/chembench' \
    target_id='mockllm/model' \
    limit=1
```

**Run SOSBench:**
```bash
llmesh run-module mod-health-evals \
    function=evaluation \
    tool=inspect_registry_runner \
    tasks='inspect_evals/sosbench' \
    target_id='mockllm/model' \
    limit=1
```

**Run MedQA:**
```bash
llmesh run-module mod-health-evals \
    function=evaluation \
    tool=inspect_registry_runner \
    tasks='inspect_evals/medqa' \
    target_id='mockllm/model' \
    limit=1
```

### Configuring the Grader Model (LLM-as-a-judge)
Some benchmarks (like SOSBench and HealthBench) utilize an **LLM-as-a-judge** (grader model) to score the responses. By default, they often look for an OpenAI model (like `gpt-4o`). To run these, you either need `OPENAI_API_KEY` exported, or you can configure them to use another model like `google/gemini-3-flash-preview` (assuming you have `GEMINI_API_KEY` exported).

**Configuring HealthBench with Gemini:**
HealthBench accepts a `judge_model` task argument. You can pass it via Hydra overrides (`+task_args.judge_model`):
```bash
llmesh run-module mod-health-evals \
    function=evaluation \
    tool=inspect_registry_runner \
    tasks='inspect_evals/healthbench' \
    target_id='mockllm/model' \
    limit=1 \
    +task_args.judge_model='google/gemini-3-flash-preview'
```

**Configuring SOSBench with Gemini:**
SOSBench hardcodes its judge retrieval for the "grader" role. You can dynamically override it via the `model_roles` configuration map in LLMesh:
```bash
llmesh run-module mod-health-evals \
    function=evaluation \
    tool=inspect_registry_runner \
    tasks='inspect_evals/sosbench' \
    target_id='mockllm/model' \
    limit=1 \
    +model_roles.grader='google/gemini-3-flash-preview'
```

### Using Local Models as Judges (vLLM / Ollama)
If you are running a local LLM to acting as your grader, you can configure Inspect to target your local API endpoint using the provider prefixes (`vllm/`, `ollama/`, or `openai/` for OpenAI-compatible endpoints).

**Example: vLLM (OpenAI Compatible API)**
If you are running vLLM that exposes an OpenAI-compatible server on `localhost:8000`, use the generic `openai/` provider but override the base URL.
*Note: We use the `INSPECT_OPENAI_BASE_URL` environment variable since `inspect_registry_runner` doesn't currently map base URLs dynamically for roles.*
```bash
export INSPECT_OPENAI_BASE_URL="http://localhost:8000/v1"
export OPENAI_API_KEY="dummy_key" # Required by the client even for local

llmesh run-module mod-health-evals \
    function=evaluation \
    tool=inspect_registry_runner \
    tasks='inspect_evals/healthbench' \
    target_id='mockllm/model' \
    limit=1 \
    +task_args.judge_model='openai/meta-llama/Llama-3-70b-instruct'
```

**Example: Ollama**
If you are running Ollama locally, use the `ollama/` prefix:
```bash
llmesh run-module mod-health-evals \
    function=evaluation \
    tool=inspect_registry_runner \
    tasks='inspect_evals/sosbench' \
    target_id='mockllm/model' \
    limit=1 \
    +model_roles.grader='ollama/llama3'
```

### Offline Execution on Cluster Nodes
When running evaluations on compute cluster nodes without internet access, you must cache the benchmark datasets beforehand. Most `inspect_evals` benchmarks download their data from the Hugging Face Hub and cache it in the default Hugging Face cache directory (`~/.cache/huggingface/datasets`).

**To run completely offline:**
1. **Pre-cache:** Run the evaluation command once on an internet-connected node to download and cache the dataset.
2. **Transfer:** If your cluster node doesn't share a home directory with the connected node, copy the `~/.cache/huggingface/` folder to the offline node.
3. **Execute Offline:** Set the `HF_DATASETS_OFFLINE` environment variable to `1` when running your LLMesh command to prevent the Hugging Face library from attempting to check for updates:

```bash
export HF_DATASETS_OFFLINE=1
llmesh run-module mod-health-evals \
    function=evaluation \
    tool=inspect_registry_runner \
    tasks='inspect_evals/sosbench' \
    target_id='mockllm/model' \
    limit=1 \
    +model_roles.grader='ollama/gpt-oss'
```
*Note: Some benchmarks (like `healthbench`) also allow you to manually download the dataset as a JSON file and pass it locally via task arguments: `+task_args.local_path='data/healthbench.jsonl'`.*

## Step 7: View Results
Launch the Inspect dashboard to view the evaluation results securely through the core-llmesh framework. 

Since the evaluations were run from `mod-health-evals`, the results are saved in its `outputs` tracking folder. To view them using the `inspect_dashboard` running from `mod-inspectAI-eval`, we explicitly pass the `log_dir` argument to point to the correct directory:

```bash
llmesh run-module mod-inspectAI-eval \
    function=evaluation \
    tool=inspect_dashboard \
    log_dir="$(pwd)/mod-health-evals/outputs"
```
