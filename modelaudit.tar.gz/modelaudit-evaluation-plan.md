# ModelAudit Evaluation Plan

## 1. Testing Methodology

To rigorously evaluate the efficacy of ModelAudit, we must employ an **Empirical Evaluation Methodology** using a curated, labeled dataset of both benign and malicious machine learning artifacts. Because ModelAudit is a static analysis tool, the testing must focus on its ability to correctly classify file structures without relying on dynamic execution.

### Dataset Construction
A robust evaluation requires a synthetic and real-world hybrid dataset:
* **Benign Dataset (True Negatives):** A diverse collection of highly downloaded, safe models from platforms like HuggingFace. This must span multiple architectures (Transformers, CNNs) and, crucially, multiple file formats (PyTorch `.bin`, SafeTensors, Keras `.h5`, ONNX, TensorFlow SavedModel).
* **Malicious Dataset (True Positives):** A custom-crafted set of "poisoned" models designed to trigger specific vulnerability categories:
    * *Deserialization:* Pickle files containing `os.system`, `subprocess.Popen`, and `eval` payloads.
    * *Graph Manipulation:* Keras models with embedded Lambda layers executing arbitrary code.
    * *Secrets:* Models with hardcoded AWS keys or SSH private keys in their metadata or raw string arrays.
    * *Archival:* Zip-bombs disguised as model weights.

#### Recommended Proxy Datasets (Starting Points)
Since public ML repositories actively delete malware for safety reasons, security researchers often use proxy datasets embedded within the test suites of open-source scanners. To get started immediately, use these existing repositories:
1. **The `protectai/modelscan` Test Fixtures:** (Best overall starting point). By cloning the `protectai/modelscan` GitHub repository, we can access their test suite which contains malicious payloads across multiple formats (Keras `.h5`, TensorFlow `.pb`, and PyTorch `.pkl`) engineered with specific malicious signatures. *Note: To avoid triggering antivirus scanners, this repository does not store raw malware files directly. Instead, we must write a small harness to run their `initialize_pickle_file` and `initialize_data_file` test functions to dynamically generate the dataset to a temporary directory before scanning.*
2. **The `mmaitre314/picklescan` Evaluation Set:** Found in the `tests/` directory of the `picklescan` GitHub repository. It includes scripts and pre-generated `.pkl` files that cover a wide spectrum of evasion techniques (e.g., obfuscated `importlib` dynamic loads). It is excellent for stress-testing ModelAudit's pickle parser.
3. **The `security-pride/MalHug` Research Dataset:** For in-the-wild malware, this academic research repository contains the tooling and links (often pointing to Zenodo archives) to datasets of actual malicious models identified during large-scale scans of Hugging Face.

## 2. Evaluation Design

The evaluation will be structured as an automated pipeline:
1. **Execution:** Run the target scanner (ModelAudit) against the entire dataset in a controlled, isolated environment.
2. **Data Collection:** Log the exit codes, scan duration, and the specific rules/findings triggered for each file.
3. **Format Stratification:** Analyze the results grouped by file format (e.g., how well it detects threats in `.pkl` vs `.h5`). This is critical because static scanners often excel at one format but struggle with others.

## 3. Key Performance Metrics

To shed light on the efficacy of the tool, we will calculate the following standard classification metrics:

* **True Positive Rate (TPR) / Recall:** *The percentage of malicious models successfully caught.* This is the most critical security metric. A low TPR means malware is slipping through.
* **False Positive Rate (FPR):** *The percentage of safe models incorrectly flagged as dangerous.* A high FPR causes alert fatigue and friction in CI/CD pipelines, making the tool unusable in practice.
* **F1-Score:** The harmonic mean of Precision and Recall, providing a single balanced metric for overall accuracy.
* **Time-to-Scan (Latency):** Measured in Megabytes per Second (MB/s). Because models can be massive (tens of gigabytes), a security tool must be performant enough not to bottleneck deployment pipelines.

## 4. Simple Baselines for Comparison

To understand if ModelAudit provides significant value, we must compare its metrics against established baselines:

### Baseline 1: `picklescan` (Format-Specific Baseline)
* **What it is:** `picklescan` is a highly popular, open-source tool developed specifically to evaluate Python pickle files for malicious opcodes.
* **Why use it:** It serves as the gold standard for deserialization attacks. Comparing ModelAudit against `picklescan` on the `.pkl`/`.pt` subset of the dataset will reveal if ModelAudit's pickle parser is equally robust, or if it sacrifices depth for breadth.

### Baseline 2: Standard Antivirus / ClamAV (Naive Baseline)
* **What it is:** A traditional signature-based antivirus scanner.
* **Why use it:** Many enterprise environments rely on standard AV to scan all incoming files. By testing ClamAV against the malicious model dataset, we can vividly demonstrate the "blind spot" traditional security tools have regarding ML-specific formats (like nested pickle opcodes), proving the necessity of an ML-specific tool like ModelAudit.

### Baseline 3: `grep` / Regex (Heuristic Baseline)
* **What it is:** A simple bash script running `strings <model_file> | grep -i "os.system\|subprocess\|AKIA"`.
* **Why use it:** It establishes the absolute minimum bar. If ModelAudit does not significantly outperform a naive regex search (especially on obfuscated payloads or complex binary graphs), its complex parsing engine provides little added value.
