# Phase 1: Limited ModelAudit Evaluation Plan

This document outlines a simplified, Phase 1 evaluation strategy to quickly test ModelAudit's baseline detection capabilities against known malicious artifacts. A more rigorous evaluation (Phase 2) incorporating benign datasets, latency metrics, and baselines will be conducted later.

## Task 1: Dataset Generation
We will utilize two established proxy datasets to provide our "ground truth" malicious models.

1. **`protectai/modelscan` Dataset:**
   - Clone the `protectai/modelscan` GitHub repository.
   - Write a small Python harness script that imports and executes their internal `initialize_pickle_file` and `initialize_data_file` test helper functions.
   - Save these dynamically generated malicious `.pkl`, `.h5`, and `.pb` files to a local `datasets/modelscan_malicious/` directory.
   
2. **`mmaitre314/picklescan` Dataset:**
   - Clone the `mmaitre314/picklescan` GitHub repository.
   - Extract the pre-generated malicious `.pkl` files and scripts located within their `tests/` directory.
   - Copy these artifacts to a local `datasets/picklescan_malicious/` directory.

*Note: In this limited Phase 1 evaluation, we are strictly testing Malicious Datasets (True Positives). Every file scanned in this phase is known to be dangerous.*

## Task 2: Execution
Run the `modelaudit` scanner (using the `modelaudit_scanner` LLMesh primitive we built) against the generated directories:
- Scan all files in `datasets/modelscan_malicious/`
- Scan all files in `datasets/picklescan_malicious/`

Ensure the output format is set to `json` so the findings can be programmatically analyzed.

## Task 3: Measurement & Metrics
Parse the JSON results from Task 2 to measure ModelAudit's basic detection efficacy:

- **Caught (True Positives):** The number of known malicious models where ModelAudit successfully identified a threat and flagged a security issue.
- **Missed (False Negatives):** The number of known malicious models that ModelAudit marked as completely "safe" or failed to flag.
- **Detection Rate:** `Caught / (Caught + Missed) * 100`

By measuring how many it got right versus how many it missed, we establish a baseline True Positive Rate (TPR). This will verify that the core static analysis and rule engines are functioning correctly before we scale up to tracking false alarms (False Positives) and performance latency in Phase 2.
