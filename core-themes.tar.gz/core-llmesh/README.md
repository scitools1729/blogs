# LLMesh

**LLMesh** is a lightweight orchestration framework for executing Python-based tools and workflows. It transforms static "Primitive" classes into automated tools and workflows capable of  execution via CLI, REST APIs, or MCP.

## Features
- **Multi-Interface**: Run workflows via CLI, REST API, or MCP.
- **Hydra Configuration**: robust, hierarchical configuration management.

## Quick Start

### 1. Installation
```bash
cd llmesh
uv sync  # or pip install -e .
```

### 2. Testing the Framework
Run the isolated integration test suite:
```bash
uv sync --all-extras
uv run --extra dev pytest tests/
uv run --with pytest pytest tests/test_cli.py -v
```
---

## Source Code

A brief guide to the core components of the framework.

### `src/llmesh`
- **`main.py`**: The application entry point. Dispatches execution based on `interface_mode` (cli, rest_api, mcp) and initializes Hydra configuration.


### `src/llmesh/serve`
- **`api_runner.py`**: FastAPI implementation that wraps workflow execution in a RESTful POST endpoint (`/workflow/{module_key}`).
- **`mcp_runner.py`**: Model Context Protocol (MCP) server implementation that exposes tools dynamically to MCP clients using `ToolUniverse`.

### `src/llmesh/core`
- **`primitive.py`**: The base class for all workflows. Defines the registry pattern and `get_workflow_definition` contract.
- **`app.py`**: Logic for primary CLI execution and configuration parsing.

### `src/llmesh/conf`
- **`config.yaml`**: Root configuration definitions and global settings.
- **`interface/*.yaml`**: Config groups defining metadata for `cli`, `rest_api`, and `mcp` modes.

### Full test
```bash
mkdir vision-pipeline-app; \
cp -r core-llmesh vision-pipeline-app; \
cd vision-pipeline-app; \
uv tool install --force ./core-llmesh; \
llmesh create-module data-forge function=ingestion,validation tool=s3_loader,sql_query; \
llmesh create-module model-lab function=architecture,optimization tool=pytorch_trainer,hyper_tuner; \
llmesh create-module ops-bridge function=deployment,monitoring tool=onnx_exporter,slack_alert; \
llmesh build .; \
llmesh run-module data-forge function=ingestion tool=s3_loader; \
llmesh run-module data-forge function=ingestion tool=s3_loader,sql_query -m; \
llmesh run-module model-lab function=architecture tool=hyper_tuner,pytorch_trainer -m; \
llmesh run-module ops-bridge function=deployment,monitoring tool=onnx_exporter,slack_alert -m
```