from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn
from core_llmesh import Primitive
from omegaconf import DictConfig, OmegaConf
from typing import Dict, Any

app = FastAPI(title="LLMesh Workflow API")

# Global state to hold the active project configuration
# In a rigorous implementation, this might be handled via dependency injection
SERVER_CONTEXT = {"module_key": None, "base_cfg": None}


class WorkflowRequest(BaseModel):
    # Flexible dict to allow any keys supported by the primitive
    parameters: Dict[str, Any]


@app.post("/workflow/{module_key}")
async def execute_workflow(module_key: str, request: WorkflowRequest):
    """
    Executes the specified workflow project with the provided parameters.
    """
    # 1. Validation
    # Ensure we are running the project intended by the server startup
    # (Or loosen this check if we want a multi-tenant server later)
    active_project = SERVER_CONTEXT.get("module_key")
    if active_project and module_key != active_project:
        # Optional: Allow it if the primitive exists, but warn?
        # For strictness, let's allow any registered primitive,
        # but using the base config started with the server.
        pass

    # 2. Load Primitive
    runner = Primitive.registry.get(module_key)
    if not runner:
        raise HTTPException(
            status_code=404, detail=f"Workflow '{module_key}' not found."
        )

    # 3. Merge Config
    # We take the base config (loaded at startup) and override with parameters
    # This allows CLI args like 'launcher=slurm' (server-side) to persist,
    # while per-request args override logic parameters.
    runtime_args = request.parameters

    # Simple merging strategy:
    # If base_cfg is a DictConfig, we convert to dict and update
    full_config = {}
    if SERVER_CONTEXT["base_cfg"]:
        # Convert OmegaConf to dict container
        full_config = OmegaConf.to_container(SERVER_CONTEXT["base_cfg"], resolve=True)

    full_config.update(runtime_args)

    # 4. Execute
    try:
        print(f"[API] Executing workflow: {module_key} with args: {runtime_args}")
        result = runner.run(**full_config)
        return {"status": "success", "result": result}
    except Exception as e:
        print(f"[API] Error executing workflow: {e}")
        raise HTTPException(status_code=500, detail=str(e))


def start_server(cfg: DictConfig, module_key: str):
    """
    Starts the FastAPI server with Uvicorn.
    """
    SERVER_CONTEXT["module_key"] = module_key
    SERVER_CONTEXT["base_cfg"] = cfg

    print(f"[LLMesh API] Starting REST API for project: {module_key}")
    print(f"[LLMesh API] Endpoint: POST http://localhost:8000/workflow/{module_key}")

    uvicorn.run(app, host="0.0.0.0", port=8000)
