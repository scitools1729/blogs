import argparse
import sys
import os
import subprocess
import re
import keyword
import shutil
from pathlib import Path

def get_uv_binary() -> str:
    """Returns the path to the uv executable."""
    uv_path = shutil.which("uv")
    if not uv_path:
        # Fallback to standard installation paths if not in PATH
        fallback = Path.home() / ".local" / "bin" / "uv"
        if fallback.exists():
            return str(fallback)
        return "uv" # Final fallback, let subprocess handle the error
    return uv_path

def sanitize_str_to_list(input_str: str) -> list[str]:
    """
    Sanitizes a comma-separated or space-separated string into a deduplicated list
    of valid Python identifiers.
    """
    if not input_str:
        return []
    
    # Split by comma or space
    items = [x.strip() for x in re.split(r'[, ]+', input_str) if x.strip()]
    
    sanitized = []
    seen = set()
    
    for item in items:
        # 1. Convert to lowercase and replace hyphens with underscores
        clean_item = item.lower().replace('-', '_')
        # 2. Strip non-alphanumeric chars
        clean_item = re.sub(r'[^a-z0-9_]', '', clean_item)
        
        if not clean_item:
            continue
            
        # 3. Prepend underscore if it starts with a number
        if clean_item[0].isdigit():
            clean_item = f"_{clean_item}"
            
        # 4. Check reserved keywords
        if keyword.iskeyword(clean_item):
            print(f"Warning: '{item}' -> '{clean_item}' is a reserved Python keyword. Suffixing with '_val'.", file=sys.stderr)
            clean_item = f"{clean_item}_val"
            
        # 5. Deduplicate
        if clean_item not in seen:
            sanitized.append(clean_item)
            seen.add(clean_item)
            
    return sanitized

def to_class_name(snake_str: str) -> str:
    """Converts a snake_case string to CamelCase."""
    components = snake_str.split('_')
    return "".join(x.title() for x in components if x)

def scaffold_module(project_name: str, functions: list[str], tools: list[str]):
    """Generates the directory structure and files for the requested project layout."""
    
    # Standardize package name
    pkg_name = project_name.replace('-', '_')
    
    base_dir = Path(project_name).resolve()
    
    # Fail fast if the directory already exists to prevent accidental overwrites
    if base_dir.exists():
        print(f"Error: Directory '{project_name}' already exists. Please choose a different name or delete the existing directory.", file=sys.stderr)
        sys.exit(1)
        
    print(f"Building architecture for {project_name}...")
    src_dir = base_dir / "src" / pkg_name
    
    # 1. Create Directory Hierarchy
    (src_dir / "conf" / "tool").mkdir(parents=True, exist_ok=True)
    (src_dir / "conf" / "function").mkdir(parents=True, exist_ok=True)
    
    # 2. Generate pyproject.toml
    pyproject_content = f"""[project]
name = "{project_name}"
version = "0.1.0"
description = ""
requires-python = ">=3.11"
dependencies = [
    "core-llmesh",
    "hydra-core",
    "omegaconf",
]

[build-system]
requires = ["setuptools"]
build-backend = "setuptools.build_meta"

# TODO: When core-llmesh is published to PyPI or Enterprise GitHub, remove this workspace binding
# and update the dependencies array above.
[tool.uv.sources]
core-llmesh = {{ workspace = true }}
"""
    (base_dir / "pyproject.toml").write_text(pyproject_content)
    
    # 3. Generate main.py
    main_py_content = f"""import hydra
from omegaconf import DictConfig, OmegaConf
from core_llmesh import execute_mesh, setup_cli_environment

@hydra.main(version_base=None, config_path="conf", config_name="config")
def main(cfg: DictConfig):
    import {pkg_name}

    print("--- Hydra Config Structure ---")
    print(OmegaConf.to_yaml(cfg, resolve=True))
    print("------------------------------")
    execute_mesh(cfg)

def cli():
    setup_cli_environment()
    main()

if __name__ == "__main__":
    cli()
"""
    (src_dir / "main.py").write_text(main_py_content)
    
    # 4. Generate config.yaml
    config_yaml_content = """hydra:
  searchpath:
    - pkg://core_llmesh.conf

defaults:
  - _self_
  - interface: cli
  - function: null
  - tool: null

function: null
tool: null
"""
    (src_dir / "conf" / "config.yaml").write_text(config_yaml_content)
    
    # 5. Create Base and Init files
    (base_dir / "README.md").touch()
    (base_dir / "src" / "__init__.py").touch()
    (src_dir / "conf" / "__init__.py").touch()
    (src_dir / "conf" / "tool" / "__init__.py").touch()
    (src_dir / "conf" / "function" / "__init__.py").touch()
    
    # Initialize the package __init__.py and import Primitive
    init_py_path = src_dir / "__init__.py"
    init_py_content = "from core_llmesh import Primitive\n\n"
    
    # 6. Generate Tool Files (.py and .yaml)
    for tool in tools:
        class_name = to_class_name(tool)
        
        # Append import and registration
        init_py_content += f"from .{tool} import {class_name}\nPrimitive.add({class_name}())\n\n"
        
        # tool.py implementation stub
        tool_py_content = f"""from dataclasses import dataclass
from core_llmesh import Primitive

@dataclass
class {class_name}(Primitive):
    name: str = "{tool}"

    def __init__(self):
        super().__init__(self.name)

    def run(self, **kwargs):
        print("----- NOT YET IMPLEMENTED -----")
        print("kwargs: ", kwargs)
        print("tool definition: ", self.get_tool_definition())
        print("----- NOT YET IMPLEMENTED -----")
        return None

    def get_tool_definition(self):
        return {{
            "name": self.name,
            "description": "Dummy tool - not yet implemented",
            "parameters": {{
                "type": "object",
                "properties": {{
                    "dummy_string": {{
                        "type": "string",
                        "description": "A dummy string parameter"
                    }},
                    "dummy_number": {{
                        "type": "number",
                        "description": "A dummy number parameter"
                    }},
                    "dummy_boolean": {{
                        "type": "boolean",
                        "description": "A dummy boolean parameter"
                    }},
                    "dummy_array": {{
                        "type": "array",
                        "items": {{
                            "type": "string"
                        }},
                        "description": "A dummy array of strings"
                    }}
                }},
                "required": ["dummy_string"]
            }}
        }}

if __name__ == "__main__":
    tool = {class_name}()
    print(tool.run())
"""
        (src_dir / f"{tool}.py").write_text(tool_py_content)
        
        # tool.yaml config
        tool_yaml_content = f"""# @package _global_
tool: "{tool}"
"""
        (src_dir / "conf" / "tool" / f"{tool}.yaml").write_text(tool_yaml_content)
        print(f"  + Tool configured: {tool}")

    # Write the dynamically generated __init__.py block containing all the tool imports
    init_py_path.write_text(init_py_content)
    
    # 7. Generate Function Configs (.yaml)
    for func in functions:
        func_yaml_content = """# @package _global_
meta:
  module_key: ${tool}
"""
        (src_dir / "conf" / "function" / f"{func}.yaml").write_text(func_yaml_content)
        print(f"  + Function configured: {func}")
        
    print("---")
    print(f"Project '{project_name}' setup complete.")

def handle_create_module(args):
    """Parses args specifically for the `create-module` command."""
    
    # The user passes input format like `function=ingestion,validation`
    function_str = ""
    tool_str = ""
    
    # Parse K=V kwargs from the variable length args list
    for kv in args.kwargs:
        if kv.startswith("function="):
            function_str = kv.split("=", 1)[1]
        elif kv.startswith("tool="):
            tool_str = kv.split("=", 1)[1]
            
    sanitized_funcs = sanitize_str_to_list(function_str)
    sanitized_tools = sanitize_str_to_list(tool_str)
    
    # If interactive validation needed, we can check lengths/content here
    scaffold_module(args.project_name, sanitized_funcs, sanitized_tools)

def handle_run_module(args, extra_args=None):
    """Executes a component module, automatically delegating virtual env creation via uv."""
    module_name = args.module_name
    pkg_name = module_name.replace("-", "_")
    target_dir = Path(module_name)
    
    if not target_dir.exists() or not target_dir.is_dir():
        print(f"Error: Module directory '{module_name}' not found in current path.", file=sys.stderr)
        sys.exit(1)
        
    main_script = target_dir / "src" / pkg_name / "main.py"
    if not main_script.exists():
        print(f"Error: Module entrypoint not found at {main_script}.", file=sys.stderr)
        sys.exit(1)
        
    # Execute through uv run inside the module directory, utilizing the workspace if it exists
    uv_bin = get_uv_binary()
    extra = extra_args if extra_args else []
    cmd = [uv_bin, "run", "python", f"src/{pkg_name}/main.py"] + args.kwargs + extra
    print(f"Executing: {' '.join(cmd)}")
    try:
        subprocess.run(cmd, cwd=target_dir, check=True)
    except subprocess.CalledProcessError as e:
        print(f"Execution failed with error {e.returncode}", file=sys.stderr)
        sys.exit(e.returncode)

def handle_build(args):
    """Generates a root uv workspace pyproject.toml that binds all scaffolded modules."""
    base_path = Path(args.path).resolve()
    print(f"Scanning for modules in {base_path}...")
    
    # Auto-detect all scaffolded Python package sub-directories
    members = []
    for child in base_path.iterdir():
        if child.is_dir() and (child / "pyproject.toml").exists() and child != base_path:
            members.append(child.name)
            
    if not members:
        print(f"No Python modules found in {base_path} to build a workspace.", file=sys.stderr)
        sys.exit(1)
        
    members_str = ", ".join(f'"{m}"' for m in members)
    workspace_toml = base_path / "pyproject.toml"
    
    if not workspace_toml.exists():
        print(f"Detected modules: {members_str}")
        print("Scaffolding root uv workspace pyproject.toml...")
        content = f"""[project]
name = "{base_path.name}-workspace"
requires-python = ">=3.11"
version = "0.1.0"

[tool.uv.workspace]
members = [{members_str}]
"""
        workspace_toml.write_text(content)
    else:
        print("Root pyproject.toml already exists. Re-syncing framework workspace...")
        
    # Trigger uv sync
    print("Running uv sync across the workspace...")
    uv_bin = get_uv_binary()
    try:
        subprocess.run([uv_bin, "sync"], cwd=base_path, check=True)
        print("Workspace built successfully! All modules share the root .venv.")
    except subprocess.CalledProcessError as e:
        print(f"Workspace build failed: {e}", file=sys.stderr)
        sys.exit(e.returncode)

def main():
    parser = argparse.ArgumentParser(description="LLMesh Core CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)
    
    # 'create-module' subcommand
    create_parser = subparsers.add_parser("create-module", help="Scaffolds a new LLMesh downstream module")
    create_parser.add_argument("project_name", help="Name of the downstream project directory")
    create_parser.add_argument("kwargs", nargs="*", help="Optional overrides, e.g., function=name,name tool=name,name")
    
    # 'run-module' subcommand
    run_parser = subparsers.add_parser("run-module", help="Executes a scaffolded downstream module via uv")
    run_parser.add_argument("module_name", help="Name of the existing module directory to execute")
    run_parser.add_argument("kwargs", nargs="*", help="Optional runtime overrides, e.g., function=name tool=name -m")
    
    # 'build' subcommand
    build_parser = subparsers.add_parser("build", help="Aggregates all modules into a shared runtime uv workspace")
    build_parser.add_argument("path", nargs="?", default=".", help="Directory to initialize the workspace inside (default: current directory)")
    
    args, unknown = parser.parse_known_args()
    
    if args.command == "create-module":
        handle_create_module(args)
    elif args.command == "run-module":
        handle_run_module(args, extra_args=unknown)
    elif args.command == "build":
        handle_build(args)


if __name__ == "__main__":
    main()
