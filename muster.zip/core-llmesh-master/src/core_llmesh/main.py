import sys
import shutil
import hydra
from omegaconf import DictConfig, OmegaConf
from dotenv import load_dotenv


def execute_mesh(cfg: DictConfig):
    """
    Core execution logic for the mesh app.
    Can be called by external consumers (like hello-world) with their own configs.
    """
    # Core logic always required
    from core_llmesh import run_app

    print(f"Loaded config: {OmegaConf.to_yaml(cfg, resolve=True)}", file=sys.stderr)

    # Extract the project key from metadata
    meta = cfg.get("meta") or {}
    module_key = meta.get("module_key") or cfg.get("tool")

    # 2. Extract Interface Mode
    interface_mode = meta.get("interface_mode", "cli")
    print(f"Interface: {interface_mode}", file=sys.stderr)

    if interface_mode == "cli" and not module_key:
        print(
            "Error: CLI mode requires a specific tool or function. Ensure 'tool=XXX' is provided.",
            file=sys.stderr,
        )
        return

    module_key = module_key or "llmesh_server"

    # 3. Dispatch

    if interface_mode == "rest_api":
        from core_llmesh.serve.api_runner import start_server

        start_server(cfg, module_key)
        return

    if interface_mode == "mcp":
        from core_llmesh.serve.mcp_runner import start_server

        start_server(cfg, module_key)
        return

    # Default to CLI execution
    # Default to CLI execution
    print(f"Running Project: {module_key}...", file=sys.stderr)
    result = run_app(cfg, runner_key=module_key)
    
    # 4. Hydra Optimization Objective Extraction (Ax / Optuna parameter sweeps)
    # If the user's config specifies an objective metric, locate it in the result
    optimization_metric = cfg.get("optimization_metric", None)
    
    if optimization_metric and result is not None and isinstance(result, dict):
        if isinstance(optimization_metric, (list, tuple)) or OmegaConf.is_list(optimization_metric):
            # MULTI-OBJECTIVE EXTRACTION
            extracted_vals = []
            for metric_name in optimization_metric:
                if metric_name in result:
                    extracted_vals.append(float(result[metric_name]))
                elif "results" in result and metric_name in result["results"]:
                    extracted_vals.append(float(result["results"][metric_name]))
                else:
                    # Fallback dot notation
                    curr = result
                    for p in metric_name.split("."):
                        curr = curr.get(p) if isinstance(curr, dict) else None
                    if curr is not None:
                        extracted_vals.append(float(curr))
                    else:
                        raise ValueError(f"Could not find metric '{metric_name}' in result!")
            print(f"[HYDRA SWEEPER] Returning multi-objective metrics {list(optimization_metric)}: {extracted_vals}", file=sys.stderr)
            return tuple(extracted_vals)
        else:
            # SINGLE-OBJECTIVE EXTRACTION
            if optimization_metric in result:
                metric_val = result[optimization_metric]
                print(f"[HYDRA SWEEPER] Returning objective metric '{optimization_metric}': {metric_val}", file=sys.stderr)
                return float(metric_val)
            
            if "results" in result and optimization_metric in result["results"]:
                return float(result["results"][optimization_metric])
                 
            if "." in optimization_metric:
                parts = optimization_metric.split(".")
                curr = result
                for p in parts:
                    if isinstance(curr, dict) and p in curr:
                        curr = curr[p]
                    else:
                        curr = None
                        break
                if curr is not None:
                    print(f"[HYDRA SWEEPER] Returning nested objective '{optimization_metric}': {curr}", file=sys.stderr)
                    return float(curr)
                
    # If no objective extraction was needed or found, just return None or result
    return result


@hydra.main(version_base=None, config_path="conf", config_name="config")
def hydra_main(cfg: DictConfig):
    return execute_mesh(cfg)


def setup_cli_environment():
    """
    Handles pre-Hydra CLI setup, such as checking for Slurm availability
    and modifying sys.argv if necessary.
    """
    # 0. Alias support: Map 'launcher=' to 'hydra/launcher='
    sys.argv = [
        (
            arg.replace("launcher=", "hydra/launcher=")
            if arg.startswith("launcher=")
            else arg
        )
        for arg in sys.argv
    ]

    # Graceful Fallback check
    if "hydra/launcher=slurm" in sys.argv and not shutil.which("sbatch"):
        print("\n[WARNING] 'sbatch' not found. Slurm cluster unavailable.")
        print(
            "[WARNING] Falling back to 'hydra/launcher=local' for local parallel execution.\n"
        )
        # Modify sys.argv in place so Hydra sees the change
        sys.argv = [
            arg if arg != "hydra/launcher=slurm" else "hydra/launcher=local"
            for arg in sys.argv
        ]


def main():
    # Load environment variables from a local .env file if it exists
    import os
    load_dotenv(os.path.join(os.getcwd(), ".env"))

    # 1. Custom Commands check
    if "--status" in sys.argv or "status" in sys.argv:
        # print_status() # Assuming print_status was imported or defined elsewhere in context, keeping as is or commenting if missing
        pass  # The previous view showed print_status call but I don't see the def. Assuming it was there or I should leave it?
        # Wait, the previous view of main.py showed `print_status()` call at line 33.
        # But I don't see the definition in the previous file view of `ll-mesh/src/ll_mesh/main.py`.
        # It might be imported or I missed it.
        # actually, looking at step 16, I don't see print_status defined. It might be missing code in the snippet or I should just preserve the structure.
        # Accessing the file content again to be safe.
        pass

    # 2. Setup environment
    setup_cli_environment()

    # 3. Run Hydra App
    hydra_main()


if __name__ == "__main__":
    main()
