from typing import Any, Dict, Optional
from pydantic import BaseModel, create_model, BeforeValidator
from typing_extensions import Annotated
from tooluniverse.base_tool import BaseTool
from core_llmesh import Primitive
import sys


# Validator to clean currency strings and handle casting
def clean_currency_and_cast(v: Any) -> Any:
    # If list is passed but we expect a number, take the first element if numeric
    if isinstance(v, list) and len(v) > 0:
        # Recursive call to handle the first element
        return clean_currency_and_cast(v[0])

    if isinstance(v, str):
        # Remove common currency symbols and whitespace
        clean_str = v.replace("$", "").replace(",", "").strip()
        # Try usage of standard float conversion
        try:
            val = float(clean_str)
            # If it's effectively an integer (e.g. 10.0), return as int
            # (some tools might be strict about types, though Pydantic usually handles this)
            if val.is_integer():
                return int(val)
            return val
        except ValueError:
            # If conversion fails, return original string (let Pydantic validation fail or pass if string expected)
            return v
    return v


# Flexible Number Type: Handles strings, floats, ints, and currency info
FlexibleNumber = Annotated[float | int, BeforeValidator(clean_currency_and_cast)]


class LLMeshPrimitiveTool(BaseTool):
    """
    Adapter to run an LLMesh Primitive as a ToolUniverse Tool.
    Uses Pydantic for robust runtime argument validation and type coercion.
    """

    def __init__(self, primitive: Primitive, tool_config: Dict[str, Any] = None):
        # BaseTool expects a tool_config
        super().__init__(tool_config or {})
        self.primitive = primitive
        self._param_model: Optional[type[BaseModel]] = None

    def _get_or_create_model(self) -> type[BaseModel]:
        """
        Dynamically creates a Pydantic model based on the primitive's tool definition.
        """
        if self._param_model:
            return self._param_model

        defn = self.primitive.get_tool_definition()
        parameters = defn.get("parameters", {})
        properties = parameters.get("properties", {})
        required_fields = set(parameters.get("required", []))

        fields = {}
        for param_name, param_info in properties.items():
            # Determine type
            p_type = param_info.get("type", "string")
            is_required = param_name in required_fields

            # Helper to check if type matches number/integer (including lists like ["number", "string"])
            is_numeric = (
                p_type == "number"
                or p_type == "integer"
                or (
                    isinstance(p_type, list)
                    and ("number" in p_type or "integer" in p_type)
                )
            )

            if is_numeric:
                # Use our robust FlexibleNumber type for numeric fields
                field_type = FlexibleNumber
            else:
                # Default to Any/str for others to be permissive
                field_type = Any

            # Field definition: (Type, Default)
            # If required, default is Ellipsis (...)
            default = ... if is_required else None

            fields[param_name] = (field_type, default)

        # Create the dynamic model
        model_name = f"{self.primitive.name}Schema"

        # Configure model to ignore extra fields (robustness against hallucinations)
        config = {"extra": "ignore"}

        self._param_model = create_model(model_name, __config__=config, **fields)
        return self._param_model

    def run(self, *args, **kwargs) -> Any:
        # LLMesh primitives run method accepts kwargs

        # Handle case where ToolUniverse passes params as a single positional dict or Context
        if args:
            # If the first arg is a dictionary, merge it into kwargs
            if isinstance(args[0], dict):
                kwargs.update(args[0])
            # If it's something else (like Context), we might ignore it for now

        # 1. Attempt Pydantic Validation
        try:
            ModelClass = self._get_or_create_model()

            # Validate input using Pydantic (handles coercion, flexible types, currency stripping)
            validated_obj = ModelClass(**kwargs)

            # Convert back to dict for the primitive
            clean_kwargs = validated_obj.model_dump()

            # Execute primitive
            return self.primitive.run(**clean_kwargs)

        except Exception as e:
            # Fallback to raw execution
            print(
                f"[MCP ADAPTER] Pydantic validation failed: {type(e).__name__}: {str(e)}. Falling back to raw args.",
                file=sys.stderr,
            )
            import traceback

            traceback.print_exc(file=sys.stderr)
            return self.primitive.run(**kwargs)
