import sys
import logging
from typing import Any, Dict
from core_llmesh import Primitive
from omegaconf import DictConfig
from tooluniverse.smcp import SMCP
from tooluniverse.execute_function import ToolUniverse
from .tooluniverse_adapter import LLMeshPrimitiveTool


def start_server(cfg: DictConfig, module_key: str):
    # Redirect all logging to stderr to keep stdout clean for stdio transport
    logging.basicConfig(
        stream=sys.stderr, level=logging.INFO, format="[MCP RUNNER] %(message)s"
    )
    logger = logging.getLogger("MCP_RUNNER")
    logger.warning("Initializing ToolUniverse...")
    print("[MCP RUNNER] Initializing ToolUniverse...", file=sys.stderr, flush=True)

    # Initialize empty ToolUniverse
    tu = ToolUniverse(tool_files={}, keep_default_tools=False)

    tool_count = 0
    logger.warning("Registering LLMesh primitives...")

    def relax_schema_types(schema: Dict[str, Any]) -> Dict[str, Any]:
        """
        Recursively modifies JSON schema to allow strings for numbers/integers,
        enabling the Pydantic adapter to handle casting.
        """
        if not isinstance(schema, dict):
            return schema

        new_schema = schema.copy()

        # If type is strictly number/integer, relax it to allow string and pass validation
        # ToolUniverse expects a hashable type (str) for its internal mapping, so we cannot use a list.
        # We rely on our Pydantic adapter to cast "string" back to number/int.
        if "type" in new_schema:
            t = new_schema["type"]
            if t == "number" or t == "integer":
                new_schema["type"] = "string"
            elif isinstance(t, list):
                if "number" in t or "integer" in t:
                    new_schema["type"] = "string"

        # Recurse into properties and items
        if "properties" in new_schema:
            new_schema["properties"] = {
                k: relax_schema_types(v) for k, v in new_schema["properties"].items()
            }
        if "items" in new_schema:
            new_schema["items"] = relax_schema_types(new_schema["items"])

        return new_schema

    for name, primitive in Primitive.registry.items():
        # Only register atomic tools, not workflows (unless they are explicitly marked)
        if primitive.get_state_graph() is None:
            try:
                # 1. Get definition
                defn = primitive.get_tool_definition()

                # RECOVERY FIX: Relax the schema so FastMCP doesn't reject strings before they reach our adapter
                raw_params = defn.get("parameters", {})
                relaxed_params = relax_schema_types(raw_params)

                # 2. Convert to ToolUniverse config format
                # ToolUniverse expects 'parameter' instead of 'parameters'
                tool_config = {
                    "name": defn.get("name", primitive.name),
                    "description": defn.get("description", primitive.description),
                    "parameter": relaxed_params,
                    "type": "LLMeshPrimitive",
                    "category": "llmesh",
                }

                # 3. Create adapter instance
                adapter = LLMeshPrimitiveTool(primitive, tool_config)

                # 4. Register with ToolUniverse
                tu.register_custom_tool(
                    tool_class=LLMeshPrimitiveTool,
                    tool_instance=adapter,
                    tool_config=tool_config,
                    tool_name=tool_config["name"],
                )

                logger.warning(f"Registered tool: {tool_config['name']}")
                tool_count += 1
            except Exception as e:
                logger.error(f"Failed to register tool {name}: {e}")

    logger.warning(f"Registered {tool_count} tools")

    # Initialize SMCP Server
    server_name = cfg.get("mcp_server_name", module_key) or module_key

    # SMCP options
    transport = cfg.get("mcp_transport", "stdio")
    port = cfg.get("mcp_port", 8000)

    server = SMCP(
        name=server_name,
        tooluniverse_config=tu,
        auto_expose_tools=True,
        search_enabled=False,  # Disable search to prevent agent distraction
    )

    if transport == "sse":
        print(f"[MCP RUNNER] Starting SSE server on port {port}", file=sys.stderr)
        server.run_simple(transport="sse", port=port)
    elif transport == "streamable-http":
        print(
            f"[MCP RUNNER] Starting Streamable HTTP server on port {port}",
            file=sys.stderr,
        )
        server.run_simple(
            transport="http", port=port
        )  # run_simple uses 'http' mapping to streamable-http internally or we can pass explicit
    else:
        print("[MCP RUNNER] Starting stdio server", file=sys.stderr)
        server.run_simple(transport="stdio")
