# Expose the configuration directory to Hydra's pkg:// search path
