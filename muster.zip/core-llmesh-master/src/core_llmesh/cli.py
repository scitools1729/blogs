import argparse
import sys
import os
import subprocess
import re
import keyword
import shutil
from pathlib import Path
from dotenv import load_dotenv

def get_uv_binary() -> str:
    """Returns the path to the uv executable."""
    uv_path = shutil.which("uv")
    if not uv_path:
        # Fallback to standard installation paths if not in PATH
        fallback = Path.home() / ".local" / "bin" / "uv"
        if fallback.exists():
            return str(fallback)
        return "uv" # Final fallback, let subprocess handle the error
    return uv_path

def sanitize_str_to_list(input_str: str) -> list[str]:
    """
    Sanitizes a comma-separated or space-separated string into a deduplicated list
    of valid Python identifiers.
    """
    if not input_str:
        return []
    
    # Split by comma or space
    items = [x.strip() for x in re.split(r'[, ]+', input_str) if x.strip()]
    
    sanitized = []
    seen = set()
    
    for item in items:
        # 1. Convert to lowercase and replace hyphens with underscores
        clean_item = item.lower().replace('-', '_')
        # 2. Strip non-alphanumeric chars
        clean_item = re.sub(r'[^a-z0-9_]', '', clean_item)
        
        if not clean_item:
            continue
            
        # 3. Prepend underscore if it starts with a number
        if clean_item[0].isdigit():
            clean_item = f"_{clean_item}"
            
        # 4. Check reserved keywords
        if keyword.iskeyword(clean_item):
            print(f"Warning: '{item}' -> '{clean_item}' is a reserved Python keyword. Suffixing with '_val'.", file=sys.stderr)
            clean_item = f"{clean_item}_val"
            
        # 5. Deduplicate
        if clean_item not in seen:
            sanitized.append(clean_item)
            seen.add(clean_item)
            
    return sanitized

def to_class_name(snake_str: str) -> str:
    """Converts a snake_case string to CamelCase."""
    components = snake_str.split('_')
    return "".join(x.title() for x in components if x)

def scaffold_module(project_name: str, functions: list[str], tools: list[str]):
    """Generates the directory structure and files for the requested project layout."""
    
    # Standardize package name
    pkg_name = project_name.replace('-', '_')
    
    base_dir = Path(project_name).resolve()
    
    # Fail fast if the directory already exists to prevent accidental overwrites
    if base_dir.exists():
        print(f"Error: Directory '{project_name}' already exists. Please choose a different name or delete the existing directory.", file=sys.stderr)
        sys.exit(1)
        
    print(f"Building architecture for {project_name}...")
    src_dir = base_dir / "src" / pkg_name
    
    # 1. Create Directory Hierarchy
    (src_dir / "conf" / "tool").mkdir(parents=True, exist_ok=True)
    (src_dir / "conf" / "function").mkdir(parents=True, exist_ok=True)
    
    # 2. Generate pyproject.toml
    core_source_uri = os.environ.get("LLMESH_CORE_SOURCE_URI")
    if not core_source_uri:
        print("Error: The 'LLMESH_CORE_SOURCE_URI' environment variable is not set.", file=sys.stderr)
        print("Please set it to specify where newly scaffolded modules should fetch the 'core-llmesh' dependency.", file=sys.stderr)
        print("Example: export LLMESH_CORE_SOURCE_URI='{ git = \"git+ssh://git@github.com/scitools1729/core-llmesh.git\" }'", file=sys.stderr)
        sys.exit(1)
    
    pyproject_content = f"""[project]
name = "{project_name}"
version = "0.1.0"
description = ""
requires-python = ">=3.11"
dependencies = [
    "core-llmesh",
    "hydra-core",
    "omegaconf",
]

[build-system]
requires = ["setuptools"]
build-backend = "setuptools.build_meta"

# TODO: When core-llmesh is published to PyPI, remove this binding
# and rely on the PyPI index in the dependencies array.
[tool.uv.sources]
core-llmesh = {core_source_uri}
"""
    (base_dir / "pyproject.toml").write_text(pyproject_content)
    
    # 3. Generate main.py
    main_py_content = f"""import hydra
from omegaconf import DictConfig
from core_llmesh import execute_mesh, setup_cli_environment

@hydra.main(version_base=None, config_path="conf", config_name="config")
def main(cfg: DictConfig):
    import {pkg_name}
    return execute_mesh(cfg)

def cli():
    setup_cli_environment()
    main()

if __name__ == "__main__":
    cli()
"""
    (src_dir / "main.py").write_text(main_py_content)
    
    # 4. Generate config.yaml
    config_yaml_content = """hydra:
  searchpath:
    - pkg://core_llmesh.conf

defaults:
  - _self_
  - interface: cli
  - function: null
  - tool: null
  - override hydra/sweeper: llmesh_optuna

function: null
tool: null
"""
    (src_dir / "conf" / "config.yaml").write_text(config_yaml_content)
    
    # 5. Create Base and Init files
    (base_dir / "README.md").touch()
    (base_dir / "src" / "__init__.py").touch()
    (src_dir / "conf" / "__init__.py").touch()
    (src_dir / "conf" / "tool" / "__init__.py").touch()
    (src_dir / "conf" / "function" / "__init__.py").touch()
    
    # Initialize the package __init__.py and import Primitive
    init_py_path = src_dir / "__init__.py"
    init_py_content = "from core_llmesh import Primitive\n\n"
    
    # 6. Generate Tool Files (.py and .yaml)
    for tool in tools:
        class_name = to_class_name(tool)
        
        # Append import and registration
        init_py_content += f"from .{tool} import {class_name}\nPrimitive.add({class_name}())\n\n"
        
        # tool.py implementation stub
        tool_py_content = f"""from dataclasses import dataclass
from core_llmesh import Primitive

@dataclass
class {class_name}(Primitive):
    name: str = "{tool}"

    def __init__(self):
        super().__init__(self.name)

    def run(self, **kwargs):
        print("----- NOT YET IMPLEMENTED -----")
        print("kwargs: ", kwargs)
        print("tool definition: ", self.get_tool_definition())
        print("----- NOT YET IMPLEMENTED -----")
        return None

    def get_tool_definition(self):
        return {{
            "name": self.name,
            "description": "Dummy tool - not yet implemented",
            "parameters": {{
                "type": "object",
                "properties": {{
                    "dummy_string": {{
                        "type": "string",
                        "description": "A dummy string parameter"
                    }},
                    "dummy_number": {{
                        "type": "number",
                        "description": "A dummy number parameter"
                    }},
                    "dummy_boolean": {{
                        "type": "boolean",
                        "description": "A dummy boolean parameter"
                    }},
                    "dummy_array": {{
                        "type": "array",
                        "items": {{
                            "type": "string"
                        }},
                        "description": "A dummy array of strings"
                    }}
                }},
                "required": ["dummy_string"]
            }}
        }}

if __name__ == "__main__":
    tool = {class_name}()
    print(tool.run())
"""
        (src_dir / f"{tool}.py").write_text(tool_py_content)
        
        # tool.yaml config
        tool_yaml_content = f"""# @package _global_
tool: "{tool}"
"""
        (src_dir / "conf" / "tool" / f"{tool}.yaml").write_text(tool_yaml_content)
        print(f"  + Tool configured: {tool}")

    # Write the dynamically generated __init__.py block containing all the tool imports
    init_py_path.write_text(init_py_content)
    
    # 7. Generate Function Configs (.yaml)
    for func in functions:
        func_yaml_content = f"""# @package _global_
meta:
  module_key: ${{tool}}
function: {func}
"""
        (src_dir / "conf" / "function" / f"{func}.yaml").write_text(func_yaml_content)
        print(f"  + Function configured: {func}")
        
    print("---")
    print(f"Project '{project_name}' setup complete.")

def handle_create_module(args):
    """Parses args specifically for the `create-module` command."""
    
    # The user passes input format like `function=ingestion,validation`
    function_str = ""
    tool_str = ""
    
    # Parse K=V kwargs from the variable length args list
    for kv in args.kwargs:
        if kv.startswith("function="):
            function_str = kv.split("=", 1)[1]
        elif kv.startswith("tool="):
            tool_str = kv.split("=", 1)[1]
            
    sanitized_funcs = sanitize_str_to_list(function_str)
    sanitized_tools = sanitize_str_to_list(tool_str)
    
    # If interactive validation needed, we can check lengths/content here
    scaffold_module(args.project_name, sanitized_funcs, sanitized_tools)

def get_install_location() -> Path:
    """Returns the central LLMesh install directory for cached modules."""
    path_str = os.environ.get("LLMESH_INSTALL_LOCATION")
    if path_str:
        path = Path(path_str).resolve()
    else:
        path = Path.home() / ".llmesh"
    path.mkdir(parents=True, exist_ok=True)
    return path

def handle_add_module(args):
    """Clones a module from a URI into the LLMesh cache."""
    install_dir = get_install_location()
    target_dir = install_dir / args.module_name
    
    if target_dir.exists():
        print(f"Error: Module '{args.module_name}' is already installed at {target_dir}.", file=sys.stderr)
        print("Use 'llmesh remove-module' first if you wish to overwrite it.", file=sys.stderr)
        sys.exit(1)
        
    print(f"Adding module '{args.module_name}' from {args.module_uri}...")
    try:
        subprocess.run(["git", "clone", args.module_uri, str(target_dir)], check=True)
        print(f"Successfully installed '{args.module_name}'.")
    except subprocess.CalledProcessError as e:
        print(f"Failed to clone repository: {e}", file=sys.stderr)
        # Clean up partial clones
        if target_dir.exists():
            shutil.rmtree(target_dir)
        sys.exit(e.returncode)

def handle_list_modules(args):
    """Lists all modules installed in the LLMesh cache."""
    install_dir = get_install_location()
    print(f"LLMESH_INSTALL_LOCATION: {install_dir}")
    print("Installed modules:")
    
    if not install_dir.exists() or not any(install_dir.iterdir()):
        print("  (No modules installed)")
        return
        
    found = False
    for child in install_dir.iterdir():
        if child.is_dir() and not child.name.startswith("."): # ignore hidden dirs like .git
            print(f"  - {child.name}")
            found = True
            
    if not found:
        print("  (No modules installed)")

def handle_remove_module(args):
    """Removes a module from the LLMesh cache."""
    install_dir = get_install_location()
    target_dir = install_dir / args.module_name
    
    if not target_dir.exists():
        print(f"Error: Module '{args.module_name}' is not installed.", file=sys.stderr)
        sys.exit(1)
        
    print(f"Removing module '{args.module_name}'...")
    shutil.rmtree(target_dir)
    print("Successfully removed.")

def handle_run_module(args, extra_args=None):
    """Executes a component module from the global cache, automatically delegating virtual env creation via uv."""
    install_dir = get_install_location()
    target_dir = install_dir / args.module_name
    
    if not target_dir.exists() or not target_dir.is_dir():
        print(f"Error: Module '{args.module_name}' not found in cache at {install_dir}.", file=sys.stderr)
        print(f"Run 'llmesh add-module {args.module_name} <URI>' to install it first.", file=sys.stderr)
        sys.exit(1)
        
    # We execute via `uv run` in the module's cached directory. 
    # Auto-detect the entrypoint `main.py`
    main_script_root = target_dir / "main.py"
    src_dir = target_dir / "src"
    
    script_path = None
    if main_script_root.exists():
        script_path = "main.py"
    elif src_dir.exists() and src_dir.is_dir():
        # Look for the first valid main.py inside src/
        for pkg_dir in src_dir.iterdir():
            if pkg_dir.is_dir() and (pkg_dir / "main.py").exists():
                script_path = f"src/{pkg_dir.name}/main.py"
                break
                
    if not script_path:
        print(f"Error: Module entrypoint not found for '{args.module_name}'. Extracted repo structure is invalid.", file=sys.stderr)
        sys.exit(1)
        
    uv_bin = get_uv_binary()
    extra = extra_args if extra_args else []
    
    original_cwd = os.getcwd()
    # Inject Hydra overrides to force output mapping back to where the user invoked the command
    hydra_overrides = [
        f"hydra.run.dir={original_cwd}/.llmesh_runs/{args.module_name}/outputs/${{now:%Y-%m-%d}}/${{now:%H-%M-%S}}",
        f"hydra.sweep.dir={original_cwd}/.llmesh_runs/{args.module_name}/multirun/${{now:%Y-%m-%d}}/${{now:%H-%M-%S}}"
    ]
    
    # Setting cwd=target_dir ensures uv uses the module's pyproject.toml
    cmd = [uv_bin, "run", "python", script_path] + hydra_overrides + args.kwargs + extra
    print(f"Executing: {' '.join(cmd)}")
    try:
        subprocess.run(cmd, cwd=target_dir, check=True)
    except subprocess.CalledProcessError as e:
        print(f"Execution failed with error {e.returncode}", file=sys.stderr)
        sys.exit(e.returncode)


def main():
    # Load environment variables from a local .env file if it exists
    load_dotenv(os.path.join(os.getcwd(), ".env"))
    
    parser = argparse.ArgumentParser(description="LLMesh Core CLI")
    
    try:
        from importlib.metadata import version
        v = version("core-llmesh")
    except Exception:
        v = "unknown"
    parser.add_argument("--version", action="version", version=f"%(prog)s {v}")
    
    subparsers = parser.add_subparsers(dest="command", required=True)
    
    # 'create-module' subcommand
    create_parser = subparsers.add_parser("create-module", help="Scaffolds a new LLMesh downstream module locally")
    create_parser.add_argument("project_name", help="Name of the downstream project directory")
    create_parser.add_argument("kwargs", nargs="*", help="Optional overrides, e.g., function=name,name tool=name,name")
    
    # 'add-module' subcommand
    add_parser = subparsers.add_parser("add-module", help="Installs a module into the global LLMesh cache from a URI")
    add_parser.add_argument("module_name", help="The namespace/name to assign this module (e.g., custom-evals)")
    add_parser.add_argument("module_uri", help="The Git or File URI to clone (e.g., https://github.com/org/repo.git)")
    
    # 'list-module' subcommand
    list_parser = subparsers.add_parser("list-module", help="Lists all installed modules in the LLMesh cache")
    
    # 'remove-module' subcommand
    remove_parser = subparsers.add_parser("remove-module", help="Removes an installed module from the LLMesh cache")
    remove_parser.add_argument("module_name", help="Name of the existing module to remove")
    
    # 'run-module' subcommand
    run_parser = subparsers.add_parser("run-module", help="Executes a cached module via uv")
    run_parser.add_argument("module_name", help="Name of the installed module to execute")
    run_parser.add_argument("kwargs", nargs="*", help="Optional runtime overrides, e.g., function=name tool=name -m")
    
    args, unknown = parser.parse_known_args()
    
    if args.command == "create-module":
        handle_create_module(args)
    elif args.command == "add-module":
        handle_add_module(args)
    elif args.command == "list-module":
        handle_list_modules(args)
    elif args.command == "remove-module":
        handle_remove_module(args)
    elif args.command == "run-module":
        handle_run_module(args, extra_args=unknown)


if __name__ == "__main__":
    main()
