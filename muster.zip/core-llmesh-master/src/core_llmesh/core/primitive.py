from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import ClassVar, Dict, Any


@dataclass
class Primitive(ABC):
    """
    Base class for all LLMesh primitives (runners).
    """

    name: str
    description: str = ""
    suppress_run: bool = False
    kwargs: Dict[str, Any] = field(default_factory=dict)
    registry: ClassVar[Dict[str, "Primitive"]] = {}

    def __post_init__(self):
        pass

    @classmethod
    def add(cls, primitive: "Primitive"):
        """Registers a primitive instance."""
        cls.registry[primitive.name] = primitive

    @abstractmethod
    def run(self, **kwargs):
        """Standard execution entry point."""
        pass

    def get_state_graph(self) -> Any | None:
        """
        Optional: Returns the underlying LangGraph state graph.
        Return None if this primitive does not wrap a graph.
        """
        return None

    def get_tool_definition(self) -> Dict[str, Any]:
        """
        Returns a JSON-schema compatible definition of this primitive as a tool.
        By default, returns basic info. Subclasses should override or
        we can eventually infer this from the run() signature.
        """
        return {
            "name": self.name,
            "description": self.description,
            "parameters": {},  # To be populated by subclasses
        }

    def get_workflow_definition(self) -> Dict[str, Any] | None:
        """
        Optional: Returns the explicit workflow definition for this primitive.
        Used by the WorkflowCompiler to generate system prompts.
        Structure:
        {
          "description": "...",
          "steps": [
            {"name": "step1", "description": "...", "tools": ["tool1"]}
          ]
        }
        """
        return None
