import pytest
import argparse
import subprocess
from unittest.mock import patch, MagicMock
from pathlib import Path

# Adjust imports to pull directly from core_llmesh.cli
from core_llmesh.cli import (
    sanitize_str_to_list,
    to_class_name,
    handle_create_module,
    handle_build,
    handle_run_module
)

def test_sanitize_str_to_list():
    assert sanitize_str_to_list("foo, bar,baz") == ["foo", "bar", "baz"]
    assert sanitize_str_to_list("foo-bar") == ["foo_bar"]
    assert sanitize_str_to_list("9number") == ["_9number"]
    assert sanitize_str_to_list("import, def, class") == ["import_val", "def_val", "class_val"]
    assert sanitize_str_to_list("dup, dup, new") == ["dup", "new"]

def test_to_class_name():
    assert to_class_name("foo_bar_baz") == "FooBarBaz"
    assert to_class_name("single") == "Single"

def test_handle_create_module(tmp_path, monkeypatch):
    """Verifies that create-module sets up the correctly named files and dependencies."""
    # Move into the temporary directory for this test
    monkeypatch.chdir(tmp_path)
    
    args = argparse.Namespace(
        project_name="test-project",
        kwargs=["function=ingestion", "tool=s3_loader"]
    )
    
    handle_create_module(args)
    
    # Assert Directory Structure
    base_dir = tmp_path / "test-project"
    src_dir = base_dir / "src" / "test_project"
    
    assert base_dir.exists()
    assert (base_dir / "pyproject.toml").exists()
    assert (src_dir / "main.py").exists()
    # Assert Config content (including Optuna override ordering)
    config_content = (src_dir / "conf" / "config.yaml").read_text()
    assert "- override hydra/sweeper: llmesh_optuna" in config_content
    
    # Verify override is at the end of defaults (strict Hydra requirement)
    all_lines = [line.strip() for line in config_content.split("\n")]
    defaults_idx = all_lines.index("defaults:")
    # Collect lines starting with '-' until we hit a non-blank line that doesn't start with '-'
    defaults_lines = []
    for line in all_lines[defaults_idx + 1:]:
        if line.startswith("-"):
            defaults_lines.append(line)
        elif not line:
            continue
        else:
            break
            
    assert defaults_lines[-1] == "- override hydra/sweeper: llmesh_optuna"
    
    # Assert PyProject configurations
    toml_content = (base_dir / "pyproject.toml").read_text()
    assert 'name = "test-project"' in toml_content
    assert 'requires-python = ">=3.11"' in toml_content
    assert 'core-llmesh = { workspace = true }' in toml_content
    
def test_handle_create_module_exists(tmp_path, monkeypatch):
    """Verifies that create-module fails safely without overwriting an existing directory."""
    monkeypatch.chdir(tmp_path)
    
    # Pre-create the collision directory
    (tmp_path / "test-project").mkdir()
    
    args = argparse.Namespace(
        project_name="test-project",
        kwargs=["function=ingestion"]
    )
    
    with pytest.raises(SystemExit) as e:
        handle_create_module(args)
        
    assert e.value.code == 1

@patch("core_llmesh.cli.get_uv_binary", return_value="mock-uv")
@patch("subprocess.run")
def test_handle_build(mock_run, mock_uv, tmp_path):
    """Verifies that build correctly scans for projects and triggers uv sync."""
    
    # Seed fake projects inside the tmp_path workspace
    for proj in ["app-a", "app-b"]:
        proj_dir = tmp_path / proj
        proj_dir.mkdir()
        (proj_dir / "pyproject.toml").touch()
        
    args = argparse.Namespace(path=str(tmp_path))
    
    handle_build(args)
    
    # Validate the generated workspace toml
    workspace_toml = tmp_path / "pyproject.toml"
    assert workspace_toml.exists()
    content = workspace_toml.read_text()
    
    assert 'name = "' in content
    assert 'requires-python = ">=3.11"' in content
    assert '"app-a"' in content
    assert '"app-b"' in content
    
    # Verify the sync triggers subprocess.run correctly
    mock_run.assert_called_once()
    assert mock_run.call_args[0][0] == ["mock-uv", "sync"]
    assert mock_run.call_args[1]["cwd"] == tmp_path

@patch("core_llmesh.cli.get_uv_binary", return_value="mock-uv")
@patch("subprocess.run")
def test_handle_run_module(mock_run, mock_uv, tmp_path, monkeypatch):
    """Verifies that run-module delegates commands directly to uv run without pathing errors."""
    monkeypatch.chdir(tmp_path)
    
    # Setup the dummy module directory
    module_dir = tmp_path / "test-module"
    module_dir.mkdir()
    main_dir = module_dir / "src" / "test_module"
    main_dir.mkdir(parents=True)
    (main_dir / "main.py").touch()
    
    # Test arguments with normal kwargs and simulated trailing flags (-m)
    args = argparse.Namespace(
        module_name="test-module",
        kwargs=["function=ingest", "tool=s3"]
    )
    extra_args = ["-m"]
    
    handle_run_module(args, extra_args)
    
    # Validate subprocess construction
    mock_run.assert_called_once()
    called_cmd = mock_run.call_args[0][0]
    
    assert called_cmd == [
        "mock-uv", "run", "python", "src/test_module/main.py",
        "function=ingest", "tool=s3", "-m"
    ]
    
    # cli.py resolves the path relative to the current working dir 
    expected_cwd = Path("test-module")
    assert mock_run.call_args[1]["cwd"] == expected_cwd
