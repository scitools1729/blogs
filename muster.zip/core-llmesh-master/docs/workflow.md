# LLMesh Workflows

This document outlines the standard operational workflows for interacting with the LLMesh ecosystem. 

The framework natively acts as a decentralized Hub via `uv`—meaning components are cached and executed in absolute isolation without bleeding dependencies. Workflows are categorized below based on whether you are simply utilizing existing modules (Consumer) or actively developing new ones (Producer).

---

## Consumer Workflow

This workflow is designed for end-users who only want to download and run existing LLMesh modules securely from the Hub.

### 1. Install LLMesh Globally
Install the lightweight orchestration CLI onto your machine. You can pull the orchestrator from any valid Git or local File URI.
```bash
# Option A: SSH (Recommended for private repositories without password prompts)
uv tool install --force "git+ssh://git@github.com/scitools1729/core-llmesh.git"

# Option B: HTTPS (Requires Git credential helper for private repositories)
uv tool install --force "git+https://github.com/scitools1729/core-llmesh.git"

# Option C: Local File Path
uv tool install --force "file:///absolute/path/to/core-llmesh"
```
*(Verify it works by running `llmesh --version` or `llmesh --help`)*

### 2. Configure Cache (Optional)
By default, all installed modules are securely cached in `~/.llmesh`. If you want to store them elsewhere, explicitly assign the directory.
```bash
export LLMESH_INSTALL_LOCATION=/path/to/my/custom/hub
```

### 3. Install a Module
Add a remote module to your local Hub cache using its Git repository. You can map any Git URI to an easy-to-use alias.
```bash
# Option A: SSH
llmesh add-module quality-evals "git+ssh://git@github.com/org/quality-evals.git"

# Option B: HTTPS
llmesh add-module quality-evals "git+https://github.com/org/quality-evals.git"

# Option C: Local File Path
llmesh add-module quality-evals "file:///absolute/path/to/quality-evals"
```

### 4. Manage Modules
You can easily view or remove installed modules from your cache.
```bash
llmesh list-module
llmesh remove-module quality-evals
```

### 5. Execute 
Run your installed module! `uv` will powerfully isolate the environment, parsing the module's `pyproject.toml` and resolving dependencies invisibly in the background.
```bash
llmesh run-module quality-evals tool=my_target_probe
```

---

## Producer Workflow

This workflow is customized for developers building and publishing brand new modules into the LLMesh ecosystem.

### 1. Install LLMesh Globally
Ensure you have the latest scaffolding tooling installed.
```bash
# Option A: SSH (Recommended)
uv tool install --force "git+ssh://git@github.com/scitools1729/core-llmesh.git"

# Option B: HTTPS 
uv tool install --force "git+https://github.com/scitools1729/core-llmesh.git"

# Option C: Local File Path (Recommended if you are actively editing core-llmesh)
uv tool install --force "file:///absolute/path/to/core-llmesh"
# Or simply: uv tool install --force . (if you are currently in the directory)
```

### 2. Configure Core Dependency Path (Required)
Before generating a new project, explicitly define where `uv` should pull the `core-llmesh` framework from for downstream users. This ensures the templated `pyproject.toml` correctly maps its upstream dependency.
```bash
# Option A: SSH
export LLMESH_CORE_SOURCE_URI='{ git = "git+ssh://git@github.com/scitools1729/core-llmesh.git" }'

# Option B: HTTPS
export LLMESH_CORE_SOURCE_URI='{ git = "https://github.com/scitools1729/core-llmesh.git" }'

# Option C: Local Path
export LLMESH_CORE_SOURCE_URI='{ path = "/absolute/path/to/your/core-llmesh" }'
```

### 3. Scaffold a New Module
Generate a clean, standardized LLMesh repository pre-configured with `main.py` entrypoints and configuration files. It will forcefully read your `LLMESH_CORE_SOURCE_URI` and fail if you haven't explicitly set it.
```bash
llmesh create-module advanced-plugin tool=metrics,analyzer function=pipeline
```

### 4. Develop Locally
Enter your newly minted repository. You bypass the `llmesh` Hub CLI here during active development and strictly use `uv` to natively execute and test your code locally.
```bash
cd advanced-plugin
# Make edits to src/advanced_plugin/*.py
uv run python src/advanced_plugin/main.py tool=metrics
```

### 5. Publish to Git
Once your tool logic is complete, publish the directory as an independent Git repository so Consumers can pull it securely via `llmesh add-module`.
```bash
git init
git add .
git commit -m "Initial plugin release"
git remote add origin git@github.com:your-org/advanced-plugin.git
git push -u origin main
```

### 6. Verify End-to-End Delivery
Prove your pipeline works exactly as a Consumer would experience it.
```bash
# Add your directly published GitHub repo to the local cache natively utilizing SSH
llmesh add-module test-install "git+ssh://git@github.com/your-org/advanced-plugin.git"

# Verify it runs successfully isolated in the Hub
llmesh run-module test-install tool=metrics
```
