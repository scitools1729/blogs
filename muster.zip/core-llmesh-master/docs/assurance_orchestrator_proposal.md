# Orchestrating AI Assurance Frameworks via `core-llmesh`

## 1. Executive Summary

This report outlines the technical rationale for adopting the `core-llmesh` orchestration framework as the primary mechanism for rapid prototyping and deployment of AI assurance tools (e.g., `promptfoo`, `Inspect AI`, `HarmBench`). The current landscape of AI evaluation is highly fragmented, with each framework dictating its own execution model, configuration syntax, and interface layer. 

By leveraging the architecture inherent to `core-llmesh`, we propose developing a universal integration layer. This approach standardizes execution, unifies configuration management, and automatically provisions tri-modal interfaces (CLI, REST, MCP) alongside HPC cluster scaling, all stemming from a minimal, standardized codebase wrapper.

## 2. Technical Architecture Integration

### 2.1 The `Primitive` Abstraction Layer

The foundational mechanism for integration is the `core_llmesh.core.primitive.Primitive` base class. This acts as a universal adapter pattern for disparate execution environments.

Integrating a complex, standalone tool like `promptfoo` or `Inspect AI` requires only the implementation of a subclass containing two primary methods:
1.  **`run(**kwargs)`**: The execution boundary. This method isolates the sub-process call (e.g., invoking a Node.js `promptfoo` CLI) or the Python API instantiation (e.g., calling `inspect_ai.eval()`).
2.  **`get_tool_definition()`**: This method returns a JSON Schema defining the expected inputs and configuration space for the enclosed assurance tool.

This abstraction ensures that heterogeneous frameworks are homogenized into standardized execution blocks within the `core-llmesh` ecosystem.

### 2.2 Modular Workspace Design

Following the established pattern in the `ai-assurance-pipeline` workspace (which separates `core-llmesh` from `mod-ic-tools`), assurance integrations can be maintained in a dedicated module (e.g., `mod-assurance`). This enforces clean architectural boundaries. The orchestration logic remains decoupled from the domain-specific implementations, allowing for rapid iteration and integration of novel evaluation tools without altering the core mesh engine.

## 3. Auto-Provisioned Interface Matrix

A primary advantage of the `core-llmesh` architecture is its capacity to generate multiple execution pathways from a single `Primitive` definition dynamically. Wrapping an evaluation tool immediately exposes it via three distinct interfaces:

### 3.1 Command Line Interface (CLI)
`core-llmesh` auto-generates programmatic CLI commands.
*   **Mechanism:** `llmesh run-module <module> function=<function> tool=<tool>`
*   **Application:** Enables immediate integration into CI/CD pipelines (GitHub Actions, GitLab CI), scheduled cron executions, and local developer ad-hoc testing.

### 3.2 RESTful API (`serve.api_runner`)
The framework utilizes FastAPI to wrap `Primitive` executions in REST protocols.
*   **Mechanism:** Execution triggered via POST requests to `/workflow/{module_key}` containing the JSON payload defined by `get_tool_definition()`.
*   **Application:** Facilitates the immediate development of web-based assurance dashboards, enterprise microservice integrations, and decoupled architecture deployments.

### 3.3 Model Context Protocol (MCP) (`serve.mcp_runner`)
`core-llmesh` dynamically serves registered Primitives to MCP clients via an internal `ToolUniverse` adapter.
*   **Mechanism:** The SDK translates the Primitive's JSON Schema into an SMCP Server tool endpoint.
*   **Application:** Permits interactive AI agents (e.g., Claude Desktop, native Ollama configurations) to discover, understand, and autonomously execute complex evaluation tools as part of broader agentic loops or reasoning traces.

## 4. Enterprise Scaling and Configuration Management

### 4.1 Unified Configuration Space
AI assurance fundamentally relies on complex parameter sweeping (varying target models, dataset permutations, and prompt templates). `core-llmesh` utilizes `hydra-core` for hierarchical, declarative YAML configuration management. This unifies the configuration syntax across all wrapped tools, allowing parameters to be easily overridden at runtime via the CLI or API, overriding underlying tool-specific configs (like `promptfoo.yaml`).

### 4.2 High-Performance Computing (HPC) Integration
AI evaluation, particularly "LLM-as-a-judge" workflows or large-scale dataset processing, is significantly compute-bound. Because `core-llmesh` is built on Hydra, it natively inherits the `hydra-submitit-launcher` capability.
*   **Slurm Cluster Submission:** By appending `--multirun hydra/launcher=submitit_slurm` to the execution command, the framework can automatically chunk large evaluation jobs and submit them as parallel arrays to a Slurm HPC cluster.
*   **Workflow Optimization:** This eliminates the need for bespoke multiprocessing scripts. The framework natively orchestrates parameter sweeps (e.g., evaluating against four different foundation models concurrently) while delegating the heavy computational lifting to the cluster.

## 5. Conclusion

Adopting `core-llmesh` as the orchestration layer for AI assurance provides significant operational leverage. By investing minimal effort into writing standardized `Primitive` wrappers, the engineering team establishes an architecture that is "Write Once, Expose Everywhere, Scale Infinitely." This approach standardizes fragmented tooling into a unified control plane, natively supporting CI/CD, user-facing dashboards, autonomous agent operations, and HPC cluster parallelization.
