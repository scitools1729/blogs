# 1. Update the globally installed CLI one last time locally
# (Run this from inside your core-llmesh directory!)
uv tool install --force git+ssh://git@github.com/scitools1729/core-llmesh.git

# 2. Define our isolated temporary testing cache
export LLMESH_INSTALL_LOCATION=/tmp/llmesh-test-hub

# 3. Set the core dependency to fetch securely from your private GitHub via SSH!
export LLMESH_CORE_SOURCE_URI='{ git = "git+ssh://git@github.com/scitools1729/core-llmesh.git" }'

# 4. Successfully scaffold the dummy module
llmesh create-module test-module tool=dummy

# 5. Initialize git so our Hub logic can 'clone' it
cd test-module
git init
git add .
git commit -m "Initial commit"
cd ..

# 6. Add the local repo to the test Hub cache
llmesh add-module my-test-mod file://$PWD/test-module

# 7. Verify the cache picked it up
llmesh list-module

# 8. Execute it perfectly isolated!
# (Watch carefully! uv will now automatically clone core-llmesh from GitHub via SSH in the background to build the isolated environment before running it)
llmesh run-module my-test-mod tool=dummy

# 9. Test removal and final tear down
llmesh remove-module my-test-mod
rm -rf test-module

