# LLMesh

**LLMesh** is a lightweight orchestration framework for executing Python-based tools and workflows. It transforms static "Primitive" classes into automated tools and workflows capable of  execution via CLI, REST APIs, or MCP.

## Features
- **Multi-Interface**: Run workflows via CLI, REST API, or MCP.
- **Hydra Configuration**: robust, hierarchical configuration management.

## Quick Start

### 1. Installation
```bash
cd llmesh
uv sync  # or pip install -e .
```

### 2. Testing the Framework
Run the isolated integration test suite:
```bash
uv sync --all-extras
uv run --extra dev pytest tests/
```
---

## Source Code

A brief guide to the core components of the framework.

### `src/llmesh`
- **`main.py`**: The application entry point. Dispatches execution based on `interface_mode` (cli, rest_api, mcp) and initializes Hydra configuration.


### `src/llmesh/serve`
- **`api_runner.py`**: FastAPI implementation that wraps workflow execution in a RESTful POST endpoint (`/workflow/{project_key}`).
- **`mcp_runner.py`**: Model Context Protocol (MCP) server implementation that exposes tools dynamically to MCP clients using `ToolUniverse`.

### `src/llmesh/core`
- **`primitive.py`**: The base class for all workflows. Defines the registry pattern and `get_workflow_definition` contract.
- **`app.py`**: Logic for primary CLI execution and configuration parsing.

### `src/llmesh/conf`
- **`config.yaml`**: Root configuration definitions and global settings.
- **`interface/*.yaml`**: Config groups defining metadata for `cli`, `rest_api`, and `mcp` modes.