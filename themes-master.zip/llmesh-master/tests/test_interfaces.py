import pytest
from unittest.mock import patch
from fastapi.testclient import TestClient
from omegaconf import OmegaConf

from llmesh import Primitive
from llmesh.core.app import run_app
from llmesh.serve.api_runner import app, SERVER_CONTEXT
from llmesh.serve.mcp_runner import start_server


# 1. Define a self-contained Dummy Primitive for testing
class DummyPrimitive(Primitive):
    name = "dummy_test_project"

    def __init__(self):
        super().__init__(self.name)
        Primitive.add(self)

    def run(self, **kwargs):
        # Allow testing dynamic parameter injection
        response_msg = kwargs.get("message", "hello world")
        return {"result": response_msg, "status": "ok"}

    def get_tool_definition(self):
        return {
            "name": self.name,
            "description": "A dummy primitive used purely for interface testing.",
            "parameters": {
                "type": "object",
                "properties": {
                    "message": {
                        "type": "string",
                        "description": "Message to echo back",
                    }
                },
            },
        }

# Ensure primitive is registered before tests run
DummyPrimitive()


def test_cli_execution():
    """
    Test that the base CLI runner (run_app) correctly discovers and executes
    the primitive with populated OmegaConf parameters.
    """
    # Simulate a Hydra DictConfig passed in from CLI like `project=dummy_test_project message="cli_test"`
    mock_config = OmegaConf.create({
        "meta": {"project_key": "dummy_test_project"},
        "message": "cli_test"
    })
    
    # run_app directly invokes the primitive and prints/returns results 
    # run_app doesn't inherently return the output in all scenarios, but we can mock or just ensure it doesn't crash 
    # Actually, run_app returns the result in recent llmesh versions if it doesn't just print. 
    # We'll assert it runs cleanly. 
    try:
        run_app(mock_config, runner_key="dummy_test_project")
    except Exception as e:
        pytest.fail(f"CLI run_app failed with error: {e}")


def test_rest_api_execution():
    """
    Test that the FastAPI server routes JSON requests correctly into the Primitive's run() method.
    """
    client = TestClient(app)
    
    # Mock the SERVER_CONTEXT that is normally populated by `start_server()` in `main.py`
    SERVER_CONTEXT["project_key"] = "dummy_test_project"
    SERVER_CONTEXT["base_cfg"] = OmegaConf.create({})

    # Dispatch request simulating a REST client
    response = client.post(
        "/workflow/dummy_test_project",
        json={"parameters": {"message": "api_test"}}
    )
    
    # Assert successful API routing and tool execution
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "success"
    assert data["result"]["result"] == "api_test"


def test_mcp_initialization():
    """
    Test that the MCP runner correctly translates the Primitive logic to the ToolUniverse configuration.
    We mock the actual server.run_simple() implementation so that the test doesn't block forever hanging on IO.
    """
    # We just want to ensure it iterates the registry and creates the SMCP without crashing
    with patch("tooluniverse.smcp.SMCP.run_simple") as mock_run_simple:
        
        mock_config = OmegaConf.create({
            "mcp_server_name": "TestServer",
            "mcp_transport": "stdio"
        })
        
        try:
            start_server(mock_config, project_key="dummy_test_project")
        except Exception as e:
            pytest.fail(f"start_server for MCP failed with error: {e}")
            
        # Assert that the blocking run_simple loop was called exactly once 
        mock_run_simple.assert_called_once_with(transport="stdio")
