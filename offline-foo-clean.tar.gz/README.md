# Offline-Foo

A secure wrapper for [Promptfoo](https://github.com/promptfoo/promptfoo) that forces it to run strictly offline using local models, completely disabling all telemetry, external network calls, and cloud dependencies.

## Prerequisites

`offline-foo` is a secure Python wrapper that executes the underlying Promptfoo engine. To use it, you must have Node.js and Promptfoo installed on your system.

### Manual System Check

Before running `offline-foo`, manually verify your prerequisites are met:

1. **Check Node.js (Required)**
   ```bash
   node -v
   # Should return v18.0.0 or higher
   ```

2. **Check npx (Required)**
   ```bash
   npx -v
   # Should return a version number
   ```

3. **Check Promptfoo (`npx` Dynamic Execution vs Global Installation)**
   When `offline-foo` spawns the engine, it runs `npx promptfoo@latest`.
   - **If you have internet access:** `npx` will dynamically download the Promptfoo package into a temporary npm cache if it is not installed locally or globally, and then execute it.
   - **If you are completely air-gapped:** This dynamic download will fail. You MUST install Promptfoo globally or locally beforehand while still connected to the internet.
   
   To ensure your machine is ready for an air-gapped environment, confirm it is installed and cached globally. If you do not have `sudo` or administrator privileges on the cluster, you must configure `npm` to install global packages into your user space:
   ```bash
   # 1. Create a directory for global node packages in your home folder
   mkdir -p ~/.npm-global
   
   # 2. Tell npm to use this new directory path
   npm config set prefix '~/.npm-global'
   
   # 3. Add the bin folder to your PATH (also append this to your ~/.bashrc)
   export PATH=~/.npm-global/bin:$PATH
   
   # 4. Install promptfoo globally into your user space
   npm install -g promptfoo
   
   promptfoo --version
   ```

4. **Verify Local LLMs (Required)**
   Ensure your local model runner (like Ollama or vLLM) is active and the model weights are downloaded.
   ```bash
   # Example for Ollama
   ollama run mistral
   ```

## Installation

You can install `offline-foo` using `uv`. 

```bash
# Add it to a specific Python project
uv add offline-foo

# Or install it as a standalone global CLI tool. 
# Note: 'uv tool install' automatically securely installs into your user space (e.g., ~/.local/bin) 
# and does NOT require sudo or complex prefix configurations like npm!
uv tool install offline-foo
```

## Extensive CLI Usage Scenarios

Because `offline-foo` passes non-engine arguments directly to the underlying engine, anything you can do natively in Promptfoo, you can do securely here. Here are 11 common use cases, assuming you have no prior experience with the Promptfoo CLI:

### 1. Initialize a new project
Scaffolds a blank `promptfooconfig.yaml` with your default local model pre-configured in the folder you run the command in.
```bash
offline-foo init -p ollama:chat:mistral:latest # For vLLM: -p openai:chat:mistral:latest
```

### 2. Run a standard evaluation
Runs the expected outputs, asserts, and tests defined in your configuration using your assigned local model. 
```bash
offline-foo eval -p ollama:chat:mistral:latest # For vLLM: -p openai:chat:mistral:latest
```

### 3. Run a basic Red Team attack
Automatically generates adversarial inputs to find vulnerabilities in your AI application, grading its resilience using the **exact same LLM** for both attacking and judging.
```bash
offline-foo redteam -a ollama:chat:mistral:latest # For vLLM: -a openai:chat:mistral:latest
```

### 4. Run Red Team with separate Attacker and Evaluator
Use a smaller, faster model to creatively generate adversarial probes (Mistral) and a larger, smarter model to act as the strict unbiased judge (Llama 3).
```bash
offline-foo redteam -a ollama:chat:mistral:latest -e ollama:chat:llama3:latest # For vLLM: -a openai:chat:mistral:latest -e openai:chat:llama3:latest
```

### 5. Run an evaluation from a specific configuration file
If you organize your test suites differently, use `-c` or `--config` to point to a specific file instead of defaulting to `promptfooconfig.yaml`.
```bash
offline-foo eval -c custom_tests.yaml -p ollama:chat:mistral:latest # For vLLM: -p openai:chat:mistral:latest
```

### 6. Run securely inside an isolated Podman/Docker container
Used primarily on Slurm clusters or highly secured machines. This completely eliminates the need to install Node.js natively by executing the engine inside an ephemeral container.

```bash
# Default behavior (uses official ghcr.io image)
offline-foo redteam --engine podman -a ollama:chat:mistral:latest # For vLLM: -a openai:chat:mistral:latest
```

**Custom Air-Gapped Images:** If your cluster has no internet access to pull the official image, you can build your own using the included `Dockerfile`:
```bash
# Build the local image
docker build -t docker-promptfoo .

# Run offline-foo using this strictly local image
PROMPTFOO_IMAGE=docker-promptfoo offline-foo redteam --engine docker -a ollama:chat:mistral:latest
```

### 7. View results interactively in your browser
Promptfoo ships with an interactive local Web UI. Use the `view` command to visualize the generated probes, failed tests, and security matrix from your last run. 
```bash
offline-foo view -y
```

### 8. Output a compiled security report
Instead of just printing a table to your terminal at the end of the run, export the entire evaluation matrix to a specific file format (e.g., JSON, CSV, HTML) to share with your team.

**Regular Execution (HTML):**
```bash
offline-foo redteam -a ollama:chat:mistral:latest -o report.html
```

**Container Execution (CSV):**
*Note: Because the container securely mounts your current working directory, it will cleanly save the file right back to your host folder!*
```bash
PROMPTFOO_IMAGE=docker-promptfoo offline-foo redteam --engine docker -a ollama:chat:mistral:latest -o report.csv
```

### 9. Optimize performance by limiting concurrency
Local LLM servers (like Ollama and vLLM) can crash, run out of VRAM, or drop requests if hammered with too much parallel generation. Use `-j` or `--max-concurrency` to limit the number of simultaneous API calls.
```bash
# Only run 2 probes at a time
offline-foo redteam -a ollama:chat:mistral:latest --max-concurrency 2 # For vLLM: -a openai:chat:mistral:latest
```

### 10. Force a fresh run by ignoring the cache
Promptfoo aggressively caches LLM responses to save time and compute. If you update your model weights, modify your system instructions, or simply want a completely fresh evaluation, force it to skip the cache.
```bash
offline-foo eval -p ollama:chat:mistral:latest --no-cache # For vLLM: -p openai:chat:mistral:latest
```

### 11. Debug silent failures with verbose logging
If an evaluation fails or your LLM repeatedly returns blank responses, enable extremely verbose logs. This allows you to inspect the exact HTTP requests and raw prompt headers Promptfoo is making to your local inference server.
```bash
offline-foo eval -p ollama:chat:mistral:latest --verbose # For vLLM: -p openai:chat:mistral:latest
```

## Configuring LLM Base URLs

Because `offline-foo` seamlessly proxies execution to Promptfoo, the cleanest way to set the base URL for your local LLM endpoints is through standard environment variables before running your CLI commands.

### For Ollama (`ollama:chat:...`)
Promptfoo automatically checks `OLLAMA_BASE_URL`.
```bash
export OLLAMA_BASE_URL="http://10.0.0.5:11434"
offline-foo redteam -a ollama:chat:mistral:latest
```

### For vLLM / OpenAI-Compatible endpoints (`openai:chat:...`)
If you are running vLLM on a cluster, use the standard OpenAI variables:
```bash
export OPENAI_BASE_URL="http://your-vllm-cluster:8000/v1"
export OPENAI_API_KEY="dummy-key-required-by-vllm"

offline-foo redteam -a openai:chat:mistral:latest
```

### Alternative: YAML Configuration
Instead of using environment variables, you can define your local provider and its custom base URL directly within your `promptfooconfig.yaml` or `redteam.yaml` file:

```yaml
# In redteam.yaml
redteam:
  provider:
    id: ollama:chat:mistral:latest # For vLLM: id: openai:chat:mistral:latest
    config:
      apiBaseUrl: "http://10.0.0.5:11434" # For vLLM: apiBaseUrl: "http://your-vllm-cluster:8000/v1"
      # apiKey: "dummy-key" # For vLLM, a dummy key is required
```
When this is configured, you don't need to pass the `-a` flag to `offline-foo redteam`.

## Code Structure

The project is broken down into simple, modular components found under `src/offline_foo/`:

*   **`cli.py`**: The Typer CLI interface. It parses user arguments (like `-p`, `-a`, `-e`, and `--engine`), bridges them to the configuration overwriter, and routes execution to the correct runner.
*   **`config.py`**: The secure YAML injection engine. It reads `promptfooconfig.yaml`, drops any explicitly defined cloud providers (e.g. `openai:gpt-4`), and safely injects your chosen local LLMs into a temporary file.
*   **`runner.py`**: The default local execution bridge. It forces security environment variables (`PROMPTFOO_DISABLE_TELEMETRY=1`, etc.) and spawns the native `npx promptfoo` binary.
*   **`container_runner.py`**: The container execution bridge. Used when `--engine podman` or `docker` is passed, it orchestrates executing Promptfoo inside a container while dynamically mounting your local working directory and securely overriding configs.
*   **`run_secure_promptfoo_redteam.py`**: A fully standalone programmatic Python API, enabling external orchestration scripts (like Hydra or Submitit) to securely execute Promptfoo sweeps without needing the CLI.

## Programmatic Python API

Because `offline-foo` is configured as an installable library, you can easily call it programmatically from another Python script without invoking the CLI parser. This is extremely powerful for cluster computing contexts like triggering parallel sweeps with Hydra and Slurm Submitit!

```python
from offline_foo.run_secure_promptfoo_redteam import run_secure_promptfoo_redteam

if __name__ == "__main__":
    # Execute the redteam programmatically against your config
    run_secure_promptfoo_redteam("promptfooconfig.yaml")
```

## Generate sbatch configs
```bash
python src/offline_foo/generate_configs.py
```

## Run red teaming after generating scripts
```bash
uv run offline-foo redteam -c sbatch_configs/redteam_excessive-agency.yaml -o results.json
```
```bash
PROMPTFOO_IMAGE=docker-promptfoo uv run offline-foo redteam --engine docker -c sbatch_configs/redteam_excessive-agency.yaml -o results.json
```

## Submit sbatch jobs
```bash
for f in sbatch_configs/redteam_*.yaml; do
  sbatch --job-name="promptfoo-$(basename $f .yaml)" --time=01:00:00 --wrap="uv run offline-foo redteam -c $f -o ${f%.yaml}_report.json"
done
```
If the cluster requires complex configurations (like loading specific module environments, virtual environments, or requesting specific GPU partitions), you write a single master runner.slurm script that takes the config as an argument. Something like this.
```bash
#!/bin/bash
#SBATCH --job-name=promptfoo-redteam
#SBATCH --time=02:00:00
#SBATCH --gpus=1
#SBATCH --mem=16G

# Load any required modules here
# module load python/3.10

# $1 is the filename passed in from the for loop
CONFIG_FILE=$1
OUTPUT_FILE="${CONFIG_FILE%.yaml}_report.json"

uv run offline-foo redteam -c $CONFIG_FILE -o $OUTPUT_FILE
```
```bash
for f in sbatch_configs/redteam_*.yaml; do sbatch runner.slurm $f; done
```


