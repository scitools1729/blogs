import sys
import subprocess
import os
from typing import List

def run_promptfoo_container(promptfoo_args: List[str], engine: str = "podman"):
    """
    Executes promptfoo securely using a container engine (docker or podman).
    
    This mounts the current working directory and shares the host network 
    so local LLMs (ollama/vLLM) can be transparently accessed by the promptfoo 
    image exactly as if it were running natively.
    """
    current_dir = os.getcwd()
    
    # Allow users to override the container image (useful for custom air-gapped builds)
    image_name = os.getenv("PROMPTFOO_IMAGE", "ghcr.io/promptfoo/promptfoo:latest")
    
    uid = os.getuid() if hasattr(os, "getuid") else 1000
    gid = os.getgid() if hasattr(os, "getgid") else 1000
    
    # Ensure local promptfoo dir exists so Docker doesn't auto-create it as root
    promptfoo_dir = os.path.expanduser("~/.promptfoo")
    os.makedirs(promptfoo_dir, exist_ok=True)
    
    # Avoid "input device is not a TTY" errors in headless subprocesses
    tty_flag = "-it" if sys.stdout.isatty() else "-i"
    
    env_args = []
    # Pass through relevant host environment variables
    for key, value in os.environ.items():
        if key.startswith("OPENAI_") or key.startswith("OLLAMA_") or key.startswith("PROMPTFOO_"):
            env_args.extend(["-e", f"{key}={value}"])
            
    # Fix Docker Desktop localhost networking issues (Windows/Mac)
    network_args = ["--network", "host"]
    if engine == "docker":
        network_args.extend(["--add-host", "host.docker.internal:host-gateway"])
        if "OLLAMA_BASE_URL" not in os.environ:
            env_args.extend(["-e", "OLLAMA_BASE_URL=http://host.docker.internal:11434"])
        if "OPENAI_BASE_URL" not in os.environ:
            # Also map default OpenAI local servers to the gateway if needed
            env_args.extend(["-e", "OPENAI_BASE_URL=http://host.docker.internal:8000/v1"])

    # Base command for container execution
    base_cmd = [
        engine, "run", "--rm", tty_flag,
        "--user", f"{uid}:{gid}",
    ] + network_args + env_args + [
        # Mount the working directory
        "-v", f"{current_dir}:/app",
        # Explicitly mount the /tmp/ directory where our secure overrides are generated
        "-v", "/tmp:/tmp",  
        # Provide a synthetic home directory so promptfoo writes its cache gracefully as the user
        "-e", "HOME=/promptfoo_home",
        "-v", f"{promptfoo_dir}:/promptfoo_home/.promptfoo",
        "-w", "/app",
        # Inject standard security flags
        "-e", "PROMPTFOO_DISABLE_TELEMETRY=1",
        "-e", "PROMPTFOO_DISABLE_UPDATE=1",
        "-e", "PROMPTFOO_DISABLE_SHARE=1",
        "-e", "PROMPTFOO_DISABLE_REDTEAM_REMOTE_GENERATION=1",
        image_name
    ]
    
    # Construct complete command by appending native promptfoo instructions
    full_cmd = base_cmd + promptfoo_args
    
    try:
        # Run the containerized engine
        result = subprocess.run(full_cmd)
        sys.exit(result.returncode)
    except FileNotFoundError:
        print(f"\n[offline-foo] Error: Could not find '{engine}' executable in PATH.", file=sys.stderr)
        print(f"Please ensure {engine} is installed or select another engine.", file=sys.stderr)
        sys.exit(1)
