import os
from pathlib import Path
from typing import Union
from .config import override_promptfoo_config
from .runner import run_promptfoo

def run_secure_promptfoo_redteam(
    config_path: Union[str, Path],
    attacker: str = "ollama:chat:mistral:latest",
    evaluator: str = "ollama:chat:gpt-oss:latest",
    engine: str = "local"
) -> None:
    """
    Programmatically executes an offline redteam evaluation.
    This dynamically injects the chosen models into the config
    and seamlessly launches promptfoo in a secure environment.
    """
    original_config = Path(config_path)
    if not original_config.exists():
        raise FileNotFoundError(f"Config {original_config} not found.")

    print(f"Securing config: {original_config.name}")
    
    # 1. Generate the secure temporary override config
    secure_temp_config = override_promptfoo_config(
        original_config_path=original_config,
        local_provider=attacker,
        evaluator_provider=evaluator,
        is_redteam=True
    )
    
    # 2. Build the exact args you want Promptfoo to receive
    promptfoo_args = ["redteam", "run", "--config", str(secure_temp_config)]
    
    print(f"Spawning promptfoo with args: {promptfoo_args} using engine: {engine}")
    try:
        # 3. Execute the wrapper using the chosen engine context
        if engine == "local":
            run_promptfoo(promptfoo_args)
        else:
            from .container_runner import run_promptfoo_container
            run_promptfoo_container(promptfoo_args, engine=engine)
            
        print("Evaluation complete.")
        
    finally:
        # 4. Clean up the temporary secure config
        if secure_temp_config.exists():
            os.remove(secure_temp_config)
