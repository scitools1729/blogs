import os
import tempfile
from pathlib import Path
from ruamel.yaml import YAML

yaml = YAML()
yaml.preserve_quotes = True

def override_promptfoo_config(
    original_config_path: Path, 
    local_provider: str,
    evaluator_provider: str = None,
    is_redteam: bool = False
) -> Path:
    """
    Parses the user's config and dynamically injects/overrides the 
    providers to use `local_provider` (and optionally a separate `evaluator_provider`).
    Returns the path to a newly created temporary config file.
    """
    if not original_config_path.exists():
        raise FileNotFoundError(f"Config file {original_config_path} not found.")

    with open(original_config_path, "r", encoding="utf-8") as f:
        data = yaml.load(f)

    # Inject default evaluate provider (judge, default test provider)
    if "defaultTest" not in data:
        data["defaultTest"] = {}
    if "options" not in data["defaultTest"]:
        data["defaultTest"]["options"] = {}
        
    data["defaultTest"]["options"]["provider"] = evaluator_provider or local_provider

    # Inject redteam attacker provider if redteam config exists
    if is_redteam or "redteam" in data:
        if "redteam" not in data or data["redteam"] is None:
            data["redteam"] = {}
        if isinstance(data["redteam"], dict):
            # Promptfoo allows overriding the attacker model in the yaml
            data["redteam"]["provider"] = local_provider

    # Also block explicitly known cloud providers from targets if found
    _validate_no_cloud_providers(data)

    # Write to a NamedTemporaryFile
    # Ensure it's not deleted immediately so promptfoo can read it
    fd, temp_path = tempfile.mkstemp(suffix=".yaml", text=True)
    with os.fdopen(fd, "w", encoding="utf-8") as temp_file:
        yaml.dump(data, temp_file)
        
    return Path(temp_path)

def _validate_no_cloud_providers(data: dict) -> None:
    """Raises ValueError if a known cloud provider is detected in targets or providers."""
    # Basic check against strings in targets or providers
    forbidden = ["openai:", "anthropic:", "google:", "bedrock:"]
    
    def check_string(s: str):
        if not isinstance(s, str): return
        for f in forbidden:
            if s.startswith(f):
                raise ValueError(f"Cloud provider detected: {s}. offline-foo blocks this.")
                
    # Check providers
    providers = data.get("providers", [])
    if isinstance(providers, list):
        for p in providers:
            if isinstance(p, str):
                check_string(p)
            elif isinstance(p, dict) and "id" in p:
                check_string(p["id"])
    elif isinstance(providers, str):
        check_string(providers)

    # Check targets (for redteam)
    targets = data.get("targets", [])
    if isinstance(targets, list):
        for t in targets:
            if isinstance(t, str):
                check_string(t)
            elif isinstance(t, dict) and "id" in t:
                check_string(t["id"])
