"""
# uv run python src/offline_foo/generate_configs.py
"""
import os

TARGET = "ollama:chat:mistral:latest" # Configured for local vLLM/Ollama
# TARGET = "openai:chat:mistral-7b"

LABEL = "ollama-chat-mistral-latest"

# Embedded provider configurations to make the promptfooconfig.yamls self-sufficient
BASE_URL = "http://localhost:11434" # For vLLM, use: "http://localhost:8000/v1"
API_KEY = "dummy_key" # vLLM Open-AI router requires a key, but the actual value does not matter

PLUGINS_STRATEGIES = {
    "excessive-agency": ["basic", "jailbreak", "prompt-injection", "leetspeak", "base64"],
    "hallucination": ["basic", "jailbreak", "prompt-injection", "rot13", "leetspeak"],
    "rbac": ["jailbreak", "prompt-injection", "base64", "leetspeak", "rot13"],
    "prompt-extraction": ["basic", "jailbreak", "base64", "prompt-injection", "leetspeak"],
    "shell-injection": ["basic", "prompt-injection", "base64", "leetspeak", "jailbreak"],
    "sql-injection": ["basic", "prompt-injection", "base64", "leetspeak", "jailbreak"],
    "debug-access": ["basic", "jailbreak", "prompt-injection", "base64", "leetspeak"],
    "tool-discovery": ["basic", "jailbreak", "prompt-injection", "base64", "leetspeak"],
    "pii:direct": ["basic", "jailbreak", "base64", "prompt-injection", "leetspeak"],
    "pii:session": ["basic", "jailbreak", "base64", "prompt-injection", "leetspeak"],
    "pii:api-db": ["basic", "jailbreak", "base64", "prompt-injection", "leetspeak"],
    "pii:social": ["basic", "jailbreak", "base64", "prompt-injection", "leetspeak"],
}

output_dir = "sbatch_configs"
# Output to the project root's sbatch_configs directory
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
parent_output_dir = os.path.join(project_root, output_dir)
os.makedirs(parent_output_dir, exist_ok=True)

for plugin, strategies in PLUGINS_STRATEGIES.items():
    strategies_yaml = "\n".join([f"      - {s}" for s in strategies])
    
    yaml_content = f"""description: "Red Teaming Run for plugin {plugin}"
targets:
  - id: {TARGET}
    label: {LABEL}
    config:
      apiBaseUrl: "{BASE_URL}"
      apiKey: "{API_KEY}"
redteam:
  numTests: 20
  plugins:
    - {plugin}
  strategies:
{strategies_yaml}
"""

    # Format the file name
    safe_plugin_name = plugin.replace(":", "_")
    filename = f"redteam_{safe_plugin_name}.yaml"
    filepath = os.path.join(parent_output_dir, filename)

    with open(filepath, "w") as f:
        f.write(yaml_content)

    print(f"Generated {filepath}")
