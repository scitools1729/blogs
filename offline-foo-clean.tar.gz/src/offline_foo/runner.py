import os
import subprocess
import sys
from pathlib import Path

def run_promptfoo(args: list[str]) -> None:
    """Run promptfoo with disabled telemetry and updates."""
    env = os.environ.copy()
    
    # Disable promptfoo cloud integrations and telemetry
    env["PROMPTFOO_DISABLE_TELEMETRY"] = "1"
    env["PROMPTFOO_DISABLE_UPDATE"] = "1"
    env["PROMPTFOO_DISABLE_SHARE"] = "1"
    env["PROMPTFOO_DISABLE_REDTEAM_REMOTE_GENERATION"] = "1" # just in case
    
    # Base command
    cmd = ["npx", "promptfoo@latest"] + args
    
    print(f"Executing: {' '.join(cmd)}")
    try:
        # We use check=False and exit with the return code to perfectly proxy the behavior
        result = subprocess.run(cmd, env=env)
        sys.exit(result.returncode)
    except FileNotFoundError:
        print("Error: 'npx' command not found. Do you have Node.js installed?")
        sys.exit(1)
