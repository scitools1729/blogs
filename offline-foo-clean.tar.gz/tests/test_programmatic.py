import os
import sys
from pathlib import Path
from unittest.mock import patch
import pytest
from offline_foo.run_secure_promptfoo_redteam import run_secure_promptfoo_redteam

@pytest.fixture
def sample_config(tmp_path: Path):
    config_file = tmp_path / "promptfooconfig.yaml"
    config_file.write_text("description: mock")
    return config_file

@patch("offline_foo.run_secure_promptfoo_redteam.run_promptfoo")
@patch("offline_foo.run_secure_promptfoo_redteam.override_promptfoo_config")
def test_programmatic_api_integration(mock_override, mock_run, sample_config, tmp_path: Path):
    # Mock the override to return a fake secure temporary file path
    secure_temp_file = tmp_path / "mock_secure_temp.yaml"
    secure_temp_file.write_text("secure: true")
    mock_override.return_value = secure_temp_file
    
    run_secure_promptfoo_redteam(
        config_path=sample_config.as_posix(),
        attacker="mock:attacker",
        evaluator="mock:judge"
    )
    
    # 1. Assert override was called securely
    mock_override.assert_called_once_with(
        original_config_path=sample_config,
        local_provider="mock:attacker",
        evaluator_provider="mock:judge",
        is_redteam=True
    )
    
    # 2. Assert runner was executed with the temporary secure config
    mock_run.assert_called_once()
    args = mock_run.call_args[0][0]
    assert args == ["redteam", "run", "--config", str(secure_temp_file)]
    
    # 3. Assert the temporary secure config trace was cleanly deleted
    assert not secure_temp_file.exists()
