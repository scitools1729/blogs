import os
from pathlib import Path
from unittest.mock import patch, MagicMock
from typer.testing import CliRunner
from offline_foo.cli import app

runner = CliRunner()

def test_cli_init_command(tmp_path: Path):
    result = runner.invoke(app, ["init", "-p", "ollama:mock", "--directory", tmp_path.as_posix()])
    assert result.exit_code == 0
    config_file = tmp_path / "promptfooconfig.yaml"
    assert config_file.exists()
    content = config_file.read_text()
    assert "ollama:mock" in content

@patch("offline_foo.cli.run_promptfoo")
@patch("offline_foo.cli.override_promptfoo_config")
def test_cli_eval_command(mock_override, mock_run, tmp_path: Path):
    mock_override.return_value = tmp_path / "secure_config.yaml"
    
    result = runner.invoke(app, ["eval", "-p", "mock:evaluator", "--env-file", "test.env"])
    assert result.exit_code == 0
    
    # Assert run_promptfoo was called with eval, the new config, and forwarded args
    mock_run.assert_called_once()
    args = mock_run.call_args[0][0]
    assert args[0] == "eval"
    assert "--config" in args
    assert str(tmp_path / "secure_config.yaml") in args
    assert "--env-file" in args
    assert "test.env" in args

@patch("offline_foo.cli.run_promptfoo")
@patch("offline_foo.cli.override_promptfoo_config")
def test_cli_redteam_command(mock_override, mock_run, tmp_path: Path):
    mock_override.return_value = tmp_path / "secure_redteam_config.yaml"
    
    result = runner.invoke(app, ["redteam", "-a", "mock:attacker", "-e", "mock:judge", "--max-concurrency", "5"])
    assert result.exit_code == 0
    
    # Assert override logic was called with correct splits
    mock_override.assert_called_once()
    kwargs = mock_override.call_args[1]
    assert kwargs.get("local_provider") == "mock:attacker"
    assert kwargs.get("evaluator_provider") == "mock:judge"
    assert kwargs.get("is_redteam") is True
    
    # Assert run_promptfoo was called with redteam and forwarded args
    mock_run.assert_called_once()
    args = mock_run.call_args[0][0]
    assert args[0] == "redteam"
    assert "--config" in args
    assert str(tmp_path / "secure_redteam_config.yaml") in args
    assert "--max-concurrency" in args
    assert "5" in args
