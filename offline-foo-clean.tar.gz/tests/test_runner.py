import os
import sys
from unittest.mock import patch, MagicMock
import pytest
from offline_foo.runner import run_promptfoo

@patch("offline_foo.runner.subprocess.run")
@patch("offline_foo.runner.sys.exit")
def test_runner_telemetry_blockers(mock_exit, mock_subprocess):
    # Setup mock subprocess to succeed
    mock_result = MagicMock()
    mock_result.returncode = 0
    mock_subprocess.return_value = mock_result
    
    run_promptfoo(["eval"])
    
    mock_subprocess.assert_called_once()
    
    kwargs = mock_subprocess.call_args[1]
    assert "env" in kwargs
    env = kwargs["env"]
    
    # Assert security variables are forcefully injected
    assert env.get("PROMPTFOO_DISABLE_TELEMETRY") == "1"
    assert env.get("PROMPTFOO_DISABLE_UPDATE") == "1"
    assert env.get("PROMPTFOO_DISABLE_SHARE") == "1"
    assert env.get("PROMPTFOO_DISABLE_REDTEAM_REMOTE_GENERATION") == "1"
    
    # Assert exit code proxying
    mock_exit.assert_called_once_with(0)

@patch("offline_foo.runner.subprocess.run")
@patch("offline_foo.runner.sys.exit")
def test_runner_base_command(mock_exit, mock_subprocess):
    mock_result = MagicMock()
    mock_result.returncode = 0
    mock_subprocess.return_value = mock_result
    
    run_promptfoo(["redteam", "--config", "test.yaml"])
    
    args = mock_subprocess.call_args[0][0]
    assert args[0] == "npx"
    assert args[1] == "promptfoo@latest"
    assert args[2] == "redteam"
    assert args[3] == "--config"
    assert args[4] == "test.yaml"

@patch("offline_foo.runner.subprocess.run")
@patch("offline_foo.runner.sys.exit")
def test_runner_missing_node(mock_exit, mock_subprocess):
    # Simulate npx not being installed on the system
    mock_subprocess.side_effect = FileNotFoundError()
    
    run_promptfoo(["eval"])
    
    mock_exit.assert_called_once_with(1)
