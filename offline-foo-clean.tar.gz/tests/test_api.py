import os
from pathlib import Path
import pytest
from ruamel.yaml import YAML
from offline_foo.config import override_promptfoo_config

yaml = YAML()
yaml.preserve_quotes = True

@pytest.fixture
def sample_config(tmp_path: Path):
    config_content = """# Sample Offline Config
description: "Test run"
providers:
  - "echo"
prompts:
  - "Hello {{topic}}"
tests:
  - vars:
      topic: "world"
"""
    config_file = tmp_path / "promptfooconfig.yaml"
    config_file.write_text(config_content)
    return config_file

def test_override_promptfoo_config_eval(sample_config):
    local_provider = "ollama:chat:mistral:latest"
    secure_config_path = override_promptfoo_config(
        original_config_path=sample_config,
        local_provider=local_provider,
        is_redteam=False
    )
    
    try:
        assert secure_config_path.exists()
        
        with open(secure_config_path, "r", encoding="utf-8") as f:
            data = yaml.load(f)
            
        # The local provider should be injected into the defaultTest evaluator 
        assert "defaultTest" in data
        assert "options" in data["defaultTest"]
        assert data["defaultTest"]["options"]["provider"] == local_provider
        
    finally:
        if secure_config_path.exists():
            os.remove(secure_config_path)


def test_override_promptfoo_config_redteam_split(sample_config):
    attacker = "ollama:chat:attacker:latest"
    evaluator = "ollama:chat:judge:latest"
    
    secure_config_path = override_promptfoo_config(
        original_config_path=sample_config,
        local_provider=attacker,
        evaluator_provider=evaluator,
        is_redteam=True
    )
    
    try:
        assert secure_config_path.exists()
        
        with open(secure_config_path, "r", encoding="utf-8") as f:
            data = yaml.load(f)
            
        # Judge model should be evaluator
        assert data["defaultTest"]["options"]["provider"] == evaluator
        
        # Generator/Attacker model should be attacker
        assert data["redteam"]["provider"] == attacker
        
    finally:
        if secure_config_path.exists():
            os.remove(secure_config_path)

def test_cloud_provider_blocking(sample_config):
    # Add a forbidden cloud provider
    config_content = """
providers:
  - "openai:gpt-4"
prompts:
  - "Test"
"""
    sample_config.write_text(config_content)
    
    with pytest.raises(ValueError, match="Cloud provider detected: openai:gpt-4. offline-foo blocks this."):
        override_promptfoo_config(
            original_config_path=sample_config,
            local_provider="ollama:mock"
        )
