# Slurm Cluster Execution Guide

When running `offline-foo` on an HPC (High Performance Computing) cluster managed by Slurm, the most efficient approach is to separate the **evaluation orchestrator** (Promptfoo) from the **model inference engine** (e.g., vLLM).

This guide provides a reference `submit.sh` script for scheduling a purely CPU-bound orchestrator node that seamlessly communicates with an already-running LLM server on the cluster.

---

## 🚀 Scenario: Remote vLLM + Native Environment

**Assumptions for this script:**
1. A vLLM server is already running on another GPU node in your cluster (or as a persistent service) and has exposed an OpenAI-compatible endpoint.
2. You have a pre-existing compute module that contains Node.js (`npm`).
3. You have `uv` installed in your user space (e.g., `~/.local/bin/uv`) to manage the Python virtual environment.

### `submit.sh`

```bash
#!/bin/bash
#SBATCH --job-name=offline-foo
#SBATCH --output=slurm-%j.out
#SBATCH --error=slurm-%j.err
#SBATCH --partition=normal       # Adjust to your cluster's standard CPU partition
#SBATCH --nodes=1                
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=8        # Give promptfoo multiple cores for threading 
#SBATCH --mem=16G                # 16GB is plenty for the Node execution context
#SBATCH --time=04:00:00          # Max execution time (4 hours)

echo "Initializing SLURM offline-foo Execution on node: $HOSTNAME"
echo "Job ID: $SLURM_JOB_ID"

# ---------------------------------------------------------
# 1. Load Cluster Modules (Gets Node.js / npm)
# ---------------------------------------------------------
echo "Loading Anaconda ML Module..."
# Replace with the exact module name provided by your cluster admins
module load anaconda/Python-ML-2025a

# ---------------------------------------------------------
# 2. Expose User-Space Tools (Gets 'uv' and 'promptfoo')
# ---------------------------------------------------------
# Your Slurm job might not inherit your full bashrc PATH.
# We explicitly append your .local/bin so 'uv' is found, 
# and ~/.npm-global/bin in case you installed promptfoo in user-space.
export PATH="$HOME/.local/bin:$HOME/.npm-global/bin:$PATH"

# Print diagnostics to ensure the node found the right binaries
echo "Using npm: $(which npm)"
echo "Using uv: $(which uv)"
echo "Using promptfoo: $(which promptfoo)"

# ---------------------------------------------------------
# 3. Configure the Remote vLLM Connection
# ---------------------------------------------------------
# Point offline-foo to your already-running vLLM server
# **IMPORTANT:** Replace this IP with the actual address of your vLLM cluster node
export OPENAI_BASE_URL="http://10.X.X.X:8000/v1" 
export OPENAI_API_KEY="dummy-key-required-by-vllm"

# ---------------------------------------------------------
# 4. Execute Offline-Foo
# ---------------------------------------------------------
echo "Executing Offline-Foo Redteam (Native Engine)..."

# Use 'uv run' to seamlessly execute offline-foo within its managed virtual environment.
# UV will automatically find the .venv in the folder and handle the Python pathing.
uv run offline-foo redteam \
    -a openai:chat:mistralai/Mistral-7B-Instruct-v0.2 \
    --max-concurrency 10 \
    -o cluster_report.html

echo "Evaluation finished successfully."
```

---

## Why this design is incredibly efficient:

1. **No GPU Requirement (`--partition=normal`)**: Because the heavy lifting (model inference) is happening on your dedicated vLLM nodes, this SLURM job only needs standard CPU cores. This means your job will schedule and start **much** faster in the Slurm queue compared to waiting for a multi-node GPU allocation.
2. **High Concurrency (`--max-concurrency 10`)**: Since your external vLLM server is built for high-throughput batching, you can safely crank up the Promptfoo concurrency flag (`-j` or `--max-concurrency`) to attack the model with 10+ parallel requests at a time, drastically speeding up the evaluation.
3. **Transparent Pathing (`uv run`)**: You don't need to write complex `source .venv/bin/activate` logic. By prepending the command with `uv run`, `uv` dynamically locates the Python virtual environment in your workspace, setting up the exact environment instantly.
