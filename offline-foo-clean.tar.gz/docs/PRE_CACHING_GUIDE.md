# Offline-Foo Dataset Pre-Caching Guide

While `offline-foo` is designed for fully air-gapped environments, certain Promptfoo plugins (like `beavertails`, `harmbench`, and `unsafebench`) require downloading datasets from HuggingFace to function. 

Promptfoo uses a robust disk-based caching system for all HTTP requests. By "priming" this cache on an internet-connected machine and transferring it to your air-gapped environment, you can use these dataset plugins entirely offline!

## Step 1: Prime the Cache (Online Machine)

1. On an internet-connected machine, install Promptfoo:
   ```bash
   npm install -g promptfoo
   ```

2. Create a dummy `redteam.yaml` file that requests the dataset plugins you want to use.
   ```yaml
   prompts: ["Dummy prompt {{query}}"]
   targets:
     - id: echo
   redteam:
     plugins:
       - beavertails
       - harmbench
       - unsafebench
       - toxic-chat
       - cyberseceval
   ```

3. Run the generation process to force Promptfoo to download the datasets. You can cancel it (Ctrl+C) as soon as the progress bars finish downloading.
   ```bash
   promptfoo redteam generate -c redteam.yaml
   ```

## Step 2: Extract the Cache

Promptfoo stores its dataset and HTTP response cache in its config directory. 
- On Linux/macOS: `~/.promptfoo/cache/`
- On Windows: `C:\Users\<YourUser>\.promptfoo\cache\`

Inside this folder, you will find a `cache.json` file. This file contains the entirety of the HuggingFace datasets you just requested.

Copy the entire `cache` folder to a secure transfer medium (e.g., a USB drive) approved for your air-gapped environment.

## Step 3: Install on the Air-Gapped Machine

1. On your fully air-gapped machine, locate or create the `.promptfoo` configuration directory in the user's home folder:
   - Linux/macOS: `~/.promptfoo/`
   - Windows: `C:\Users\<YourUser>\.promptfoo\`

2. Paste the `cache` folder you transferred so that the structure looks like:
   `~/.promptfoo/cache/cache.json`

## Step 4: Run Offline-Foo

You're done! You can now use `offline-foo` with the dataset plugins. 

When `offline-foo` encounters a plugin like `beavertails`, Promptfoo will attempt to fetch the dataset, immediately find a cache hit in your transferred `cache.json`, and continue the evaluation without ever attempting an outbound network request.
