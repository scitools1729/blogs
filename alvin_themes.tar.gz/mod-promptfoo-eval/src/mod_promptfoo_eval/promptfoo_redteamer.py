from dataclasses import dataclass
from core_llmesh import Primitive
import subprocess
import json
import os

@dataclass
class PromptfooRedteamer(Primitive):
    name: str = "promptfoo_redteamer"

    def __init__(self):
        super().__init__(self.name)

    def run(self, **kwargs):
        config_path = kwargs.get("config_path")
        if not config_path:
            return {"status": "error", "message": "config_path is required"}
            
        try:
            from hydra.utils import to_absolute_path
            config_path = to_absolute_path(config_path)
        except ImportError:
            config_path = os.path.abspath(config_path)
        
        try:
            from hydra.core.hydra_config import HydraConfig
            output_dir = HydraConfig.get().runtime.output_dir
        except Exception:
            output_dir = os.getcwd()
            
        output_file = os.path.join(output_dir, "redteam_output.json")
        
        if os.path.exists(output_file):
            try:
                os.remove(output_file)
            except OSError:
                pass
        
        # Execute promptfoo redteam run using npx
        cmd = ["npx", "-y", "promptfoo", "redteam", "run", "-c", config_path, "-o", output_file]
        print(f"[promptfoo_redteamer] Executing: {' '.join(cmd)}")
        
        try:
            from rich.console import Console
            console = Console()
            
            captured_output = []
            with console.status("[bold blue]Starting promptfoo redteam run...", spinner="dots") as status:
                process = subprocess.Popen(
                    cmd, 
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.STDOUT, 
                    universal_newlines=True,
                    bufsize=1
                )
                
                for line in process.stdout:
                    captured_output.append(line)
                    clean_line = line.strip()
                    if clean_line:
                        # Truncate long lines so the spinner doesn't wrap awkwardly
                        if len(clean_line) > 80:
                            clean_line = clean_line[:77] + "..."
                        status.update(f"[bold blue]promptfoo: [white]{clean_line}")
                        
                process.wait()
            
            if process.returncode != 0:
                console.print(f"[bold red][promptfoo_redteamer] Process exited with code {process.returncode}[/bold red]")
            
            if not os.path.exists(output_file):
                return {
                    "status": "error",
                    "message": "Output file was not generated.",
                    "stdout": "".join(captured_output),
                    "stderr": ""
                }
                
            with open(output_file, 'r', encoding='utf-8') as f:
                eval_results = json.load(f)
                
            stats = eval_results.get("results", {}).get("stats", {})
            successes = stats.get("successes", 0) # models defended successfully 
            failures = stats.get("failures", 0)   # vulnerabilities found
            total = successes + failures
            
            return {
                "config_evaluated": config_path,
                "total_attacks": total,
                "attacks_defended": successes,
                "vulnerabilities_found": failures,
                "status": "completed"
            }
            
        except Exception as e:
            return {
                "status": "error",
                "message": str(e)
            }

    def get_tool_definition(self):
        return {
            "name": self.name,
            "description": "Executes a promptfoo redteam run using a manually authored configuration file.",
            "parameters": {
                "type": "object",
                "properties": {
                    "config_path": {
                        "type": "string",
                        "description": "The path to the promptfoo redteam configuration file"
                    }
                },
                "required": ["config_path"]
            }
        }

if __name__ == "__main__":
    tool = PromptfooRedteamer()
    print(tool.run(config_path="redteam.yaml"))
