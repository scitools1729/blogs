from dataclasses import dataclass
from core_llmesh import Primitive
import os
import json
import glob

@dataclass
class PromptfooReportGenerator(Primitive):
    name: str = "promptfoo_report_generator"

    def __init__(self):
        super().__init__(self.name)

    def run(self, **kwargs):
        multirun_dir = kwargs.get("multirun_dir")
        
        if not multirun_dir:
            try:
                from hydra.core.hydra_config import HydraConfig
                # If we are running this inside a multirun sweep, Hydra knows where the root is
                multirun_dir = HydraConfig.get().sweep.dir
            except Exception:
                pass
                
        if not multirun_dir:
             return {"status": "error", "message": "multirun_dir is required if not running recursively under a hydra multirun."}
             
        try:
            from hydra.utils import to_absolute_path
            multirun_dir = to_absolute_path(multirun_dir)
        except ImportError:
            multirun_dir = os.path.abspath(multirun_dir)
            
        if not os.path.isdir(multirun_dir):
            return {"status": "error", "message": f"Directory not found: {multirun_dir}"}
            
        aggregate_stats = {
            "total_suites_processed": 0,
            "total_evaluations": 0,
            "total_passed": 0,
            "total_failed": 0,
            "overall_pass_rate_percentage": 0.0,
            "detailed_results": []
        }
        
        # Search recursively for output.json or redteam_output.json
        search_pattern = os.path.join(multirun_dir, "**", "*.json")
        for filepath in glob.glob(search_pattern, recursive=True):
            filename = os.path.basename(filepath)
            if filename not in ["output.json", "redteam_output.json", "consolidated_report.json"]:
                # Promptfoo creates random configs or caches, we just want these outputs
                continue
                
            if filename == "consolidated_report.json":
                continue # don't ingest a previous report
                
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    stats = data.get("results", {}).get("stats", {})
                    successes = stats.get("successes", 0)
                    failures = stats.get("failures", 0)
                    total = successes + failures
                    
                    if total > 0:
                        aggregate_stats["total_suites_processed"] += 1
                        aggregate_stats["total_evaluations"] += total
                        aggregate_stats["total_passed"] += successes
                        aggregate_stats["total_failed"] += failures
                        
                        aggregate_stats["detailed_results"].append({
                            "source_file": filepath,
                            "successes": successes,
                            "failures": failures
                        })
            except Exception as e:
                pass # skip invalid files
                
        if aggregate_stats["total_evaluations"] > 0:
            rate = (aggregate_stats["total_passed"] / aggregate_stats["total_evaluations"]) * 100
            aggregate_stats["overall_pass_rate_percentage"] = round(rate, 2)
            
        aggregate_stats["status"] = "completed"
        
        # Write consolidated report out to the multirun root
        out_path = os.path.join(multirun_dir, "consolidated_report.json")
        with open(out_path, 'w', encoding='utf-8') as f:
            json.dump(aggregate_stats, f, indent=2)
            
        return aggregate_stats

    def get_tool_definition(self):
        return {
            "name": self.name,
            "description": "Finds all promptfoo json outputs across a multirun sweep directory and consolidates them into a single summary report.",
            "parameters": {
                "type": "object",
                "properties": {
                    "multirun_dir": {
                        "type": "string",
                        "description": "Path to the directory containing promptfoo JSON outputs (e.g. the Hydra multirun root)"
                    }
                },
                "required": ["multirun_dir"]
            }
        }

if __name__ == "__main__":
    tool = PromptfooReportGenerator()
    print(tool.run(multirun_dir="."))
