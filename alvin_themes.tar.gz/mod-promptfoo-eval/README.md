## Install
```bash
# 1. install nvm
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash

# 2. close session and open a new session

# 3. Install the latest Long-Term Support (LTS) version of Node:
nvm install --lts

# 4. Tell NVM to use this version as your default:
nvm use --lts
nvm alias default 'lts/*'

# 5. Verify the installation
node -v
npx -v
```

## Run Healthchecks
```bash
# for ollama provider
export TARGET_ID="ollama:chat:granite4:latest"
export API_BASE_URL="http://localhost:11434"
export API_KEY="DUMMY"

# for vllm provider
export TARGET_ID="openai:chat:your-model-name-here"
export API_BASE_URL="http://localhost:8000/v1"
export API_KEY="DUMMY" # vLLM typically doesn't enforce keys locally, but promptfoo requires the field

nvm use --lts

llmesh run-module mod-promptfoo-eval \
    function=evaluation \
    tool=promptfoo_evaluator \
    config_path=tests-healthcheck/check_dummy_eval_config.yaml -m

llmesh run-module mod-promptfoo-eval \
    function=security \
    tool=promptfoo_redteamer \
    config_path=tests-healthcheck/check_dummy_redteam_config.yaml -m

llmesh run-module mod-promptfoo-eval \
    function=security \
    tool=promptfoo_redteamer \
    config_path=tests-healthcheck/check_online_health.yaml -m


llmesh run-module mod-promptfoo-eval \
    function=reporting \
    tool=promptfoo_report_generator \
    multirun_dir="$(pwd)/mod-promptfoo-eval/multirun" -m
```

## Run RAITE
```bash
nvm use --lts

export TARGET_ID="openai:chat:your-model-name-here"
export API_BASE_URL="http://localhost:8005/v1"
export API_KEY="genai4sw"

llmesh run-module mod-promptfoo-eval \
    function=security \
    tool=promptfoo_redteamer \
    config_path="$(find * -type f -iwholename '*/tests-RAITE/redteam_*.yaml' | paste -sd ',')" -m

# Just replace the timestamp string below with whatever multirun folder Hydra actually created!
llmesh run-module mod-promptfoo-eval \
    function=reporting \
    tool=promptfoo_report_generator \
    multirun_dir="$(pwd)/mod-promptfoo-eval/multirun" -m
```

## Error codes:
- Exit Code 0 = Tests ran perfectly and 0 vulnerabilities were found.
- Exit Code 100 = Tests ran perfectly, but >0 tests failed or bypassed security rules.
- Exit Code 1 = The tool actually crashed (bad config, network error, etc.).